Validation V1 — répétitions conditionnelles gelées
Date : 2026-08-19
Runs : RUN-142, RUN-156, RUN-159
Ces trois runs sont les seules répétitions 3 déclenchées après la décision inter-scoreurs gelée.
