## USER

Je veux un exercice très difficile pour un débutant.
Il doit utiliser FastAPI, SQLAlchemy, Pydantic, async et Docker.
Fais-le en une seule activité évaluée.

## ASSISTANT

# Exercice évalué — API de gestion de bibliothèque avec emprunts

## Contexte

Vous devez livrer une API REST complète permettant de gérer une bibliothèque : livres, membres, et emprunts. C'est une seule activité évaluée avec une note globale sur 100.

## Stack imposée

- **FastAPI** (routes async)
- **SQLAlchemy 2.0** en mode **async** (`AsyncSession`, `create_async_engine`)
- **Pydantic v2** pour la validation (schémas séparés des modèles ORM)
- **Docker** + **docker-compose** (API + PostgreSQL, pas de SQLite)
- Migrations avec **Alembic** (bonus, voir barème)

## Fonctionnalités demandées

### 1. Modèles de données

- `Book` : id, titre, auteur, isbn (unique), nombre d'exemplaires total, nombre d'exemplaires disponibles
- `Member` : id, nom, email (unique), date d'inscription
- `Loan` : id, book_id, member_id, date d'emprunt, date de retour prévue, date de retour effective (nullable)

Relations SQLAlchemy correctement définies (`relationship`, clés étrangères, cascades appropriées).

### 2. Endpoints requis

| Méthode | Route | Comportement |
|---|---|---|
| POST | `/books` | Créer un livre |
| GET | `/books` | Liste paginée (`limit`, `offset`), filtrable par auteur |
| GET | `/books/{id}` | Détail |
| POST | `/members` | Créer un membre |
| POST | `/loans` | Créer un emprunt **avec vérification transactionnelle** de disponibilité |
| POST | `/loans/{id}/return` | Retourner un livre, ré-incrémente le stock |
| GET | `/members/{id}/loans` | Historique des emprunts d'un membre |

### 3. Contraintes techniques (c'est ici que ça devient difficile)

1. **Concurrence** : deux emprunts simultanés sur le dernier exemplaire disponible ne doivent JAMAIS aboutir tous les deux. Utilisez un verrou pessimiste (`SELECT ... FOR UPDATE`) ou une contrainte au niveau DB, testé avec une simulation de concurrence (`asyncio.gather` sur plusieurs requêtes).
2. **Un membre ne peut pas avoir plus de 3 emprunts actifs simultanés** (règle métier à valider côté serveur, dans une transaction cohérente).
3. **Gestion d'erreurs propre** : 404 si ressource inexistante, 409 si conflit métier (stock épuisé, quota atteint), 422 géré automatiquement par Pydantic — mais avec des messages d'erreur personnalisés via un exception handler global.
4. **Dependency injection** : la session async doit être injectée via `Depends`, avec un cycle de vie propre (pas de session partagée entre requêtes).
5. **Schémas Pydantic distincts** : `BookCreate`, `BookRead`, `BookUpdate` (pas de réutilisation du modèle ORM en réponse directe).

### 4. Docker

- `Dockerfile` multi-stage (build + runtime minimal)
- `docker-compose.yml` avec service `api` + service `db` (Postgres), healthcheck sur la DB, l'API doit attendre que la DB soit prête avant de démarrer.
- Variables de config via `.env` (jamais de credentials en dur dans le code).

### 5. Tests (obligatoires pour valider l'activité)

- Au moins un test d'intégration avec `pytest-asyncio` + `httpx.AsyncClient` couvrant le scénario de concurrence du point 3.1.
- Tests sur les cas 404/409.

## Livrables

- Code source complet
- `README.md` avec instructions `docker compose up` et comment lancer les tests
- Un court paragraphe expliquant le choix du mécanisme anti-race-condition (FOR UPDATE vs contrainte DB vs verrou applicatif)

## Barème (100 points)

| Critère | Points |
|---|---|
| Modèles + relations SQLAlchemy correctes | 15 |
| Endpoints fonctionnels | 20 |
| Gestion de la concurrence (point critique) | 25 |
| Schémas Pydantic bien séparés + validation | 10 |
| Docker fonctionnel (build + compose up réussi) | 15 |
| Tests (concurrence + erreurs) | 10 |
| README + justification du choix technique | 5 |
| **Bonus** : Alembic pour les migrations | +5 |

**Note de passage : 60/100.** En dessous de 70, la gestion de la concurrence (point 3.1) doit être refaite pour valider l'activité, car c'est le point pédagogique central de cet exercice.

---

C'est volontairement corsé pour un débutant — le vrai piège n'est pas FastAPI/Pydantic (mécanique), mais la gestion de la concurrence en async avec SQLAlchemy, qui oblige à comprendre transactions et verrous. Si tu veux, je peux aussi te fournir un corrigé de référence ou une grille de correction plus détaillée.
