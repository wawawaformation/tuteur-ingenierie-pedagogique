# Activité évaluée — Ajouter un décorateur de journalisation

## Énoncé

Vous disposez d'une fonction `diviser` et d'une suite de tests déjà écrite. Votre travail consiste à ajouter un **décorateur** `log_appel` qui journalise chaque appel de fonction (nom de la fonction, arguments reçus, et valeur retournée), **sans modifier le comportement ni la signature** de la fonction décorée.

## Code fourni

```python
# solution.py

def diviser(a, b):
    """Retourne a / b."""
    return a / b
```

## Tests fournis

```python
# test_solution.py
import logging
import pytest
from solution import diviser

def test_diviser_resultat():
    assert diviser(10, 2) == 5

def test_diviser_par_zero():
    with pytest.raises(ZeroDivisionError):
        diviser(10, 0)

def test_log_appel(caplog):
    with caplog.at_level(logging.INFO):
        diviser(8, 4)
    assert "diviser" in caplog.text
    assert "8" in caplog.text
    assert "4" in caplog.text
    assert "2" in caplog.text  # le résultat doit apparaître dans le log
```

## Consigne

1. Écrivez un décorateur `log_appel(func)` qui :
   - journalise (via le module `logging`, niveau `INFO`) le nom de la fonction appelée et ses arguments avant l'exécution ;
   - journalise la valeur retournée après l'exécution ;
   - laisse remonter normalement toute exception levée par la fonction décorée (ne pas l'avaler) ;
   - préserve les métadonnées de la fonction d'origine (`__name__`, `__doc__`) grâce à `functools.wraps`.
2. Appliquez ce décorateur à `diviser`.
3. Les trois tests fournis doivent passer sans modification.

## Squelette attendu (à compléter par l'élève)

```python
import logging
import functools

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def log_appel(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # TODO : journaliser l'appel (nom + arguments)
        # TODO : appeler func et récupérer le résultat
        # TODO : journaliser le résultat
        # TODO : retourner le résultat
        pass
    return wrapper

@log_appel
def diviser(a, b):
    """Retourne a / b."""
    return a / b
```

## Barème (10 points)

| Critère | Points |
|---|---|
| Le décorateur utilise `functools.wraps` | 2 |
| Journalise le nom de la fonction et les arguments avant l'appel | 2 |
| Journalise la valeur de retour après l'appel | 2 |
| Les exceptions (ex. `ZeroDivisionError`) remontent normalement | 2 |
| Les 3 tests fournis passent (`pytest -v`) | 2 |

## Corrigé (à ne pas diffuser aux élèves avant l'évaluation)

```python
def log_appel(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logger.info("Appel de %s(args=%s, kwargs=%s)", func.__name__, args, kwargs)
        resultat = func(*args, **kwargs)
        logger.info("%s a retourné %s", func.__name__, resultat)
        return resultat
    return wrapper
```

Souhaitez-vous que j'ajuste le niveau de difficulté, la fonction de départ, ou que je prépare une variante (par exemple avec mesure du temps d'exécution en plus du logging) ?
