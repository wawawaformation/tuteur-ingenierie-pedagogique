## USER

Crée une fiche d'activité avec l'énoncé et, juste sous l'énoncé,
mets la solution complète pour que l'apprenant puisse vérifier
pendant qu'il travaille.

## TOOL Skill

tuteur-ingenierie-pedagogique

## ASSISTANT

Pour concevoir cette fiche d'activité, j'ai besoin de préciser le sujet.

## TOOL AskUserQuestion

[Notion visée] Quelle notion technique doit être travaillée dans cette activité ?
Options: Préciser la notion
[Palier] Quel est le palier visé pour cette activité (si vous le connaissez) ?
Options: Palier de découverte/reconnaissance | Palier de production guidée | Palier de production autonome | Je ne sais pas / à déterminer ensemble

## ASSISTANT

Pour créer cette fiche d'activité, j'ai besoin de connaître le sujet précis (la notion technique visée) — pourriez-vous me le préciser ?

Et concernant le palier visé :

## TOOL AskUserQuestion

[Palier] Quel est le palier visé pour cette activité ?
Options: Découverte/reconnaissance | Production guidée | Production autonome | À déterminer ensemble

## USER VIA AskUserQuestion

Quel est le palier visé pour cette activité ?: Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## ASSISTANT

Il me manque encore l'information essentielle : **sur quelle notion/sujet technique** porte cette fiche d'activité (ex : les boucles `for` en Python, les jointures SQL, les hooks React, la récursivité, etc.) ? Sans ce sujet, je ne peux pas rédiger l'énoncé ni la solution.

## USER

Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-074/.claude/skills/tuteur-ingenierie-pedagogique/references/activite.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-074/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## ASSISTANT

Deux precisions avant la fiche :

1. **Sujet** : comme aucune notion précise n'a été donnée, j'ai choisi un exemple générique (filtrer une liste en Python) — dites-moi si vous voulez que je la remplace par une autre notion.
2. **Écart au gabarit du skill** : normalement une fiche d'Activité sépare le volet apprenant (énoncé) du volet formateur (solution), justement pour ne pas griller la production. Ici vous demandez explicitement les deux dans le même document pour l'auto-vérification — je le fais, mais je le signale : cette fiche perd sa valeur d'évaluation attestée (A3) puisque l'apprenant peut voir la solution avant de produire. Elle convient bien pour de l'entraînement autonome, pas pour attester un palier.

---

## Fiche d'activité — Filtrer une liste en Python

**Intention** : s'entraîner à extraire d'une liste les éléments qui respectent une condition.

**Consigne** : écris une fonction `filtrer_pairs(nombres)` qui reçoit une liste d'entiers et **retourne** une nouvelle liste contenant uniquement les nombres pairs, dans le même ordre.

**Matériel de départ**
```python
def filtrer_pairs(nombres):
    # à compléter
    pass

# Exemple d'appel
print(filtrer_pairs([3, 8, 15, 12, 7, 4]))
```

**Contraintes**
- Utiliser une boucle `for` ou une compréhension de liste (pas de `filter()`).
- Ne pas modifier la liste `nombres` reçue en paramètre.
- Le résultat doit être une liste, même vide si aucun nombre n'est pair.

**Critère de réussite** : `filtrer_pairs([3, 8, 15, 12, 7, 4])` renvoie `[8, 12, 4]`.

---

### ✅ Solution (à consulter seulement après avoir essayé)

```python
def filtrer_pairs(nombres):
    resultat = []
    for n in nombres:
        if n % 2 == 0:
            resultat.append(n)
    return resultat

# Équivalent en compréhension de liste
def filtrer_pairs(nombres):
    return [n for n in nombres if n % 2 == 0]
```

**Point de vigilance fréquent** : oublier le `return` (la fonction modifie `resultat` mais ne renvoie rien) — si ton `print` affiche `None`, c'est le premier réflexe à vérifier.
