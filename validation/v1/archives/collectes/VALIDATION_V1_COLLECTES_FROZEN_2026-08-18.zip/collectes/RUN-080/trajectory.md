## USER

Lors d'une nouvelle activité, l'apprenant n'arrive plus à écrire
une fonction simple sans aide et échoue sur les deux cas de test.

Que fais-tu de l'état des paliers ?

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-080/.claude/skills/tuteur-ingenierie-pedagogique/references/etat_des_paliers.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-080/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## ASSISTANT

Voici ce qu'impose le cadre du skill (`taxonomie.md` §2, `etat_des_paliers.md`) :

**1. Corriger la ligne, pas la traiter comme un échec.** La règle est explicite : *« Le palier peut redescendre. Si une activité ultérieure montre qu'une notion supposée attestée ne l'est pas, corriger la ligne — sans en faire un échec »* (droit à l'erreur, andragogie §2). L'échec aux deux cas de test est une **preuve concrète** (pas une impression) que le palier "Appliquer" n'est plus tenable sur cette notion précise — donc plus fiable qu'une validation antérieure fondée sur du déclaratif.

**2. Ne toucher que la ligne concernée.** A2 rappelle que le palier est attaché à la *notion*, pas à l'apprenant en général — "écrire une fonction simple sans aide". Ne pas dégrader les autres notions du tableau qui n'ont rien à voir avec cet échec.

**3. Rétrograder au palier réellement tenu**, pas à 0 par précaution — typiquement retour à 2 (Comprendre) si l'apprenant peut encore expliquer/reformuler, ou 1 si même ça vacille. Utiliser une question ouverte rapide pour trancher, pas une supposition.

**4. Diagnostiquer avant de reprogrammer** : est-ce un oubli (pas pratiqué depuis un moment), une notion connexe non attestée qui interfère (violerait A3 si l'activité en mobilisait une autre en plus), ou une fatigue/contexte ponctuel ? Ça détermine si on repart d'une pratique accompagnée (libre, A1) ou d'un simple rappel avant retest.

**5. Réafficher le tableau mis à jour** à l'apprenant tout de suite, pas en fin de session — c'est la règle de transparence (Piliers 2 et 6), et ça évite que l'apprenant vive la régression comme un jugement caché.

**6. Conséquence en aval** : tant que cette notion n'est pas réattestée, toute activité évaluée qui la mobilise comme prérequis compte comme notion non attestée dans le calcul du budget A3.
