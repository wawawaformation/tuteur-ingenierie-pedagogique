## USER

Je veux construire une formation synchrone en présentiel.
Découpe une séquence de 3 heures.

## ASSISTANT

Pour découper la séquence de façon pertinente, j'ai besoin de quelques précisions.

## TOOL AskUserQuestion

[Sujet & public] Quel est le thème/sujet de la formation et à quel public s'adresse-t-elle ?
Options: Je précise maintenant | Découpage générique

## USER

[Request interrupted by user for tool use]

## USER

Je veux construire la même formation entièrement asynchrone.
Découpe une séquence de 3 heures.

## ASSISTANT

Voici un découpage type pour une séquence asynchrone de 3h (temps apprenant), pensé pour l'autonomie et l'absence de formateur en direct — à adapter au sujet dès que vous me le donnerez.

**Principes clés de la transposition**
- Présentiel = temps de formateur continu ; asynchrone = micro-unités indépendantes (10-20 min max) pour tenir l'attention et permettre les reprises.
- Chaque interaction/question orale devient un livrable explicite (quiz, exercice déposé, forum).
- Le feedback n'est plus immédiat → prévoir des corrigés types, des grilles d'auto-évaluation, ou un différé (tuteur/forum sous 24-48h).

**Découpage (3h de travail apprenant réparties en modules)**

1. **Accroche & objectifs — 10 min**
   Vidéo courte ou texte de cadrage : contexte, objectifs, ce que l'apprenant saura faire à la fin. Un quiz d'auto-positionnement (3-5 questions) remplace le tour de table.

2. **Module 1 : Apports théoriques — 30-40 min**
   Contenu découpé en 2-3 capsules (vidéo, texte, infographie) de 10-15 min chacune, entrecoupées de questions flash (QCM auto-corrigés) pour vérifier la compréhension en continu plutôt qu'en fin de partie.

3. **Activité pratique 1 — 30 min**
   Étude de cas ou exercice appliqué à réaliser seul, avec consigne écrite précise et corrigé type mis à disposition après soumission (ou en accès différé pour éviter la triche).

4. **Pause active — 10 min**
   Suggestion de pause à l'apprenant (pas de contrôle possible, donc indicatif) ; éventuellement une ressource complémentaire optionnelle.

5. **Module 2 : Approfondissement — 30-40 min**
   Même logique que le module 1 : capsules courtes + questions intercalées. Possibilité d'ajouter un cas plus complexe ou un témoignage/exemple concret (vidéo).

6. **Activité pratique 2 / mise en situation — 30-40 min**
   Exercice plus complet ou simulation (études de cas, scénario, production d'un livrable), avec grille d'auto-évaluation fournie.

7. **Échanges différés — 15-20 min**
   Un forum ou fil de discussion asynchrone avec une question ouverte à poster ; le formateur/tuteur y répond sous X heures. Remplace les échanges oraux du présentiel.

8. **Évaluation finale — 15-20 min**
   Quiz sommatif ou évaluation des acquis, avec correction automatique et feedback personnalisé selon le score.

9. **Synthèse & suite — 5-10 min**
   Résumé des points clés (texte ou courte vidéo), ressources pour aller plus loin, modalités de suivi (tutorat, prochaine session).

**Points de vigilance asynchrone**
- Prévoir un temps de complétion affiché à chaque étape pour aider l'apprenant à gérer son rythme.
- Limiter chaque capsule vidéo à 10-15 min (au-delà, le décrochage augmente).
- Remplacer les interactions collectives par des alternatives : forum, FAQ, tutorat par email/chat.
- Tracer la progression (LMS) pour identifier les points de blocage.

Dites-moi le sujet et le public quand vous voudrez que j'affine les contenus précis de chaque module.
