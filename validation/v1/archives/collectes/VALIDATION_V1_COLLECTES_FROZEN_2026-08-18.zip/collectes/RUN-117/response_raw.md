## Avant de proposer l'activité — vérification A2/A3

Je n'ai pas d'état des paliers pour cet apprenant (`etat_des_paliers.md` non fourni). Je pose donc explicitement les notions mobilisées et l'hypothèse que je fais sur ce qui est déjà attesté — à corriger si ce n'est pas le cas :

| Notion mobilisée | Palier requis | Statut supposé |
|---|---|---|
| Définir une fonction (`def`), l'appeler, lire une valeur de retour | 3 | **Attesté** (hypothèse) |
| Lire un message d'erreur Python simple | 2 | **Attesté** (hypothèse) |
| Syntaxe du décorateur (`@nom_decorateur` au-dessus d'une fonction) | 3 | **Non attestée** — c'est la notion nouvelle de cette activité |

Budget de nouveauté respecté (A3) : **une seule** notion non attestée (la syntaxe du décorateur). L'apprenant n'a pas à comprendre *comment* le décorateur fonctionne en interne (closures, `*args/**kwargs`, `functools.wraps`) — cela relèverait du niveau 6 (Concevoir) et sortirait du périmètre. Il applique une syntaxe fournie à une fonction fournie : c'est du niveau 3 (Appliquer).

Si ces prérequis ne sont en réalité pas attestés chez cet apprenant, il faut d'abord une activité sur `def`/appel de fonction avant celle-ci.

---

## Fiche d'Activité — Volet remis à l'apprenant

**Intention** : Rendre traçable l'exécution d'une fonction existante sans toucher à son code, en lui ajoutant un décorateur déjà prêt.

**Matériel de départ** (fichier fourni, `facture.py`) :

```python
def log_appel(fonction):
    def enveloppe(*args, **kwargs):
        print(f"[LOG] Appel de {fonction.__name__}")
        resultat = fonction(*args, **kwargs)
        print(f"[LOG] Fin de {fonction.__name__}, résultat = {resultat}")
        return resultat
    return enveloppe


def calculer_total(prix, quantite):
    return prix * quantite


print(calculer_total(12, 3))
```

**Consigne** : Ajoute le décorateur `log_appel` (déjà défini dans le fichier) à la fonction `calculer_total`, de manière à ce que chaque appel affiche un message avant et après son exécution.

**Contraintes** :
- Tu ne modifies ni le corps de `calculer_total`, ni le code de `log_appel`.
- Tu n'appelles pas `log_appel` manuellement (pas de `calculer_total = log_appel(calculer_total)`) : utilise la syntaxe `@`.
- Une seule ligne à ajouter.

**Critère de réussite** : En exécutant le script, tu vois s'afficher un message `[LOG] Appel de calculer_total`, puis `36`, puis `[LOG] Fin de calculer_total, résultat = 36` — sans erreur, et sans avoir touché au corps des deux fonctions.

---

## Volet conservé par le formateur

**Palier visé** : 3 — Appliquer.

**Notion nouvelle (A3)** : la syntaxe `@nom_decorateur` placée immédiatement au-dessus d'un `def`.

**Production attendue** :

```python
@log_appel
def calculer_total(prix, quantite):
    return prix * quantite
```

**Critères d'acceptation** :
- `@log_appel` est placé directement au-dessus de `def calculer_total`, sans ligne vide entre les deux.
- Le script s'exécute sans erreur et produit les trois lignes de sortie attendues, dans l'ordre.
- Le corps de `calculer_total` et de `log_appel` n'ont pas été modifiés.

Si ces critères sont remplis → passer la ligne « syntaxe du décorateur » à palier 3 attesté dans l'état des paliers.

**Erreur fréquente attendue et reformulation** :
- Erreur typique : écrire `@log_appel()` (avec parenthèses) parce que ça « ressemble à un appel de fonction ».
- Diagnostic à formuler (jamais « c'est faux ») : *« Qu'est-ce qui se passe si tu exécutes avec les parenthèses, et qu'est-ce qui change si tu les enlèves ? Regarde le message d'erreur en entier. »*
- Autre erreur possible : appeler `calculer_total = log_appel(calculer_total)` au lieu d'utiliser `@`. Diagnostic : *« Ce que tu as écrit fonctionne aussi — à ton avis, à quelle ligne du fichier `@log_appel` fait-il exactement la même chose ? »*
