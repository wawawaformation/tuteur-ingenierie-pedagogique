Voici un décorateur Python concret et courant : mesurer le temps d'exécution d'une fonction.

```python
import time
from functools import wraps

def chrono(fonction):
    @wraps(fonction)
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = fonction(*args, **kwargs)
        fin = time.time()
        print(f"{fonction.__name__} a pris {fin - debut:.4f} secondes")
        return resultat
    return wrapper


@chrono
def calculer_somme(n):
    return sum(range(n))


calculer_somme(10_000_000)
```

**Ce qui se passe :**

1. `chrono` est une fonction qui prend une autre fonction (`fonction`) en argument.
2. À l'intérieur, elle définit une nouvelle fonction `wrapper` qui « enveloppe » l'appel original : elle note l'heure de début, appelle `fonction(*args, **kwargs)` pour exécuter le vrai code, note l'heure de fin, affiche la durée, puis renvoie le résultat comme si de rien n'était.
3. `chrono` retourne `wrapper` — c'est cette nouvelle fonction qui remplacera `calculer_somme`.
4. La ligne `@chrono` juste au-dessus de `def calculer_somme(n):` est un raccourci pour écrire :
   ```python
   calculer_somme = chrono(calculer_somme)
   ```
   Autrement dit, `@chrono` remplace `calculer_somme` par sa version « enveloppée ».
5. Quand on appelle ensuite `calculer_somme(10_000_000)`, c'est en réalité `wrapper` qui s'exécute : il lance le chronométrage, appelle la vraie fonction, affiche le temps, puis renvoie le résultat calculé.

**L'idée clé** : un décorateur permet d'ajouter un comportement (ici, du chronométrage) autour d'une fonction *sans modifier son code interne*. On pourrait réutiliser `@chrono` sur n'importe quelle autre fonction pour mesurer son temps d'exécution, sans dupliquer la logique de mesure.

(Petit détail technique : `@wraps(fonction)` sert juste à conserver le nom et la documentation de la fonction originale — sans ça, `calculer_somme.__name__` afficherait `wrapper` au lieu de `calculer_somme`.)
