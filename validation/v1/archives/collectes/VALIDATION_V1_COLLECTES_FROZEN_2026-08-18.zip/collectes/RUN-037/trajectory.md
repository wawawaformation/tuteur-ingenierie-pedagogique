## USER

Lors d'une nouvelle activité, l'apprenant n'arrive plus à écrire
une fonction simple sans aide et échoue sur les deux cas de test.

Que fais-tu de l'état des paliers ?

## ASSISTANT

Je ne rétrograderais pas le palier tout de suite sur ce seul signal : un échec sur une activité nouvelle peut juste refléter une difficulté ponctuelle (fatigue, notion mal consolidée, énoncé ambigu) plutôt qu'une vraie perte de compétence acquise. Je marquerais plutôt le palier comme "à vérifier"/en observation et je proposerais une activité de renforcement ciblée sur les points ratés ; si l'échec se reproduit sur 2-3 tentatives similaires, là je déclasserais le palier.

Le compromis : figer le palier trop longtemps risque de masquer une vraie régression (l'apprenant progresse sur le papier sans maîtriser), alors que déclasser trop vite décourage et peut être un faux signal statistique.
