Fiche de Séance – Validation des données avec Pydantic

**Durée :** 45 minutes
**Public :** Développeurs Python ayant des bases en programmation orientée objet
**Prérequis :** Python 3.8+, notions de classes, type hints de base

## Objectifs pédagogiques

À l'issue de la séance, le participant sera capable de :
- Définir un modèle de données avec Pydantic (BaseModel)
- Utiliser les types Python et les validateurs intégrés pour contraindre les données
- Écrire des validateurs personnalisés (`@field_validator`, `@model_validator`)
- Gérer et exploiter les erreurs de validation (`ValidationError`)

## Déroulé

### 1. Introduction (5 min)
- Pourquoi valider des données ? (entrées utilisateur, API, fichiers de config)
- Limites de la validation manuelle (if/else, try/except dispersés)
- Positionnement de Pydantic : validation déclarative basée sur les type hints

### 2. Modèle de base (10 min)
- Création d'une classe héritant de `BaseModel`
- Déclaration des champs avec type hints (`str`, `int`, `float`, `bool`, `Optional`)
- Instanciation et coercition automatique de types (ex : `"123"` → `123`)
- Démonstration : `model_dump()` et `model_dump_json()`

```python
from pydantic import BaseModel

class Utilisateur(BaseModel):
    nom: str
    age: int
    email: str
```

### 3. Contraintes et types avancés (10 min)
- `Field()` : valeurs par défaut, contraintes (`gt`, `lt`, `min_length`, `max_length`)
- Types spécialisés : `EmailStr`, `HttpUrl`, `conint`, `constr`
- Champs optionnels vs obligatoires
- Listes, dictionnaires et modèles imbriqués (`List[Item]`, sous-modèles)

```python
from pydantic import BaseModel, Field, EmailStr

class Utilisateur(BaseModel):
    nom: str = Field(min_length=2)
    age: int = Field(gt=0, lt=120)
    email: EmailStr
```

### 4. Validateurs personnalisés (10 min)
- `@field_validator` : logique métier sur un champ précis
- `@model_validator` : validation croisée entre plusieurs champs
- Cas d'usage : cohérence de dates, unicité, règles métier complexes

```python
from pydantic import field_validator

class Utilisateur(BaseModel):
    nom: str
    age: int

    @field_validator("nom")
    @classmethod
    def nom_non_vide(cls, v):
        if not v.strip():
            raise ValueError("Le nom ne peut pas être vide")
        return v
```

### 5. Gestion des erreurs (7 min)
- Capture de `ValidationError`
- Structure de l'erreur : `errors()` (champ, message, type)
- Bonnes pratiques : remonter des erreurs exploitables côté API (FastAPI en aperçu rapide)

```python
from pydantic import ValidationError

try:
    Utilisateur(nom="", age=30)
except ValidationError as e:
    print(e.errors())
```

### 6. Synthèse et questions (3 min)
- Récapitulatif : modèle → contraintes → validateurs → erreurs
- Ouverture possible : Pydantic Settings, intégration FastAPI

## Modalités
- **Format :** démonstration live coding + mini-exercices guidés
- **Support :** environnement Python avec `pydantic` installé (`pip install pydantic`)
- **Évaluation formative :** exercice final — modéliser une commande e-commerce (produit, quantité, prix, email client) avec au moins une validation personnalisée
