## USER

L'activité demande simplement :
« Écris une fonction Python qui prend deux nombres et retourne leur somme. »

Est-ce une nouvelle notion ?

## ASSISTANT

Non. Cette activité ne fait qu'appliquer des notions déjà de base en Python : définition de fonction (`def`), paramètres, et `return`. Aucune nouvelle notion n'est introduite par rapport à ce qui est typiquement déjà couvert dès les premiers exercices sur les fonctions.

```python
def somme(a, b):
    return a + b
```
