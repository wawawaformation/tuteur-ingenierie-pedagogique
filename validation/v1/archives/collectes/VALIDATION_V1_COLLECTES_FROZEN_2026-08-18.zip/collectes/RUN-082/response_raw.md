# Quiz d'auto-positionnement — Prérequis pour les décorateurs

Objectif : vérifier que les notions nécessaires avant d'aborder les décorateurs sont acquises. Répondez sans lancer Python, puis vérifiez.

**1. Fonctions comme objets de première classe**
Que produit ce code ?
```python
def saluer():
    return "bonjour"

f = saluer
print(f())
```
a) `saluer` b) `bonjour` c) une erreur d) `<function saluer>`

**2. Passer une fonction en argument**
```python
def appliquer(fonction, valeur):
    return fonction(valeur)

print(appliquer(str.upper, "abc"))
```
Que renvoie cet appel ?

**3. Fonction interne (closure)**
```python
def externe():
    x = 10
    def interne():
        return x + 1
    return interne

g = externe()
print(g())
```
Quelle est la sortie ? Expliquez en une phrase pourquoi `interne` a accès à `x`.

**4. Retourner une fonction**
Écrivez une fonction `multiplicateur(n)` qui retourne une fonction prenant `x` et renvoyant `n * x`. Testez avec `double = multiplicateur(2)` puis `double(5)`.

**5. `*args` et `**kwargs`**
```python
def f(*args, **kwargs):
    print(args, kwargs)

f(1, 2, a=3)
```
Que s'affiche-t-il ?

**6. Portée (scope)**
```python
def compteur():
    n = 0
    def incrementer():
        n += 1
        return n
    return incrementer

c = compteur()
print(c())
```
Cela lève-t-il une erreur ? Si oui, laquelle et pourquoi ? (indice : mot-clé `nonlocal`)

**7. Fonction anonyme**
Quelle est la différence entre une fonction définie avec `def` et une fonction `lambda` ? Dans quel cas utiliseriez-vous plutôt l'une ou l'autre ?

**8. Enchaîner des appels**
```python
def double(x):
    return x * 2

def carre(x):
    return x ** 2

resultat = carre(double(3))
print(resultat)
```
Calculez `resultat` mentalement.

**9. Attributs de fonction**
Que fait `functools.wraps` et pourquoi pourrait-on en avoir besoin en enveloppant une fonction dans une autre ? (Si vous ne savez pas, ce n'est pas grave — c'est justement une notion abordée avec les décorateurs.)

**10. Synthèse**
En une phrase, comment décririez-vous ce qu'est une fonction qui "enveloppe" une autre fonction pour lui ajouter un comportement, sans la modifier elle-même ?

---

## Corrigé rapide

1. **b** — `f` est juste un alias vers `saluer`.
2. `"ABC"` — `str.upper` est passée sans être appelée, puis exécutée dans `appliquer`.
3. `11` — `interne` capture `x` par closure car elle est définie dans la portée d'`externe` et y fait référence.
4. 
```python
def multiplicateur(n):
    def fonction(x):
        return n * x
    return fonction
```
5. `(1, 2) {'a': 3}`
6. Oui, `UnboundLocalError` : `n += 1` tente de modifier une variable locale à `interne` avant qu'elle soit affectée dans cette portée. Il faut `nonlocal n` pour indiquer qu'on modifie la variable de la portée englobante.
7. `lambda` est une expression anonyme limitée à une seule instruction (pas de nom, pas de corps multi-lignes) ; `def` convient pour une logique plus complexe ou nommée. `lambda` est pratique pour des fonctions courtes passées en argument (ex. `sorted(key=lambda x: ...)`).
8. `double(3)` → `6`, puis `carre(6)` → `36`.
9. `functools.wraps` préserve les métadonnées (nom, docstring) de la fonction originale quand on la remplace par une fonction "wrapper" — sans ça, `help()` ou `__name__` pointeraient vers le wrapper au lieu de la fonction décorée.
10. Réponse ouverte — l'essentiel est l'idée de fonction qui prend une fonction en entrée, retourne une nouvelle fonction, et ajoute du comportement autour de l'appel original.

**Grille d'interprétation :**
- 8-10 bonnes réponses → prêt à attaquer les décorateurs directement.
- 5-7 → réviser les closures (questions 3, 6) et `*args/**kwargs` avant de continuer.
- <5 → revoir d'abord "fonctions comme objets" et "fonctions imbriquées" avant la séquence.
