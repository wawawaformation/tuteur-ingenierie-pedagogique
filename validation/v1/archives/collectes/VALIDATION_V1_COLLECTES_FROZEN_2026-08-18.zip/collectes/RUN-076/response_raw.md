Avant de plonger dans le code, une question rapide pour rendre l'exemple concret :

Parfait, on part sur l'exemple du **chronomètre** (`@chrono`) — c'est le plus parlant pour voir ce qu'un décorateur apporte concrètement.

On va y aller étape par étape, je code avec toi et j'explique à chaque étape. On ne va pas écrire le décorateur tout de suite : il faut d'abord poser deux briques indispensables.

## Étape 1 — une fonction "normale" qu'on veut chronométrer

```python
import time

def calcul_long():
    total = 0
    for i in range(10_000_000):
        total += i
    return total
```

On a une fonction toute simple. Le but : savoir combien de temps `calcul_long()` met à s'exécuter, **sans modifier son code**.

La version "sans décorateur", tu l'as peut-être déjà faite intuitivement :

```python
debut = time.time()
resultat = calcul_long()
fin = time.time()
print(f"Temps : {fin - debut:.4f}s")
```

Ça marche, mais si tu veux chronométrer 10 fonctions différentes, tu dois recopier ces 3 lignes partout. C'est exactement le problème qu'un décorateur résout : **factoriser un comportement qu'on veut ajouter autour de plusieurs fonctions**.

Avant d'aller plus loin, dis-moi : est-ce que ce code ci-dessus est clair pour toi (notamment `time.time()`) ? On passe ensuite à la brique clé : **une fonction peut en prendre une autre en paramètre**.
