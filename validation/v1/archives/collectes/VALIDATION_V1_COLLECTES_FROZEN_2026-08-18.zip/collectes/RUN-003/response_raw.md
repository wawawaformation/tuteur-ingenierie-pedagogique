## Avant de proposer l'activité — état des paliers mobilisés

| Notion | Palier attesté | Preuve | Quand |
|---|---|---|---|
| Fonction simple (paramètres, valeur de retour) | 3. Appliquer | déclaré par vous : l'apprenant sait déjà en écrire | — |
| Test (assertion sur un résultat) | 3. Appliquer | déclaré par vous : l'apprenant sait déjà en écrire | — |
| Fonction enveloppante (wrapper) — une fonction qui reçoit une fonction en argument et en retourne une nouvelle | 0 | notion identifiée, rien d'attesté | — |

Deux notions sont déjà attestées au palier requis, une seule est nouvelle → l'activité respecte le budget de nouveauté (A3).

J'ai posé une hypothèse : **Python**, faute de précision de votre part sur le langage. Dites-moi si ce n'est pas le bon contexte, je réajuste.

---

## Fiche d'Activité — « Encapsuler un comportement autour d'une fonction »

### Volet remis à l'apprenant

**Intention** — Beaucoup d'outils (mesure de temps, journalisation, vérification de droits) ajoutent un comportement autour d'une fonction sans toucher à son code. Tu vas construire toi-même ce mécanisme.

**Matériel de départ** — Ces deux fichiers te sont fournis, ne les modifie pas :

```python
# fonctions.py
def addition(a, b):
    return a + b

def multiplication(a, b):
    return a * b
```

```python
# test_existant.py
from fonctions import addition

def test_addition():
    assert addition(3, 4) == 7
```

Ce test passe déjà — il atteste que tu sais écrire une fonction et un test ; ce n'est pas ce qu'on évalue ici.

**Consigne** — Écris une fonction `enveloppe(fonction)` qui :
- prend **une fonction quelconque** en argument,
- retourne **une nouvelle fonction**, qui, quand on l'appelle :
  1. ajoute la chaîne `"avant"` à une liste `journal`,
  2. appelle la fonction d'origine avec les arguments reçus,
  3. ajoute la chaîne `"après"` à `journal`,
  4. renvoie le résultat de la fonction d'origine, inchangé.

**Contraintes**
- Interdiction de modifier `addition`, `multiplication` ou le test fourni.
- `enveloppe` ne doit contenir **aucune référence en dur** à `addition` ou `multiplication` : elle doit fonctionner avec n'importe quelle fonction qu'on lui passe.
- Tu dois prouver la généricité en écrivant toi-même un second test qui utilise `enveloppe(multiplication)`.

**Critère de réussite** — Ton propre test passe sur les deux points suivants, pour `addition` **et** pour `multiplication`, sans avoir touché à leur code :
- le résultat renvoyé par la version enveloppée est identique à celui de la fonction d'origine ;
- `journal` contient exactement `["avant", "après"]` dans cet ordre après l'appel.

---

### Volet conservé par le formateur

**Palier visé** — 6. Créer (construire un mécanisme complet à partir de contraintes, sans méthode fournie).

**Notion nouvelle (unique, A3)** — la fonction d'ordre supérieur enveloppante : une fonction qui reçoit une fonction en paramètre et retourne une nouvelle fonction exécutant du code avant/après l'appel, en préservant le résultat.

**Production attendue**

```python
def enveloppe(fonction):
    def version_enveloppee(*args, **kwargs):
        journal.append("avant")
        resultat = fonction(*args, **kwargs)
        journal.append("après")
        return resultat
    return version_enveloppee
```

(`journal` peut être une liste globale fournie dans le squelette, ou passée/déclarée par l'apprenant — laisser ce détail libre ne change pas le palier visé.)

**Critères d'acceptation**
- `enveloppe(addition)(3, 4)` renvoie `7`, `journal == ["avant", "après"]`.
- `enveloppe(multiplication)(3, 4)` renvoie `12`, `journal == ["avant", "après"]`, **sans qu'une seule ligne de `enveloppe` ait changé**.
- Aucune référence en dur au nom d'une fonction précise dans le corps de `enveloppe`.

**Erreur fréquente attendue et sa reformulation**
L'apprenant écrit souvent une fonction qui appelle `addition` directement à l'intérieur, au lieu d'appeler le paramètre reçu — ça marche pour `addition`, ça casse pour `multiplication`. Plutôt que « c'est faux », demander :
> « Si je te demande maintenant d'envelopper `multiplication` au lieu de `addition`, dois-tu changer une seule ligne à l'intérieur de `enveloppe` ? »

Erreur secondaire possible : oublier de `return` le résultat de l'appel interne — le retour vaut alors `None`. Reformulation : « Que contient `resultat` si `fonction(*args, **kwargs)` n'est jamais capturé nulle part ? »
