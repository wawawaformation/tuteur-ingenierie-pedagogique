I dois avoir quelques informations avant de découper cette séquence.

Pour construire cette séquence, j'ai besoin de trois précisions :

1. **Sujet** : quelle est la compétence ou le thème technique/métier visé par ces 3 heures ?
2. **Public** : qui sont les apprenants, et quels prérequis peut-on supposer déjà acquis ?
3. **Contexte** : cette séquence s'inscrit-elle dans un module/syllabus déjà défini (avec une séquence amont/aval), ou est-ce un point de départ isolé ?

Deux points à clarifier avant de découper.

**1. Sur la durée** : en asynchrone, une Séquence inclut le temps de production du livrable par l'apprenant, et la fourchette observée est plutôt 8-15h (contre 2-4h en présentiel, qui elles n'incluent pas la production). Une Séquence asynchrone de seulement 3h serait donc inhabituelle — soit ça correspond en réalité à un seul **Atelier** (niveau en dessous de la Séquence, 1h30-3h, une production évaluée en étapes), soit vous voulez vraiment une Séquence complète mais avec un volume de production plus faible que d'habitude. Lequel des deux correspond à votre intention ?

**2. Il me manque toujours** (la même formation que le présentiel, donc peut-être déjà répondu dans votre tête, mais je préfère confirmer) :
- le sujet / la compétence visée
- le public et les prérequis supposés acquis
- si ça s'inscrit dans un module/parcours déjà défini, ou si c'est un point de départ isolé
