## USER

Je veux construire une formation synchrone en présentiel.
Découpe une séquence de 3 heures.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-052/.claude/skills/tuteur-ingenierie-pedagogique/references/decoupage_pedagogique.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-052/.claude/skills/tuteur-ingenierie-pedagogique/references/sequence.md

## ASSISTANT

I dois avoir quelques informations avant de découper cette séquence.

## TOOL AskUserQuestion

[Sujet] Quel est le sujet / la compétence visée par cette séquence de 3h ?
Options: Autre (préciser)
[Public] Qui est le public et quels prérequis peut-on supposer déjà acquis ?
Options: Autre (préciser)
[Contexte] Cette séquence de 3h s'inscrit-elle dans un module plus large déjà défini, ou est-ce un point de départ isolé ?
Options: Point de départ isolé | Module existant

## ASSISTANT

Pour construire cette séquence, j'ai besoin de trois précisions :

1. **Sujet** : quelle est la compétence ou le thème technique/métier visé par ces 3 heures ?
2. **Public** : qui sont les apprenants, et quels prérequis peut-on supposer déjà acquis ?
3. **Contexte** : cette séquence s'inscrit-elle dans un module/syllabus déjà défini (avec une séquence amont/aval), ou est-ce un point de départ isolé ?

## USER

Je veux construire la même formation entièrement asynchrone.
Découpe une séquence de 3 heures.

## ASSISTANT

Deux points à clarifier avant de découper.

**1. Sur la durée** : en asynchrone, une Séquence inclut le temps de production du livrable par l'apprenant, et la fourchette observée est plutôt 8-15h (contre 2-4h en présentiel, qui elles n'incluent pas la production). Une Séquence asynchrone de seulement 3h serait donc inhabituelle — soit ça correspond en réalité à un seul **Atelier** (niveau en dessous de la Séquence, 1h30-3h, une production évaluée en étapes), soit vous voulez vraiment une Séquence complète mais avec un volume de production plus faible que d'habitude. Lequel des deux correspond à votre intention ?

**2. Il me manque toujours** (la même formation que le présentiel, donc peut-être déjà répondu dans votre tête, mais je préfère confirmer) :
- le sujet / la compétence visée
- le public et les prérequis supposés acquis
- si ça s'inscrit dans un module/parcours déjà défini, ou si c'est un point de départ isolé
