Bonne idée ! Les décorateurs sont un concept qui clique bien mieux quand on les construit soi-même étape par étape plutôt qu'en lisant une définition. On va y aller progressivement.

**Étape 0 — le prérequis à valider d'abord**

Avant de parler de décorateurs, il faut être à l'aise avec une idée : *en Python, une fonction est une valeur comme une autre*. On peut la mettre dans une variable, la passer en argument, la retourner depuis une autre fonction.

Petit test pour voir où on en est : est-ce que ce code te semble normal, ou est-ce que ça te surprend ?

```python
def dire_bonjour():
    print("Bonjour !")

action = dire_bonjour   # pas d'appel, pas de parenthèses
action()                # ça appelle dire_bonjour()
```

Dis-moi : à ton avis, qu'est-ce que ça affiche, et pourquoi il n'y a pas de parenthèses à la ligne `action = dire_bonjour` ?
