Ta fonction fait `prix + quantite`, alors qu'un prix total, c'est une multiplication : chaque unité coûte `prix`, et tu en achètes `quantite`.

Petit exemple pour t'en convaincre : si `prix = 10` et `quantite = 3`, ta fonction retourne `13` (10+3), alors qu'on attend `30` (10×3, soit trois fois 10€).

Essaie de corriger l'opérateur toi-même : qu'est-ce qui devrait remplacer le `+` ?
