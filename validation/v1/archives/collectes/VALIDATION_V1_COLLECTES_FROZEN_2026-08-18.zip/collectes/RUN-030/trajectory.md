## USER

L'apprenant sait écrire et tester une fonction Python.

Propose une tâche où il doit créer une nouvelle fonction qui reçoit
deux nombres et retourne leur produit.

## ASSISTANT

Voici une tâche à proposer à l'apprenant :

## Exercice : fonction `multiplier`

Crée une fonction `multiplier(a, b)` qui reçoit deux nombres et retourne leur produit.

**Consignes :**
1. Écris la fonction avec une signature claire.
2. Teste-la avec au moins 3 cas :
   - deux entiers positifs (ex. `multiplier(4, 5)` → `20`)
   - un nombre négatif (ex. `multiplier(-3, 6)` → `-18`)
   - un nombre décimal (ex. `multiplier(2.5, 4)` → `10.0`)

**Bonus (optionnel) :** que se passe-t-il si on appelle `multiplier(0, 100)` ? Ajoute ce cas à tes tests.

Veux-tu que je te laisse essayer d'abord, ou que je te montre une solution ensuite pour comparer ?
