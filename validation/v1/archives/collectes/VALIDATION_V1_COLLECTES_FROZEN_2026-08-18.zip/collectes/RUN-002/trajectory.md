## USER

Explique les décorateurs Python à un développeur adulte qui travaille sur une application de réservation.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-002/.claude/skills/tuteur-ingenierie-pedagogique/references/andragogie.md

## ASSISTANT

Avant de foncer dans la théorie : dans ton appli de réservation, qu'est-ce que tu appellerais un "décorateur", avec tes mots — et as-tu déjà un endroit où tu te dis "je répète cette vérification (genre l'authentification avant une réservation, ou un log d'appel) sur plusieurs fonctions" ?

Ça m'aide à savoir si on part de zéro ou si tu as déjà une intuition à corriger/affiner, et ça me donne un vrai cas de ton code sur lequel raccrocher l'explication plutôt qu'un exemple abstrait.

Pendant que tu réponds, voici déjà le *pourquoi* concret : dans une appli de réservation, tu as sans doute des besoins transverses — vérifier qu'un utilisateur est connecté avant de créer une réservation, logger chaque appel à l'API de paiement, mesurer le temps de réponse d'une recherche de disponibilité, ou empêcher deux requêtes concurrentes de réserver le même créneau. Sans décorateur, tu dupliques ce code dans chaque fonction (`creer_reservation`, `annuler_reservation`, `modifier_reservation`...). Un décorateur te permet d'écrire cette logique une fois et de l'"agrafer" sur n'importe quelle fonction avec juste une ligne au-dessus :

```python
@requiert_authentification
def creer_reservation(utilisateur, chambre, dates):
    ...
```

Dis-moi ce que tu en penses / ton exemple, et on construit à partir de là plutôt que je te sorte le cours complet fonction-qui-prend-une-fonction.
