## USER

Je suis développeur PHP et je veux apprendre les décorateurs Python.
Commence la séance.

## ASSISTANT

Bonjour ! On va apprendre les décorateurs Python en partant de ce que tu connais déjà en PHP.

Petite question pour caler le point de départ : en PHP, tu as déjà utilisé des choses comme les **attributs** (`#[Route(...)]` par exemple avec Symfony), ou codé des **middlewares** ? Ça te donnera une intuition proche, même si techniquement un décorateur Python est différent (il enveloppe une fonction, alors qu'un attribut PHP est juste une métadonnée).

Voici le concept de base, en partant de zéro :

En Python, les fonctions sont des **objets de première classe** — tu peux les passer en argument, les retourner, les stocker dans une variable, comme n'importe quelle valeur (un peu comme les closures/`Closure` en PHP, ou les callables).

Un décorateur, c'est juste une fonction qui :
1. prend une fonction en argument,
2. retourne une nouvelle fonction qui "enveloppe" l'originale (ajoute du comportement avant/après),
3. et qu'on applique avec la syntaxe `@mon_decorateur` au-dessus d'une définition de fonction.

```python
def mon_decorateur(fonction):
    def wrapper(*args, **kwargs):
        print("Avant l'appel")
        resultat = fonction(*args, **kwargs)
        print("Après l'appel")
        return resultat
    return wrapper

@mon_decorateur
def dire_bonjour(nom):
    print(f"Bonjour {nom}")

dire_bonjour("David")
```

C'est strictement équivalent à écrire :
```python
dire_bonjour = mon_decorateur(dire_bonjour)
```

C'est tout le secret : `@decorateur` au-dessus d'une fonction n'est qu'un sucre syntaxique pour "réassigne cette fonction avec la valeur de retour du décorateur appliqué à elle-même".

**Question pour continuer** : veux-tu que je te montre tout de suite un cas d'usage concret (genre logging, mesure de temps, vérification d'authentification — proche d'un middleware), ou tu préfères qu'on décortique d'abord en détail ce que fait exactement le code ci-dessus (le `wrapper`, `*args, **kwargs`, la fermeture) avant d'avancer ?
