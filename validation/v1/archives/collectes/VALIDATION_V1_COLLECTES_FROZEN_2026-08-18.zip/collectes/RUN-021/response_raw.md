# Atelier asynchrone — Tests unitaires en Python

## Objectif
Permettre aux participants d'apprendre à écrire des tests unitaires robustes en Python (avec `unittest` et `pytest`), à leur rythme, sur une période de **2 semaines**, avec des jalons de validation asynchrones (pas de session live obligatoire).

## Public visé
Développeurs Python ayant des bases (fonctions, classes, modules) mais peu ou pas d'expérience en tests automatisés.

## Format
- 100% asynchrone : contenu écrit + vidéos courtes + exercices à rendre via dépôt Git (PR).
- Un canal Slack/Discord dédié pour les questions, avec réponse sous 24h.
- Un mentor relit les PR et laisse des commentaires (pas de correction "magistrale").

---

## Structure (4 modules, ~2-3h chacun)

### Module 1 — Pourquoi et comment tester
- Contenu : pyramide des tests, anatomie d'un test (`arrange / act / assert`), `unittest` vs `pytest`.
- Exercice : écrire 5 tests simples avec `pytest` sur une fonction fournie (ex : calcul de TVA).
- Livrable : PR avec les tests + passage en CI (GitHub Actions fourni en template).

### Module 2 — Fixtures et paramétrage
- Contenu : `@pytest.fixture`, portée (`scope`), `@pytest.mark.parametrize`, `setUp`/`tearDown` côté `unittest`.
- Exercice : refactorer une suite de tests répétitifs en utilisant fixtures + paramétrage.
- Livrable : PR avec réduction du code dupliqué (mesurée).

### Module 3 — Mocks et isolation
- Contenu : `unittest.mock` (`Mock`, `MagicMock`, `patch`), tester du code avec dépendances externes (API, DB, fichiers, `datetime.now()`).
- Exercice : tester une fonction qui appelle une API externe, sans réseau réel.
- Livrable : PR avec mocks + couverture de cas d'erreur (timeout, 500, réponse invalide).

### Module 4 — Couverture, TDD et bonnes pratiques
- Contenu : `pytest-cov`, lecture d'un rapport de couverture, introduction au TDD (red-green-refactor), anti-patterns (tests fragiles, tests qui testent l'implémentation).
- Exercice final : choisir une fonction non testée dans un mini-projet fourni, viser 90%+ de couverture en TDD.
- Livrable : PR finale + courte rétro écrite (3-5 lignes : ce qui a été difficile, ce qui a changé dans leur façon de coder).

---

## Jalons et rythme suggéré
| Jour | Action |
|---|---|
| J1 | Kickoff écrit (email/Slack) + accès repo + Module 1 |
| J4 | Deadline PR Module 1 |
| J7 | Module 2 + 3 disponibles, deadline PR Module 2 |
| J10 | Deadline PR Module 3 |
| J13 | Module 4 |
| J15 | Deadline PR finale + rétro |

## Matériel à préparer
- Un dépôt Git template avec structure de projet, CI configurée (`pytest` + `pytest-cov`), et un mini-projet volontairement peu testé pour le module 4.
- 4 courtes vidéos ou capsules écrites (10-15 min de lecture chacune) par module.
- Un canal de questions asynchrone + FAQ qui se construit au fil de l'eau.

## Critères de réussite
- Les 4 PR sont soumises et passent en CI.
- Couverture de code du mini-projet final ≥ 90% sur la fonction ciblée.
- Rétro écrite soumise.

---

Dites-moi si vous voulez que j'ajuste la durée, le niveau (plus avancé : property-based testing avec `hypothesis`, tests d'intégration), ou que je rédige le contenu détaillé d'un module en particulier.
