## USER

Rédige uniquement une fiche de Séance de 45 minutes
sur la validation des données avec Pydantic.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-046/.claude/skills/tuteur-ingenierie-pedagogique/references/seance.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-046/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-046/.claude/skills/tuteur-ingenierie-pedagogique/references/opo.md

## ASSISTANT

# Fiche de Séance — Validation des données avec Pydantic

**Durée : 45 min** | Modalité synchrone | Public : développeurs Python connaissant déjà les classes, les type hints et les dictionnaires (paliers 2-3 attestés sur ces notions)

---

## 1. Intitulé et place dans la séquence

- **Séance amont** : Manipulation des dictionnaires et type hints en Python.
- **Séance aval** : Intégration de Pydantic dans une API (FastAPI) pour valider les requêtes entrantes.

## 2. OPO de la séance (règle des 3C)

> À la fin de la séance, l'apprenant sera capable de **définir** un modèle Pydantic avec des contraintes de validation (Comportement), **à partir d'un cahier des charges de champs donné et sans documentation externe** (Conditions), **de manière à ce que le modèle rejette au moins 3 cas de données invalides fournis en test, avec des messages d'erreur exploités correctement, et accepte tous les cas valides sans lever d'exception** (Critères).

Palier visé : **3. Appliquer** (mettre en œuvre une méthode — ici Pydantic — sur un cas simple dans des conditions définies).

**État des paliers pour cette séance :**

| Notion | Palier attesté avant séance | Palier visé après séance | Preuve |
|---|---|---|---|
| Classes Python, type hints | 3 (prérequis) | inchangé | attesté en séance amont |
| Dictionnaires / structures de données | 2-3 (prérequis) | inchangé | attesté en séance amont |
| `BaseModel` et validation Pydantic | 0 (nouveau) | **3** | activité 2, ci-dessous |

→ Une seule notion non attestée mobilisée dans l'activité évaluée (A3 respecté) : Pydantic. Les classes et type hints sont des prérequis déjà acquis, pas des inconnues.

## 3. Ancrage / Pourquoi (0–5 min)

Démonstration rapide (libre, non évaluée — A1) : montrer un bout de code qui reçoit un dictionnaire venant d'un JSON externe (ex. une commande client avec `age`, `email`), et faire planter le programme en passant une chaîne à la place d'un entier, ou un email malformé. Poser la question : *« Comment être sûr que les données qui entrent dans votre programme sont dans la forme attendue, sans écrire vous-même 15 lignes de `if isinstance(...)` ? »*

## 4. Apport (5–15 min)

**Le problème que résout Pydantic.** En Python, les type hints (`age: int`) ne sont pas vérifiés à l'exécution — ils ne servent qu'à l'outillage (linters, IDE). Rien n'empêche d'instancier un objet avec des données incorrectes. Pydantic transforme ces annotations en contrat vérifié à l'exécution.

**`BaseModel`.** On définit un modèle en héritant de `pydantic.BaseModel` et en déclarant les champs comme des attributs de classe avec type hint :

```python
from pydantic import BaseModel, EmailStr

class Client(BaseModel):
    nom: str
    age: int
    email: EmailStr
```

À l'instanciation (`Client(nom="Ana", age=30, email="ana@ex.com")`), Pydantic :
- vérifie que chaque champ a le bon type,
- **convertit** les types compatibles quand c'est raisonnable (ex. `"30"` → `30`),
- lève une `ValidationError` explicite sinon, listant **tous** les champs en tort d'un coup (pas seulement le premier).

**Champs optionnels et valeurs par défaut** : `remise: float = 0.0` ou `note: str | None = None`.

**Contraintes plus fines** avec `Field` :

```python
from pydantic import Field

class Client(BaseModel):
    nom: str
    age: int = Field(ge=0, le=120)
    email: EmailStr
```

`ge`/`le` (greater/less-or-equal) bornent la valeur. D'autres options existent (`min_length`, `pattern`...) mais ne seront pas creusées ici — l'objectif du jour reste la construction d'un modèle simple et de ses bornes numériques/format de base.

**Lire une erreur** : `ValidationError` expose `.errors()`, une liste structurée (champ, type d'erreur, message) — bien plus exploitable qu'un `try/except ValueError` générique.

## 5. Déroulé minuté

| Minutage | Temps | Palier visé | Rôle du formateur |
|---|---|---|---|
| 0–5 | Ancrage : le dictionnaire qui plante | — (non évalué) | Montre, raconte |
| 5–15 | Apport : `BaseModel`, `Field`, `ValidationError` | — (non évalué) | Expose, fait reformuler |
| 15–25 | Activité 1 — Reformuler : face à 3 modèles Pydantic déjà écrits, dire pour chacun quelles données seraient acceptées/rejetées et pourquoi | 2. Comprendre | Circule, questionne |
| 25–40 | Activité 2 — Écrire un modèle `Commande` (produit: str, quantite: int ≥ 1, prix: float ≥ 0, email_client: EmailStr) à partir du cahier des charges fourni, et le faire passer sur un jeu de données de test (3 cas valides, 3 cas invalides) | 3. Appliquer | Débloque, ne fait pas à la place |
| 40–45 | Reprise collective et transition | — | Synthétise à partir des productions |

**Le minutage est un budget, pas un script** : si l'Activité 1 déborde, la compresser à 5 min plutôt que de rogner sur l'Activité 2, qui porte l'évaluation du palier visé.

## 6. Erreurs fréquentes attendues

- **« Pydantic valide comme un `if`, donc ça remplace mes tests. »** → Reformulation : Pydantic garantit la *forme* des données à l'entrée, pas la logique métier (ex. il ne sait pas qu'une quantité de 10000 est suspecte pour ce client précis). Diagnostic à poser sans « c'est faux » : *« Qu'est-ce que ce modèle vérifierait ici, concrètement, et qu'est-ce qu'il laisserait passer ? »*
- **Oublier que Pydantic convertit silencieusement les types compatibles** (ex. `"30"` accepté comme `int`) et s'étonner qu'une erreur attendue ne se déclenche pas. → Faire tester avec une valeur *vraiment* incompatible (`"trente"`) pour observer la différence.
- **Confondre `Optional[str]` et champ avec valeur par défaut** — un champ optionnel sans défaut reste obligatoire à l'instanciation. Faire lire le message d'erreur exact produit par Pydantic dans ce cas.

## 7. Transition

*« Vous savez maintenant garantir que des données isolées ont la bonne forme avant d'entrer dans votre code. La prochaine séance branche ça sur une vraie route d'API FastAPI : on verra comment Pydantic s'intègre automatiquement à la validation des requêtes HTTP entrantes. »*

---

**Contrôles effectués** : l'activité évaluée (Activité 2) porte une seule notion non attestée (Pydantic/`BaseModel`) ; les prérequis (classes, type hints) sont supposés déjà acquis en amont ; l'évaluation (jeu de données valide/invalide) teste exactement le palier 3 (Appliquer), ni la conception d'un système complet (palier 6) ni la simple identification de syntaxe (palier 1).
