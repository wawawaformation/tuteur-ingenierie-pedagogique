## USER

L'apprenant n'a jamais vu les décorateurs Python.
Montre-lui un exemple concret de décorateur déjà écrit et explique ce qu'il fait.
Ne lui demande pas de produire du code.

## TOOL Skill

tuteur-ingenierie-pedagogique

## ASSISTANT

Voici un décorateur concret, avec une explication du mécanisme derrière.

## Le problème qu'il résout

Imagine que tu as plusieurs fonctions et que tu veux savoir combien de temps chacune met à s'exécuter, sans réécrire le code de chronométrage à chaque fois.

## Le code

```python
import time

def chrono(fonction):
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = fonction(*args, **kwargs)
        fin = time.time()
        print(f"{fonction.__name__} a mis {fin - debut:.4f} secondes")
        return resultat
    return wrapper


@chrono
def calculer_carres(n):
    return [i**2 for i in range(n)]


calculer_carres(1_000_000)
```

Sortie :
```
calculer_carres a mis 0.0812 secondes
```

## Ce qui se passe réellement

La ligne `@chrono` juste au-dessus de `def calculer_carres` est un raccourci. Elle est **strictement équivalente** à ceci :

```python
def calculer_carres(n):
    return [i**2 for i in range(n)]

calculer_carres = chrono(calculer_carres)
```

Autrement dit :

1. `chrono` est une fonction normale qui **prend une fonction en argument** (`fonction`, ici `calculer_carres`) et **retourne une nouvelle fonction** (`wrapper`).
2. `wrapper` est la fonction qui va réellement s'exécuter à la place de `calculer_carres`. Elle fait trois choses : elle note l'heure de départ, elle appelle la fonction originale (`fonction(*args, **kwargs)`), puis elle affiche le temps écoulé.
3. Après `@chrono`, le nom `calculer_carres` ne pointe plus vers la fonction d'origine, mais vers `wrapper`. Quand tu appelles `calculer_carres(1_000_000)`, c'est en fait `wrapper(1_000_000)` qui s'exécute, et c'est *lui* qui appelle la vraie fonction à l'intérieur.

Le `*args, **kwargs` dans `wrapper` sert à ce que le décorateur fonctionne avec **n'importe quelle** fonction, quels que soient ses arguments — `wrapper` se contente de les transmettre tels quels à `fonction`.

## L'idée à retenir

Un décorateur ne modifie pas le code d'une fonction. Il l'**enveloppe** dans une autre fonction qui peut exécuter du code avant et/ou après l'appel original, sans que la fonction décorée ait besoin de le savoir. C'est pour ça qu'on peut mettre `@chrono` sur n'importe quelle fonction et obtenir le chronométrage gratuitement, sans toucher à son corps.
