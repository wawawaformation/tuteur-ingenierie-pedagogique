## USER

Explique les décorateurs Python à un développeur adulte qui travaille sur une application de réservation.

## ASSISTANT

Les décorateurs, c'est du sucre syntaxique pour envelopper une fonction dans une autre fonction, sans toucher au code de la fonction originale. Utile pour ajouter un comportement transversal (logging, auth, cache, retry...) à plusieurs endroits sans dupliquer le code.

## Le mécanisme de base

```python
def mon_decorateur(func):
    def wrapper(*args, **kwargs):
        # code avant l'appel
        resultat = func(*args, **kwargs)
        # code après l'appel
        return resultat
    return wrapper

@mon_decorateur
def ma_fonction():
    ...
```

`@mon_decorateur` au-dessus de `ma_fonction` équivaut à écrire `ma_fonction = mon_decorateur(ma_fonction)`. C'est tout — pas de magie.

## Exemples concrets pour une appli de réservation

**1. Logger les appels sur les réservations**

```python
import functools
import time

def log_appel(func):
    @functools.wraps(func)  # préserve __name__, docstring, etc.
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = func(*args, **kwargs)
        print(f"{func.__name__} exécuté en {time.time() - debut:.3f}s")
        return resultat
    return wrapper

@log_appel
def creer_reservation(client_id, date, salle):
    ...
```

`functools.wraps` est important : sans lui, `creer_reservation.__name__` deviendrait `"wrapper"`, ce qui casse l'introspection, les frameworks web, la doc auto-générée, etc. Toujours l'utiliser.

**2. Vérifier une authentification / autorisation**

```python
def authentifie(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if not utilisateur_courant_est_connecte():
            raise PermissionError("Connexion requise")
        return func(*args, **kwargs)
    return wrapper

@authentifie
def annuler_reservation(reservation_id):
    ...
```

**3. Décorateur avec paramètres (un décorateur qui prend des arguments)**

C'est un niveau d'imbrication en plus : une fonction qui retourne un décorateur.

```python
def retry(max_tentatives=3):
    def decorateur(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for tentative in range(max_tentatives):
                try:
                    return func(*args, **kwargs)
                except ConnexionAPIError:
                    if tentative == max_tentatives - 1:
                        raise
        return wrapper
    return decorateur

@retry(max_tentatives=5)
def confirmer_paiement(reservation_id):
    ...
```

**4. Empêcher les double-réservations (verrou)**

```python
from threading import Lock
_verrou = Lock()

def transaction_atomique(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        with _verrou:
            return func(*args, **kwargs)
    return wrapper

@transaction_atomique
def reserver_creneau(salle_id, creneau):
    ...
```

## Décorateurs intégrés utiles ici

- `@property` — exposer un calcul (ex: `duree_restante`) comme un attribut
- `@staticmethod` / `@classmethod` — méthodes utilitaires liées à une classe `Reservation`
- `@lru_cache` (functools) — cacher les résultats coûteux, ex. disponibilités calculées

```python
from functools import lru_cache

@lru_cache(maxsize=128)
def disponibilites_salle(salle_id, date):
    ...  # requête coûteuse
```

⚠️ Attention avec `lru_cache` sur des données qui changent (disponibilités) — il faut invalider le cache ou fixer une TTL, sinon on sert des données périmées.

## Cumuler plusieurs décorateurs

```python
@authentifie
@log_appel
@retry(max_tentatives=3)
def payer_reservation(reservation_id, montant):
    ...
```

Ils s'appliquent de bas en haut (le plus proche de la fonction s'exécute en premier). Ici : retry englobe la fonction, log_appel englobe retry, authentifie englobe le tout.

Point clé à retenir : un décorateur ne modifie pas le code source, il ajoute un comportement autour. C'est ce qui le rend idéal pour factoriser des préoccupations transversales (auth, logs, retry, cache, transactions) sans polluer la logique métier de réservation.
