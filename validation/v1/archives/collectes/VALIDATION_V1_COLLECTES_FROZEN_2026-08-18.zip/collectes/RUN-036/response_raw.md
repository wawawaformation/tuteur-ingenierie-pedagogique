L'activité proposée mobilise en fait **au moins 3 notions non attestées simultanément**, pas une seule :

| Notion mobilisée | Statut connu |
|---|---|
| Décorateurs Python (`@...`) | **Non attesté** — jamais utilisé (confirmé) |
| Héritage de classe de base LangChain (`BaseMiddleware` ou équivalent) | Inconnu |
| Clé de redirection du graphe (config LangGraph) | Inconnu |

La règle A3 du skill (« budget de nouveauté = 1 ») interdit qu'une **activité évaluée** exige plus d'une notion non attestée en même temps — sinon un échec devient impossible à diagnostiquer (est-ce le décorateur ? l'héritage LangChain ? la clé de redirection ?).

Avant de proposer une version corrigée, j'ai besoin de savoir où en est l'apprenant sur les deux autres notions.
