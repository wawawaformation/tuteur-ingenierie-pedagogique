## USER

Rédige uniquement une fiche de Séance de 45 minutes
sur la validation des données avec Pydantic.

## ASSISTANT

# Fiche de Séance – Validation des données avec Pydantic

**Durée totale : 45 minutes**
**Public visé :** développeurs Python ayant des bases (fonctions, classes, type hints)
**Prérequis :** Python 3.9+, notions de POO, notions de type hints

---

## Objectifs pédagogiques

À la fin de la séance, les apprenants seront capables de :
- Comprendre le rôle de Pydantic dans la validation et la sérialisation de données
- Définir des modèles de données avec des types et des contraintes
- Gérer les erreurs de validation
- Utiliser des validateurs personnalisés simples

---

## Déroulé de la séance

### 1. Introduction et mise en contexte (5 min)
- Pourquoi valider des données (API, formulaires, fichiers de config) ?
- Problèmes classiques sans validation : erreurs silencieuses, types incohérents, crashs en production
- Présentation rapide de Pydantic : bibliothèque de validation basée sur les type hints Python

### 2. Démonstration : premier modèle Pydantic (10 min)
- Installation (`pip install pydantic`)
- Création d'un modèle simple avec `BaseModel` :
```python
from pydantic import BaseModel

class Utilisateur(BaseModel):
    nom: str
    age: int
    email: str
```
- Instanciation avec des données valides et invalides
- Observation du message d'erreur (`ValidationError`) et de sa structure

### 3. Exercice guidé : contraintes et champs avancés (10 min)
- Ajout de contraintes avec `Field` (valeurs min/max, longueur de chaîne, valeur par défaut)
```python
from pydantic import BaseModel, Field

class Produit(BaseModel):
    nom: str = Field(min_length=2)
    prix: float = Field(gt=0)
    quantite: int = Field(ge=0, default=0)
```
- Les apprenants testent avec des données correctes/incorrectes et interprètent les erreurs

### 4. Exercice pratique en autonomie (12 min)
- Consigne : créer un modèle `Commande` avec :
  - un `id` entier positif
  - une liste de `Produit` (réutilisation du modèle précédent)
  - une date de commande (type `date`)
  - un champ `statut` limité à un ensemble de valeurs (via `Enum` ou `Literal`)
- Tester la validation avec un JSON d'exemple (`Commande.model_validate(...)` ou `parse_obj`)
- Circulation du formateur pour aide individuelle

### 5. Validateurs personnalisés (5 min)
- Introduction rapide à `@field_validator` (Pydantic v2)
```python
from pydantic import field_validator

class Utilisateur(BaseModel):
    email: str

    @field_validator("email")
    @classmethod
    def valider_email(cls, v):
        if "@" not in v:
            raise ValueError("Email invalide")
        return v
```
- Cas d'usage : validation métier au-delà du typage simple

### 6. Synthèse et conclusion (3 min)
- Rappel des points clés : `BaseModel`, `Field`, `ValidationError`, validateurs personnalisés
- Cas d'usage réels : FastAPI, configuration d'application, ingestion de données
- Questions/réponses

---

## Matériel nécessaire
- Environnement Python avec Pydantic installé (v2 recommandée)
- Éditeur de code / notebook
- Jeux de données d'exemple (JSON valides/invalides) préparés à l'avance

## Modalité d'évaluation
- Observation de l'exercice pratique en autonomie (étape 4)
- Vérification orale de la compréhension des messages d'erreur
