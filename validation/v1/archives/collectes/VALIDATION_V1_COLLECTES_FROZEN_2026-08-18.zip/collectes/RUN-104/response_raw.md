I now have everything I need. Let me produce the activity directly in the conversation, per the user's global CLAUDE.md instruction to avoid unnecessary files.

## État des paliers (mobilisé par cette activité)

| Notion | Palier attesté | Preuve |
|---|---|---|
| Écrire des fonctions simples (def, paramètres, retour) | 3 — Appliquer | déclaré acquis par l'énoncé |
| Écrire des tests (assert / test unitaire) | 3 — Appliquer | déclaré acquis par l'énoncé |
| **Fonction qui enveloppe une autre fonction (wrapper avant/après)** | **non attesté** | — cible de cette activité |

Une seule notion nouvelle est mobilisée (clause A3) : le reste (écrire une fonction, écrire un test) est supposé déjà attesté. Palier visé pour cette première attestation : **3 — Appliquer** (mettre en œuvre le mécanisme sur un cas concret et bordé), pas 6 — un premier passage sur une notion neuve ne se cible pas en conception ouverte.

---

## Fiche d'Activité — « Chronomètre de fonction »

### Volet remis à l'apprenant

**1. Intention**
Tu vas construire, seul, le mécanisme qui permet d'ajouter un comportement avant et après l'appel d'une fonction quelconque, sans modifier son code — la brique de base derrière le logging, le chronométrage ou les décorateurs.

**2. Consigne**
Écris une fonction `chronometrer(fonction)` qui **prend une fonction en paramètre** et **retourne une nouvelle fonction**. Quand on appelle cette nouvelle fonction :
- elle affiche `"Début"` avant d'appeler `fonction` ;
- elle appelle `fonction` avec les arguments reçus et récupère son résultat ;
- elle affiche `"Fin"` après l'appel ;
- elle renvoie le résultat original de `fonction`, inchangé.

**3. Matériel de départ**
Une fonction déjà écrite et testée t'est fournie :

```python
def addition(a, b):
    return a + b

def test_addition():
    assert addition(2, 3) == 5
```

**4. Contraintes**
- Tu ne modifies pas `addition`, ni son test existant.
- `chronometrer` doit fonctionner avec `addition(a, b)` tel quel (deux arguments positionnels) — pas besoin de généraliser à un nombre variable d'arguments.
- Pas de bibliothèque tierce ni de syntaxe `@decorateur` : uniquement une fonction qui prend une fonction et en retourne une autre.

**5. Critère de réussite**
`addition_chrono = chronometrer(addition)` puis `addition_chrono(2, 3)` affiche `Début` puis `Fin` sur deux lignes et renvoie `5` — et le test `test_addition()` d'origine continue de passer sans modification.

---

### Volet formateur

**1. Palier visé** : 3 — Appliquer.

**2. Notion nouvelle (A3)** : la fonction d'ordre supérieur qui **enveloppe** une fonction reçue en paramètre et **retourne une fonction interne** (closure) exécutant avant/appel/après. Tout le reste (`def`, `return`, `assert`) est présumé attesté.

**3. Production attendue**

```python
def chronometrer(fonction):
    def enveloppe(*args, **kwargs):
        print("Début")
        resultat = fonction(*args, **kwargs)
        print("Fin")
        return resultat
    return enveloppe
```

**4. Critères d'acceptation** (font passer la ligne « fonction enveloppante » à attesté dans l'état des paliers, rien de plus large) :
- `chronometrer` retourne bien une fonction (pas le résultat direct de l'appel).
- La fonction retournée appelle effectivement la fonction d'origine et propage son résultat sans le modifier.
- L'ordre d'affichage est respecté : `Début` avant l'appel, `Fin` après.
- `test_addition()` passe toujours, preuve que `addition` n'a pas été touchée.

**5. Erreur fréquente attendue et sa reformulation**
Erreur probable : écrire `chronometrer` qui **appelle** `fonction` tout de suite et retourne le résultat, au lieu de retourner une nouvelle fonction.
Diagnostic à poser (jamais « c'est faux ») : *« Que se passe-t-il si tu appelles `chronometrer(addition)` sans jamais rappeler ce qu'elle te renvoie — est-ce que `addition` a été exécutée quand même ? »* — cette question fait voir que la version fautive exécute immédiatement au lieu de préparer un appel différé.

---

Cette activité isole une seule inconnue (le wrapping) pour rester diagnostique : si l'apprenant échoue, on sait que c'est sur cette notion précise, pas sur `def` ou `assert`.
