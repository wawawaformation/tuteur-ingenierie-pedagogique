Avant de proposer l'activité, j'applique A2 (énumérer les notions mobilisées et leur palier) et A3 (une seule notion non attestée). Je pose une hypothèse de départ sur l'état des paliers — à corriger si elle ne correspond pas à l'apprenant réel.

## État des paliers (hypothèse à valider)

| Notion | Palier attesté | Preuve |
|---|---|---|
| Définir et appeler une fonction Python | 3 — Appliquer | *(supposé acquis — à confirmer)* |
| Lire/comprendre ce qu'est un décorateur (concept, à quoi ça sert) | 2 — Comprendre | *(exposé au préalable, activité libre selon A1)* |
| **Appliquer la syntaxe `@decorateur` à une fonction existante** | **non attesté** | — notion visée par cette activité |

Une seule notion non attestée mobilisée : l'application syntaxique d'un décorateur. Tout le reste (écrire/appeler une fonction, notion de « qu'est-ce qu'un décorateur ») est supposé déjà acquis ou vu en exposition libre — conforme à A3.

---

## Fiche d'Activité — Appliquer un décorateur existant

### Volet remis à l'apprenant

**Intention** : Voir comment on branche un comportement supplémentaire (ici, mesurer un temps d'exécution) sur une fonction sans toucher à son code.

**Consigne** : Applique le décorateur `@chronometre` fourni ci-dessous à la fonction `calculer_total`, pour que son temps d'exécution s'affiche automatiquement à chaque appel.

**Matériel de départ** :

```python
import time

def chronometre(fonction):
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = fonction(*args, **kwargs)
        print(f"Temps d'exécution : {time.time() - debut:.6f} s")
        return resultat
    return wrapper

def calculer_total(prix, quantite):
    return prix * quantite

print(calculer_total(19.90, 3))
```

**Contraintes** :
- Tu ne modifies ni le corps de `calculer_total`, ni le code de `chronometre`.
- Tu n'appelles pas `chronometre` manuellement (pas de `calculer_total = chronometre(calculer_total)`) : utilise la syntaxe `@`.
- Le reste du script reste inchangé.

**Critère de réussite** : Quand tu exécutes le script, le message du temps d'exécution s'affiche juste avant le résultat de `calculer_total`, sans erreur.

---

### Volet conservé par le formateur

**Palier visé** : 3 — Appliquer (mettre en œuvre une syntaxe apprise sur un cas simple).

**Notion nouvelle (A3)** : la syntaxe `@decorateur` placée juste au-dessus d'une définition de fonction, comme raccourci de `fonction = decorateur(fonction)`.

**Production attendue** :

```python
import time

def chronometre(fonction):
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = fonction(*args, **kwargs)
        print(f"Temps d'exécution : {time.time() - debut:.6f} s")
        return resultat
    return wrapper

@chronometre
def calculer_total(prix, quantite):
    return prix * quantite

print(calculer_total(19.90, 3))
```

**Critères d'acceptation** (font passer la ligne « application syntaxique d'un décorateur » à attesté) :
- `@chronometre` est placé immédiatement au-dessus de `def calculer_total`.
- Le corps de `calculer_total` et le code de `chronometre` sont inchangés.
- Le script s'exécute sans erreur et affiche le temps d'exécution avant `59.7`.

**Erreur fréquente attendue et sa reformulation** :
- Erreur probable : écrire `calculer_total = chronometre(calculer_total)` sous la fonction au lieu d'utiliser `@chronometre` au-dessus.
- Reformulation à l'oral (jamais « c'est faux ») : *« Ta ligne fonctionne, mais regarde où le décorateur est écrit dans le script fourni au-dessus d'autres fonctions — à quel endroit exactement, et par rapport à quoi ? »*

---

Cette fiche suppose que la notion de fonction est déjà attestée et que le concept de décorateur a été vu en exposition libre. Dites-moi si l'un des deux n'est pas encore le cas : je décompose alors en une étape supplémentaire avant celle-ci.
