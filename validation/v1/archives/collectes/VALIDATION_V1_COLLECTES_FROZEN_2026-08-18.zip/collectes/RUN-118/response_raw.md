Voici un exercice de 15 minutes sur les décorateurs Python, pensé pour des développeurs adultes déjà à l'aise avec les fonctions.

## Exercice : décorateur de chronométrage (`@timer`)

**Objectif (15 min) :** écrire un décorateur qui mesure et affiche le temps d'exécution d'une fonction, sans modifier son comportement.

### Contexte
Vous avez une fonction lente :

```python
import time

def calcul_lourd(n):
    total = 0
    for i in range(n):
        total += i ** 2
    return total

print(calcul_lourd(1_000_000))
```

### Étape 1 — (5 min) : décorateur basique
Écrivez un décorateur `timer` qui affiche le temps d'exécution de la fonction décorée, sans utiliser `functools.wraps` pour l'instant.

```python
def timer(func):
    def wrapper(*args, **kwargs):
        # TODO: chronométrer l'appel à func et afficher le résultat
        pass
    return wrapper

@timer
def calcul_lourd(n):
    total = 0
    for i in range(n):
        total += i ** 2
    return total

calcul_lourd(1_000_000)
```

Attendu : un affichage du type `calcul_lourd exécutée en 0.087s`, et la fonction doit toujours renvoyer sa valeur normalement.

### Étape 2 — (5 min) : préserver les métadonnées
Testez `calcul_lourd.__name__` et `calcul_lourd.__doc__` après décoration. Vous allez constater qu'ils sont "cassés" (ils pointent vers `wrapper`). Corrigez avec `functools.wraps`.

### Étape 3 — (5 min) : décorateur paramétrable
Transformez `timer` en `@timer(unit="ms")` qui affiche le résultat en millisecondes ou secondes selon le paramètre. Indice : il faut une fonction supplémentaire qui englobe le décorateur (un décorateur qui retourne un décorateur).

### Solution (à ne révéler qu'à la fin)

```python
import time
import functools

def timer(unit="s"):
    def decorateur(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            debut = time.perf_counter()
            resultat = func(*args, **kwargs)
            duree = time.perf_counter() - debut
            if unit == "ms":
                print(f"{func.__name__} exécutée en {duree*1000:.2f}ms")
            else:
                print(f"{func.__name__} exécutée en {duree:.4f}s")
            return resultat
        return wrapper
    return decorateur

@timer(unit="ms")
def calcul_lourd(n):
    total = 0
    for i in range(n):
        total += i ** 2
    return total

calcul_lourd(1_000_000)
print(calcul_lourd.__name__)  # "calcul_lourd", pas "wrapper"
```

### Points pédagogiques à souligner en debrief
- Un décorateur est une fonction qui prend une fonction et en renvoie une autre.
- `*args, **kwargs` permet de décorer n'importe quelle fonction, peu importe sa signature.
- `functools.wraps` évite de perdre l'identité de la fonction originale (important pour le debug, l'introspection, les frameworks comme Flask/FastAPI qui utilisent `__name__`).
- Un décorateur "paramétrable" ajoute un niveau d'imbrication supplémentaire (usine à décorateurs).

Voulez-vous une variante plus difficile (ex. décorateur de cache, ou décorateur de classe) ou une version avec des trous à compléter type QCM ?
