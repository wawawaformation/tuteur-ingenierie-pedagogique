# Activité évaluée : Ajouter un décorateur à une fonction existante

## Contexte
Vous disposez d'une fonction déjà fonctionnelle. Votre mission : lui ajouter un décorateur Python qui affiche le temps d'exécution de la fonction, **sans modifier le code de la fonction elle-même**.

## Code de départ

```python
import time

def calculer_somme(n):
    """Calcule la somme des entiers de 1 à n."""
    total = 0
    for i in range(1, n + 1):
        total += i
    return total

# Appel de test
resultat = calculer_somme(1000000)
print(f"Résultat : {resultat}")
```

## Consigne

1. Écrivez un décorateur nommé `chronometre` qui :
   - mesure le temps d'exécution de la fonction décorée (utilisez `time.time()` ou `time.perf_counter()`) ;
   - affiche un message du type : `Temps d'exécution de calculer_somme : 0.0421s` ;
   - retourne bien le résultat de la fonction décorée (le programme doit toujours pouvoir utiliser `resultat`).
2. Appliquez ce décorateur à `calculer_somme` avec la syntaxe `@chronometre`, **sans modifier le corps de `calculer_somme`**.
3. Le programme doit toujours afficher `Résultat : ...` après l'affichage du temps.

## Critères d'évaluation

| Critère | Points |
|---|---|
| Le décorateur utilise `*args, **kwargs` pour rester générique | 2 |
| Le décorateur retourne la valeur de la fonction décorée | 3 |
| Le temps d'exécution est correctement mesuré et affiché | 3 |
| `calculer_somme` n'est pas modifiée, seule la décoration est ajoutée | 2 |
| **Total** | **10** |

## Contrainte
Ne pas utiliser `functools.wraps` n'est pas pénalisé ici (niveau débutant), mais vous pouvez l'ajouter en bonus (+1 point) pour préserver `__name__` et `__doc__`.

---

## Corrigé (à ne fournir qu'après la remise des copies)

```python
import time
from functools import wraps

def chronometre(fonction):
    @wraps(fonction)
    def wrapper(*args, **kwargs):
        debut = time.perf_counter()
        resultat = fonction(*args, **kwargs)
        fin = time.perf_counter()
        print(f"Temps d'exécution de {fonction.__name__} : {fin - debut:.4f}s")
        return resultat
    return wrapper

@chronometre
def calculer_somme(n):
    """Calcule la somme des entiers de 1 à n."""
    total = 0
    for i in range(1, n + 1):
        total += i
    return total

resultat = calculer_somme(1000000)
print(f"Résultat : {resultat}")
```

Voulez-vous une variante (autre fonction de départ, décorateur de logging plutôt que de chronométrage, niveau plus avancé avec `functools.wraps` obligatoire) ?
