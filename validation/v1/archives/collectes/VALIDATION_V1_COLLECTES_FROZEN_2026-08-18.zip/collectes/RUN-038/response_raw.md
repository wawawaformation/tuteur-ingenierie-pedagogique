# Atelier asynchrone — Écrire ses premiers tests unitaires en Python

**Palier visé : 3 — Appliquer** (mettre en œuvre une méthode sur un cas simple, dans des conditions définies).

**Notion non attestée mobilisée (budget A3 = 1)** : écrire des tests unitaires avec `pytest` (fonctions `test_*`, assertions, cas nominal / cas limite / cas d'erreur).

**Prérequis supposés déjà attestés** (sinon, redécouper avant de proposer cet atelier) :
- écrire une fonction Python avec paramètres et valeur de retour ;
- utiliser des structures conditionnelles simples ;
- lire un message d'erreur dans un terminal.

---

## 1. Documents fournis

- Un fichier `calculatrice.py` contenant 3 fonctions déjà écrites et fonctionnelles : `diviser(a, b)`, `appliquer_remise(prix, pourcentage)`, `moyenne(liste_notes)`.
- Un fichier vide `test_calculatrice.py`, avec en commentaire un unique exemple de test déjà rempli pour la fonction `diviser` (cas nominal seulement).
- Un lien vers la documentation officielle de `pytest` (section "Getting started").

## 2. Objectifs de l'atelier

- Identifier, pour une fonction donnée, un cas nominal, un cas limite et un cas d'erreur.
- Écrire des fonctions de test avec `pytest` en utilisant `assert`.
- Exécuter une suite de tests et interpréter un résultat d'échec.

## 3. Durée estimée

Entre 1h30 et 2h30. Cette fourchette est indicative : elle dépend de votre aisance avec les cas limites, pas d'un chronomètre à respecter. Si vous dépassez largement 2h30, c'est un signal pour vous arrêter et en parler, pas un échec.

## 4. Organisation et outils

Vous êtes libre d'utiliser l'éditeur, le terminal et l'environnement Python de votre choix. Le seul prérequis technique est d'avoir `pytest` installé (`pip install pytest`) et de pouvoir exécuter `pytest test_calculatrice.py` depuis un terminal.

## 5. Méthode proposée

1. Lisez les 3 fonctions de `calculatrice.py` et, pour chacune, notez sur une feuille à part (pas dans le code) : un cas nominal, un cas limite, un cas qui devrait provoquer une erreur.
2. Reprenez l'exemple déjà fourni pour `diviser` : exécutez-le tel quel avec `pytest` pour vérifier que votre environnement fonctionne.
3. Complétez `diviser` avec les tests du cas limite (ex. `b = 0`) et du cas d'erreur que vous avez identifiés à l'étape 1.
4. Répétez la démarche des étapes 1 et 3 pour `appliquer_remise` puis pour `moyenne` : un test par cas repéré, sous forme d'une fonction `test_...` distincte.
5. Exécutez l'ensemble avec `pytest test_calculatrice.py -v` et corrigez vos tests jusqu'à ce que le résultat corresponde à ce que vous attendiez de chaque cas.

## 6. Ce qui est supposé par défaut

- Une fonction "en erreur" est une fonction qui doit lever une exception (par exemple `ZeroDivisionError` pour une division par zéro) : on considère ce comportement comme correct, pas comme un bug à corriger dans `calculatrice.py`.
- `moyenne` reçoit toujours une liste non vide dans les cas nominal et limite ; le cas d'erreur à tester est précisément la liste vide.
- Vous n'êtes pas censé modifier le code de `calculatrice.py` : seul `test_calculatrice.py` évolue.

## 7. Livrable attendu

- Le fichier `test_calculatrice.py` complété, contenant au moins 3 fonctions de test par fonction testée (nominal, limite, erreur), soit 9 fonctions de test au minimum.
- Une capture d'écran ou une copie du terminal montrant l'exécution de `pytest test_calculatrice.py -v` avec le résultat (tous les tests passent, ou vous expliquez en une phrase pourquoi l'un échoue encore).

## 8. Critère simple

Si, en lisant vos fonctions de test sans regarder `calculatrice.py`, une personne comprend ce que chaque fonction est censée faire dans le cas testé, et que `pytest` confirme que ce comportement est bien celui observé, c'est gagné.

---

### Callouts à inclure dans la fiche remise

> 💡 **Bon à savoir** — Le fichier fourni contient volontairement un seul exemple de test rempli, pas un modèle pour chaque fonction : c'est à vous d'identifier les cas pour les deux fonctions restantes, c'est l'objet de l'atelier.

> ⚠️ **Vigilance** — On ne cherche pas ici à corriger ou améliorer `calculatrice.py`. Si vous repérez un vrai bug, notez-le à part : il ne fait pas partie du livrable de cet atelier.

---

### Conservé côté formateur (ne pas remettre à l'apprenant)

**Production attendue** : 9 fonctions de test minimum, correctement nommées (`test_diviser_nominal`, `test_diviser_par_zero`, etc.), chacune avec au moins une assertion pertinente au cas visé.

**Grille de correction** :
| Critère | Attendu |
|---|---|
| Couverture des cas | Nominal, limite et erreur présents pour les 3 fonctions |
| Justesse des assertions | L'assertion vérifie effectivement le comportement attendu (pas un `assert True`) |
| Gestion du cas d'erreur | Utilisation de `pytest.raises` ou équivalent pour les exceptions attendues |
| Exécution | La suite s'exécute sans erreur de syntaxe, résultat interprété correctement par l'apprenant |

---

Dites-moi si l'apprenant à qui cet atelier est destiné a déjà un niveau différent sur les prérequis supposés (fonctions, conditions), pour que j'ajuste le budget de nouveauté en conséquence.
