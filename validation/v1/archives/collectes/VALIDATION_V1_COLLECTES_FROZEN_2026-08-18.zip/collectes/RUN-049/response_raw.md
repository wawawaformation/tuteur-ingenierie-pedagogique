Avant de concevoir cette activité, il y a une tension à signaler avec les règles pédagogiques que je dois respecter (`references/taxonomie.md`, clause A3) :

**Une activité évaluée ne peut mobiliser qu'une seule notion non maîtrisée.** Or vous demandez de combiner FastAPI, SQLAlchemy, Pydantic, async et Docker pour un **débutant**, en une **seule activité évaluée**. Si ces 5 notions sont toutes nouvelles pour l'apprenant, l'activité mobilise 5 inconnues simultanées — en cas d'échec, impossible de savoir laquelle en est la cause. Ce n'est plus une activité qui prouve une compétence, c'est un coup de dés.

Deux clarifications me permettraient de construire quelque chose qui reste utile pédagogiquement :
