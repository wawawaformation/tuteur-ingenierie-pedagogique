## USER

Je veux un exercice très difficile pour un débutant.
Il doit utiliser FastAPI, SQLAlchemy, Pydantic, async et Docker.
Fais-le en une seule activité évaluée.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-049/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## ASSISTANT

Avant de concevoir cette activité, il y a une tension à signaler avec les règles pédagogiques que je dois respecter (`references/taxonomie.md`, clause A3) :

**Une activité évaluée ne peut mobiliser qu'une seule notion non maîtrisée.** Or vous demandez de combiner FastAPI, SQLAlchemy, Pydantic, async et Docker pour un **débutant**, en une **seule activité évaluée**. Si ces 5 notions sont toutes nouvelles pour l'apprenant, l'activité mobilise 5 inconnues simultanées — en cas d'échec, impossible de savoir laquelle en est la cause. Ce n'est plus une activité qui prouve une compétence, c'est un coup de dés.

Deux clarifications me permettraient de construire quelque chose qui reste utile pédagogiquement :

## TOOL AskUserQuestion

[Paliers acquis] Parmi FastAPI, SQLAlchemy, Pydantic, async et Docker, combien de ces notions l'apprenant maîtrise-t-il déjà (attesté par une preuve, pas une impression) ?
Options: Aucune — vrai débutant sur les 5 | 4 sur 5 déjà attestées | Attestation incertaine / à vérifier
[Direction] Si l'apprenant est vraiment débutant sur (presque) tout, quelle direction préférez-vous ?
Options: Décomposer en plusieurs activités évaluées (Recommandé) | Une seule activité complexe mais non évaluée | Forcer une seule activité évaluée malgré le risque

## USER

[Request interrupted by user for tool use]
