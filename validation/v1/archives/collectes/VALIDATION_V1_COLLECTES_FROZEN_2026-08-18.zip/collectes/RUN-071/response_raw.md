Voici un quiz d'auto-positionnement à faire passer **avant** une séquence sur les décorateurs Python. Il cible les prérequis réels des décorateurs (fonctions comme objets, fonctions imbriquées, closures, `*args`/`**kwargs`) plutôt que les décorateurs eux-mêmes.

---

## Quiz d'auto-positionnement — Avant les décorateurs

**Intention** : ce quiz sert à repérer ce que tu maîtrises déjà sur les briques qui rendent les décorateurs possibles (fonctions comme objets, fonctions imbriquées, arguments variables), pas à évaluer les décorateurs eux-mêmes. Il n'est pas noté : l'objectif n'est pas de tout réussir, mais d'identifier ce qui est déjà acquis et ce qui mérite d'être approfondi avant de commencer.

---

**Q1.** Que fait ce code ?
```python
def dire_bonjour():
    print("Bonjour")

action = dire_bonjour
action()
```
A) Une erreur, car `action` n'est pas une fonction
B) Affiche "Bonjour"
C) Affiche le mot "action"
D) N'affiche rien, `action` reste une simple référence

**Bonne réponse : B.** En Python, une fonction est un objet comme un autre : `action = dire_bonjour` fait pointer `action` vers le même objet fonction, sans l'appeler (pas de parenthèses). `action()` l'exécute ensuite normalement.

---

**Q2.** Quelle est la différence entre `dire_bonjour` et `dire_bonjour()` ?
A) Aucune, c'est équivalent
B) `dire_bonjour` désigne la fonction elle-même ; `dire_bonjour()` l'exécute et donne son résultat
C) `dire_bonjour()` désigne la fonction ; `dire_bonjour` l'exécute
D) `dire_bonjour` est une erreur de syntaxe

**Bonne réponse : B.** C'est la distinction centrale pour comprendre les décorateurs : on va manipuler des fonctions *sans les appeler*, en passant leur référence.

---

**Q3.** Ce code est-il valide en Python ?
```python
def appliquer(f, valeur):
    return f(valeur)

resultat = appliquer(len, "bonjour")
```
A) Non, on ne peut pas passer une fonction comme argument
B) Oui, et `resultat` vaudra 7
C) Oui, mais `resultat` sera une erreur
D) Non, il faut écrire `f = len` avant

**Bonne réponse : B.** Une fonction peut être passée en argument à une autre fonction, exactement comme un entier ou une chaîne. C'est ce mécanisme (fonction d'ordre supérieur) que les décorateurs exploitent.

---

**Q4.** Que retourne cette fonction quand on l'appelle ?
```python
def creer_multiplicateur():
    def multiplier(x):
        return x * 2
    return multiplier

f = creer_multiplicateur()
```
A) Le nombre 2
B) Une erreur, car on ne peut pas définir une fonction dans une fonction
C) La fonction `multiplier`, prête à être appelée via `f(...)`
D) `None`

**Bonne réponse : C.** Une fonction peut être définie *à l'intérieur* d'une autre et être renvoyée comme valeur. C'est le second mécanisme clé des décorateurs : une fonction qui en fabrique une autre.

---

**Q5.** Dans l'exemple précédent, que vaut `f(5)` ?
A) 10
B) 5
C) Une erreur
D) La fonction `multiplier` elle-même

**Bonne réponse : A.** `f` est bien la fonction `multiplier` ; `f(5)` l'exécute avec `x = 5`, donc `5 * 2 = 10`. Si cette question t'a semblé évidente, tant mieux : c'est exactement le comportement attendu d'un décorateur qui "enveloppe" une fonction.

---

**Q6.** Que fait `*args` dans une définition de fonction comme `def f(*args):` ?
A) Impose exactement un argument nommé `args`
B) Récupère un nombre variable d'arguments positionnels dans un tuple
C) C'est une erreur de syntaxe
D) Récupère les arguments sous forme de dictionnaire

**Bonne réponse : B.** `*args` permet à une fonction d'accepter n'importe quel nombre d'arguments positionnels. C'est indispensable pour écrire un décorateur générique, capable d'envelopper *n'importe quelle* fonction, peu importe sa signature.

---

**Q7.** Et `**kwargs` ?
A) Fait la même chose que `*args`
B) Récupère les arguments nommés (mot-clé) dans un dictionnaire
C) Sert uniquement pour les méthodes de classe
D) Provoque une erreur si la fonction reçoit des arguments positionnels

**Bonne réponse : B.** `**kwargs` capture les arguments passés par mot-clé (`nom=valeur`) dans un dictionnaire. Combiné à `*args`, cela permet à une fonction "enveloppante" d'accepter n'importe quel appel.

---

**Q8.** Que fait ce code ?
```python
def externe():
    message = "salut"
    def interne():
        print(message)
    return interne

f = externe()
f()
```
A) Erreur : `message` n'existe plus quand `interne` est appelée
B) Affiche "salut", car `interne` garde en mémoire la variable `message` de `externe`
C) Affiche `None`
D) Erreur de syntaxe

**Bonne réponse : B.** C'est une *closure* : la fonction interne "se souvient" des variables de la fonction externe même après que celle-ci a fini de s'exécuter. Les décorateurs reposent presque toujours sur ce mécanisme.

---

**Q9.** Si tu devais écrire une fonction qui exécute une autre fonction puis affiche "terminé" après, à quoi ressemblerait le squelette le plus proche ?
A)
```python
def f(g):
    g()
    print("terminé")
```
B)
```python
def f(g):
    print("terminé")
    return g
```
C)
```python
def f():
    g()
    print("terminé")
```
D) Ce n'est pas possible en Python

**Bonne réponse : A.** On passe la fonction `g` en argument, on l'appelle, puis on exécute du code après. C'est très exactement la structure interne d'un décorateur, avant même d'introduire la syntaxe `@`.

---

**Q10.** Tu as déjà vu ou utilisé la syntaxe suivante :
```python
@login_required
def ma_vue(request):
    ...
```
A) Jamais rencontrée
B) Déjà vue dans du code, sans savoir précisément ce qu'elle fait
C) Déjà utilisée, en comprenant globalement le principe
D) Je sais expliquer comment `@login_required` transforme `ma_vue`

**Il n'y a pas de "bonne" réponse ici** : cette question sert juste à situer ton point de départ avant la séquence. Si tu es en A ou B, c'est le point de départ normal ; si tu es en D, la séquence te servira surtout à consolider et à repérer les pièges (arguments variables, préservation du nom de fonction, empilement de décorateurs).

---

### Checklist auto-cochée (complément)

Coche ce qui te semble vrai — il est normal de ne pas tout cocher :

- [ ] Je sais qu'une fonction peut être assignée à une variable sans être appelée
- [ ] Je sais écrire une fonction qui prend une autre fonction en paramètre
- [ ] Je sais écrire une fonction qui définit et retourne une fonction interne
- [ ] Je sais ce qu'est `*args` / `**kwargs` et je sais m'en servir
- [ ] Je comprends pourquoi une fonction interne peut "se souvenir" d'une variable de la fonction externe (closure)
- [ ] J'ai déjà vu la syntaxe `@quelque_chose` au-dessus d'une définition de fonction

---

### Ce que tu fais de ton résultat

Ce quiz ne donne pas un score à interpréter seul. Repère plutôt **où** tu as hésité :

- Q1–Q3 (fonctions comme objets) fragiles → revoir la notion de fonction comme valeur avant d'attaquer la séquence.
- Q4–Q5, Q8 (fonctions imbriquées, closures) fragiles → c'est le cœur mécanique des décorateurs, ce sera le point d'attention n°1 de la séquence.
- Q6–Q7 (`*args`/`**kwargs`) fragiles → à revoir en parallèle, sinon les décorateurs génériques resteront opaques.
- Tout est solide → la séquence portera surtout sur la syntaxe `@`, l'empilement de décorateurs et les cas d'usage (cache, chronométrage, contrôle d'accès).
