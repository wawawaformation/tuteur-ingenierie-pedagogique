## USER

Explique les décorateurs Python à un développeur adulte qui travaille sur une application de réservation.

## ASSISTANT

Les décorateurs Python permettent de modifier ou d'enrichir le comportement d'une fonction sans toucher à son code interne. C'est du sucre syntaxique autour du pattern "wrapper" : une fonction qui en prend une autre en argument et retourne une version enrichie.

## Le mécanisme de base

```python
def log_appel(func):
    def wrapper(*args, **kwargs):
        print(f"Appel de {func.__name__} avec {args}, {kwargs}")
        resultat = func(*args, **kwargs)
        print(f"{func.__name__} a retourné {resultat}")
        return resultat
    return wrapper

@log_appel
def reserver_chambre(chambre_id, client):
    return f"Chambre {chambre_id} réservée pour {client}"
```

`@log_appel` équivaut à `reserver_chambre = log_appel(reserver_chambre)`. Rien de magique : c'est juste réaffecter le nom.

## Cas d'usage concrets pour une appli de réservation

**Authentification / autorisation**
```python
def authentifie(func):
    def wrapper(*args, **kwargs):
        if not utilisateur_courant.est_connecte():
            raise PermissionError("Connexion requise")
        return func(*args, **kwargs)
    return wrapper

@authentifie
def annuler_reservation(reservation_id):
    ...
```

**Logging / audit** (traçabilité des actions de réservation, souvent exigée)

**Cache** — éviter de recalculer la disponibilité des chambres à chaque appel :
```python
from functools import lru_cache

@lru_cache(maxsize=128)
def disponibilite_chambre(chambre_id, date):
    return requete_couteuse_bdd(chambre_id, date)
```

**Gestion de transaction / retry** (utile pour les appels à un système de paiement ou une BDD) :
```python
def avec_transaction(func):
    def wrapper(*args, **kwargs):
        with db.transaction():
            return func(*args, **kwargs)
    return wrapper
```

**Validation** — vérifier les dates ou les entrées avant d'exécuter la réservation.

## Points techniques importants

1. **`functools.wraps`** — sans lui, `wrapper.__name__` écrase le nom de la fonction originale, ce qui casse l'introspection (debug, docs, frameworks comme Flask/FastAPI) :
```python
from functools import wraps

def log_appel(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        ...
    return wrapper
```

2. **Décorateurs avec arguments** (ex: `@requiert_role("admin")`) demandent un niveau d'indirection en plus — une fonction qui retourne un décorateur :
```python
def requiert_role(role):
    def decorateur(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if utilisateur_courant.role != role:
                raise PermissionError()
            return func(*args, **kwargs)
        return wrapper
    return decorateur

@requiert_role("admin")
def supprimer_reservation(reservation_id):
    ...
```

3. **Cumul de décorateurs** — ils s'appliquent de bas en haut :
```python
@authentifie
@avec_transaction
@log_appel
def reserver_chambre(...):
    ...
```
Ici `log_appel` s'exécute en premier (le plus proche de la fonction), puis `avec_transaction`, puis `authentifie`.

4. **Frameworks web** (Flask/FastAPI) exploitent ça massivement pour le routing : `@app.route("/reservations")` ou `@app.post("/reservations")` — le décorateur enregistre la fonction dans une table de routage sans changer son code.

Le point clé : ça sépare la logique métier (réserver une chambre) des préoccupations transverses (auth, logs, cache, transactions), ce qui garde le code de réservation lisible et évite de dupliquer ces vérifications dans chaque endpoint.
