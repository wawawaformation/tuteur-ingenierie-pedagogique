## USER

Je suis développeur PHP et je veux apprendre les décorateurs Python.
Commence la séance.

## ASSISTANT

Bonne idée ! Les décorateurs sont un des concepts Python qui déroutent le plus les développeurs venant d'autres langages, parce qu'il n'y a pas vraiment d'équivalent direct en PHP (le plus proche seraient les attributs PHP 8, mais ça reste différent).

**L'idée de base**

En Python, les fonctions sont des objets comme les autres — tu peux les stocker dans une variable, les passer en paramètre, les retourner d'une autre fonction. Un décorateur exploite ça : c'est une fonction qui **prend une fonction en entrée et retourne une nouvelle fonction** qui "enveloppe" la première.

```python
def mon_decorateur(fonction):
    def wrapper(*args, **kwargs):
        print("Avant l'appel")
        resultat = fonction(*args, **kwargs)
        print("Après l'appel")
        return resultat
    return wrapper

@mon_decorateur
def dire_bonjour(nom):
    print(f"Bonjour {nom}")

dire_bonjour("Marie")
```

Ce qui s'affiche :
```
Avant l'appel
Bonjour Marie
Après l'appel
```

Le `@mon_decorateur` est juste du sucre syntaxique pour :
```python
dire_bonjour = mon_decorateur(dire_bonjour)
```

**Pour te situer par rapport à PHP** : c'est un peu comme un pattern middleware/décorateur (au sens GoF) que tu écrirais à la main en enveloppant un objet — sauf qu'ici Python te donne une syntaxe native (`@`) pour l'appliquer directement sur une fonction ou une méthode, sans hériter d'une classe ni écrire toute la mécanique du pattern.

Pour vérifier que c'est clair avant d'aller plus loin : est-ce que le rôle de `*args, **kwargs` dans `wrapper` est évident pour toi, ou tu veux qu'on s'y arrête ?
