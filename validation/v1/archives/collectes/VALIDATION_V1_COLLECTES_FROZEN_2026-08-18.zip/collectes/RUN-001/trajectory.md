## USER

Crée une activité asynchrone dans laquelle l'apprenant :
1. analyse le problème ;
2. choisit une solution ;
3. implémente ;
4. teste ;
5. rédige un court bilan.

La production doit durer environ 2 heures.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-001/.claude/skills/tuteur-ingenierie-pedagogique/references/activite.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-001/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-001/.claude/skills/tuteur-ingenierie-pedagogique/references/atelier.md

## ASSISTANT

This correspond à un **Atelier** (asynchrone, méthode en plusieurs étapes, ~2h) plutôt qu'à une Activité. Avant de le rédiger, il me manque le contexte pour respecter A2/A3 (une seule notion non attestée, les autres déjà maîtrisées) :

## TOOL AskUserQuestion

[Domaine] Quel est le domaine / la compétence technique visée par cet atelier ?
Options: Développement logiciel (debug/résolution de bug) | Autre domaine technique
[Notion visée] Quelle est la notion nouvelle (non encore attestée) que cet atelier doit permettre d'attester ? Les autres notions mobilisées (langage, outils, méthode de test, etc.) doivent déjà être maîtrisées par l'apprenant.
Options: Je vais préciser

## TOOL AskUserQuestion

[Domaine] Quel est le domaine / la compétence technique visée par cet atelier ?
Options: Développement logiciel (debug de code) | Administration système / réseau | Data / analyse | Autre domaine (à préciser)

## USER VIA AskUserQuestion

Quel est le domaine / la compétence technique visée par cet atelier ?: Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## ASSISTANT

Faute de précisions, je choisis un scénario concret de **débogage logiciel** (domaine où la séquence analyse → solution → implémentation → test → bilan est la plus naturelle), et j'assume les prérequis ci-dessous. J'indique les hypothèses explicitement (section 6) comme l'exige le gabarit.

**Palier visé** : 3 – Appliquer (mettre en œuvre une méthode de correction sur un cas simple, dans des conditions définies).
**Notion nouvelle (budget A3)** : écrire un test qui prouve qu'un correctif fonctionne. Prérequis supposés déjà attestés : lire/modifier du code dans le langage donné, exécuter un script, identifier une erreur dans un message de trace.

---

## Fiche d'Atelier (asynchrone) — *Corriger un bug à partir d'un rapport utilisateur*

**1. Documents fournis**
- Un script (`facture.py`) contenant une fonction `calculer_total(lignes, taux_remise)` avec un bug : la remise est appliquée après la TVA au lieu d'avant.
- Un rapport utilisateur : *« Sur une commande de 100 €HT avec 10 % de remise et 20 % de TVA, le total affiché est 132 € au lieu de 108 €. »*
- Un jeu de 3 commandes d'exemple avec leurs totaux attendus (fournis en commentaire dans le script).

**2. Objectifs de l'atelier**
- Diagnostiquer l'origine du décalage entre le résultat attendu et le résultat obtenu.
- Choisir un correctif et justifier pourquoi il règle le problème sans en créer un autre.
- Implémenter ce correctif dans le script fourni.
- Écrire un test qui prouve que le correctif fonctionne sur les 3 exemples fournis.
- Rédiger un bilan de 10 lignes maximum expliquant la cause, la correction et sa vérification.

**3. Durée estimée**
Environ 2 heures. Cette durée est indicative : elle dépend de votre aisance avec le langage, pas d'un chronomètre à respecter.

**4. Organisation et outils**
Libre. Éditeur de code, terminal, environnement de test au choix (script manuel, `assert`, ou framework si vous en avez l'habitude).

**5. Méthode proposée**
1. Rejouez le calcul à la main sur l'exemple du rapport utilisateur pour confirmer l'écart.
2. Lisez `calculer_total` ligne à ligne et repérez l'ordre des opérations (remise / TVA).
3. Formulez par écrit, en une phrase, la cause du bug avant de toucher au code.
4. Corrigez la fonction.
5. Écrivez un test qui exécute les 3 exemples fournis et vérifie que le total obtenu correspond au total attendu.
6. Rédigez le bilan (section 7).

**6. Ce qui est supposé par défaut**
- Le taux de TVA et le taux de remise sont exprimés en proportion décimale (0.10, pas 10).
- Un seul bug est présent dans la fonction ; les autres parties du script sont correctes.
- « Écrire un test » signifie : du code qui compare automatiquement un résultat obtenu à un résultat attendu, pas une simple exécution suivie d'une lecture visuelle du résultat.

**7. Livrable attendu**
- Le fichier `facture.py` corrigé.
- Le code du test (dans le même fichier ou un fichier séparé).
- Un bilan écrit (5 à 10 lignes) : cause du bug, correction apportée, preuve que le test passe.

**8. Critère simple**
*Si votre test échoue avant la correction et réussit après, sur les 3 exemples fournis, c'est gagné.*

---

### Volet formateur (ne pas remettre à l'apprenant)

- **Notion nouvelle attestée si réussite** : écrire un test automatisé qui documente et vérifie un correctif.
- **Production de référence** : `total = (sous_total - remise) * (1 + taux_tva)` au lieu de `(sous_total * (1 + taux_tva)) - remise`.
- **Critères d'acceptation** : les 3 exemples fournis passent ; le test échoue si on annule le correctif (sinon il ne teste rien) ; le bilan nomme explicitement la cause (ordre des opérations), pas seulement le symptôme.
- **Erreur fréquente attendue** : corriger le résultat pour le seul exemple du rapport utilisateur sans généraliser (correctif qui « marche » en apparence mais casse un des deux autres cas). Reformulation à proposer : *« Votre test passe-t-il aussi sur les deux autres commandes fournies ? »*
