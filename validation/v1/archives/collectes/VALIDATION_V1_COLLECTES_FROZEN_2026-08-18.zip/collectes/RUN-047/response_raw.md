Voici un décorateur simple et concret, qu'on va lire ensemble ligne par ligne — pas besoin d'en écrire un pour comprendre ce qui se passe.

```python
import time

def chronometre(fonction):
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = fonction(*args, **kwargs)
        fin = time.time()
        print(f"{fonction.__name__} a pris {fin - debut:.4f} secondes")
        return resultat
    return wrapper

@chronometre
def calcul_long(n):
    total = 0
    for i in range(n):
        total += i
    return total

calcul_long(10_000_000)
```

**Ce qui s'affiche quand on exécute ce code :**
```
calcul_long a pris 0.3521 secondes
```

**Ce qui se passe, étape par étape :**

1. `calcul_long` est une fonction ordinaire : elle additionne les nombres de 0 à `n`. Rien de spécial jusqu'ici.
2. La ligne `@chronometre` juste au-dessus dit à Python : « avant d'utiliser `calcul_long`, passe-la à la fonction `chronometre` et remplace-la par ce que `chronometre` renvoie ». C'est strictement équivalent à écrire `calcul_long = chronometre(calcul_long)`.
3. Regarde maintenant `chronometre` : elle reçoit une fonction en argument (ici `calcul_long`), et elle définit *à l'intérieur* une nouvelle fonction, `wrapper`. C'est `wrapper` qu'elle renvoie à la fin — pas le résultat du calcul, la fonction elle-même.
4. `wrapper` fait trois choses : elle note l'heure de départ, elle appelle la fonction d'origine (`fonction(*args, **kwargs)` — c'est là que `calcul_long(10_000_000)` s'exécute réellement), puis elle note l'heure de fin et affiche la durée.
5. Donc quand tu écris `calcul_long(10_000_000)` dans ton code, tu n'appelles plus directement la fonction d'origine : tu appelles `wrapper`, qui elle-même appelle l'originale « par-dessous », en ajoutant le chronométrage avant et après.

**L'idée centrale à retenir** : un décorateur est une fonction qui prend une fonction en entrée et renvoie une nouvelle fonction en sortie — une version « enveloppée » (d'où `wrapper`, l'enveloppe) qui ajoute un comportement (ici, mesurer le temps) sans toucher au code original de `calcul_long`. La syntaxe `@nom_du_decorateur` est juste un raccourci d'écriture pour ce remplacement.

Ça te semble clair, ou il y a un point — le rôle de `wrapper`, le `*args, **kwargs`, ou le fonctionnement de `@` lui-même — que tu veux qu'on reprenne plus lentement ?
