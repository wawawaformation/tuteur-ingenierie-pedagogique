## USER

Explique les décorateurs Python à un développeur adulte qui travaille sur une application de réservation.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-113/.claude/skills/tuteur-ingenierie-pedagogique/references/andragogie.md

## ASSISTANT

Avant de partir dans les explications : est-ce que tu as déjà croisé un truc du genre `@app.route(...)` (Flask) ou `@login_required` dans du code existant ? Et si oui, tu décrirais ça comment avec tes mots — qu'est-ce que tu penses que ça fait concrètement au moment où Python lit ce fichier ?

Je te pose la question parce que ça change l'angle : si tu as déjà vu la syntaxe sans avoir démêlé le mécanisme, on part de là plutôt que de reprendre depuis zéro.

En attendant ta réponse, voici le fil que je te propose pour ton appli de réservation — dis-moi si tu préfères qu'on parte d'un autre cas concret :

**Le problème que ça résout.** Dans une appli de réservation, tu as sûrement des trucs comme : vérifier que l'utilisateur est authentifié avant de créer une réservation, logger le temps d'exécution d'un appel au service de paiement, ou retenter un appel réseau qui a échoué. Sans décorateur, tu dupliques ce code au début de chaque fonction concernée (`confirmer_reservation`, `annuler_reservation`, `modifier_reservation`...). Un décorateur te permet d'écrire cette logique une fois et de l'« agrafer » sur n'importe quelle fonction, juste en ajoutant une ligne au-dessus.

**Le mécanisme, pas la magie.** Un décorateur, c'est juste une fonction qui prend une fonction en argument et qui renvoie une nouvelle fonction. `@mon_decorateur` au-dessus de `def confirmer_reservation():` est strictement équivalent à écrire `confirmer_reservation = mon_decorateur(confirmer_reservation)`. Rien d'autre. Ça marche parce qu'en Python les fonctions sont des objets comme les autres — tu peux les passer en argument, les renvoyer, les stocker dans une variable.

Concrètement, pour vérifier qu'un utilisateur est connecté avant de réserver :

```python
from functools import wraps

def login_required(fonction):
    @wraps(fonction)
    def wrapper(*args, **kwargs):
        if not utilisateur_courant.est_connecte:
            raise PermissionDenied("Connexion requise pour réserver")
        return fonction(*args, **kwargs)
    return wrapper

@login_required
def confirmer_reservation(id_creneau):
    ...
```

Quand `confirmer_reservation(42)` est appelée, c'est en réalité `wrapper(42)` qui s'exécute : elle vérifie la connexion, et si tout va bien, appelle la vraie fonction en lui passant les arguments tels quels.

Deux points qui piègent souvent, et qui te seront utiles direct :
- `*args, **kwargs` dans le wrapper, c'est ce qui permet au décorateur de s'appliquer à n'importe quelle fonction, peu importe sa signature (`confirmer_reservation(id_creneau)` vs `annuler_reservation(id_reservation, motif=None)`).
- `@wraps(fonction)` de `functools` préserve le nom et la docstring de la fonction d'origine — sans ça, `confirmer_reservation.__name__` te renverrait `"wrapper"`, ce qui casse la lisibilité des stack traces et de la doc en prod.

Ça te parle comme point de départ, ou tu veux qu'on parte plutôt d'un cas déjà présent dans ton code (retry sur l'appel au fournisseur de paiement, cache sur la dispo des créneaux, etc.) ?
