Avant de plonger dans le code, une question pour caler le point de départ : **est-ce que tu as déjà manipulé des fonctions en Python en les passant comme argument à une autre fonction**, ou en les retournant depuis une fonction (genre `def f(): return une_autre_fonction`) ? Et est-ce que tu as un cas concret en tête où tu te dis "je voudrais ajouter un comportement (logger un appel, chronométrer, vérifier une permission...) à plusieurs fonctions sans dupliquer le code partout" ?

Ça me permet de savoir si on part de zéro sur les fonctions comme "objets", ou si on peut foncer directement sur le décorateur.

Pas de souci, on construit progressivement — je vais vérifier ta compréhension au fil de l'eau plutôt que par des questions préalables.

## Étape 0 : le problème qu'on va résoudre

Imagine que tu as plusieurs fonctions dans un projet, et que tu veux savoir combien de temps chacune prend à s'exécuter — sans réécrire le code de chronométrage dans chaque fonction. C'est exactement le genre de problème qu'un décorateur résout : **ajouter un comportement autour d'une fonction, sans toucher à son contenu**.

## Étape 1 : une fonction est un objet comme un autre

Avant le décorateur, il faut ce socle : en Python, une fonction peut se manipuler comme une variable — on peut la stocker, la passer en argument, la retourner.

Essaie ça de ton côté (dans un fichier ou un interpréteur) :

```python
def saluer():
    print("Salut !")

f = saluer   # pas d'appel, pas de parenthèses : on stocke la fonction elle-même
f()          # ici on l'appelle
```

Lance ce petit bout de code et dis-moi ce que tu observes — en particulier, qu'est-ce qui se passe si tu écris juste `f` (sans parenthèses) au lieu de `f()` ? Ça va nous servir directement pour l'étape suivante.
