# Quiz d'auto-positionnement — Prérequis décorateurs

Objectif : vérifier que les bases nécessaires aux décorateurs sont acquises (fonctions comme objets, fonctions imbriquées, closures, *args/**kwargs). Pas de points bloquants — c'est pour identifier les révisions à faire.

---

**1. Que va afficher ce code ?**
```python
def dire_bonjour():
    return "Bonjour"

f = dire_bonjour
print(f())
```
a) Erreur, `dire_bonjour` n'est pas défini comme variable
b) `Bonjour`
c) `<function dire_bonjour>`
d) `None`

---

**2. Qu'est-ce qu'une fonction "de premier ordre" (first-class) en Python ?**
a) Une fonction qui s'exécute plus vite que les autres
b) Une fonction qu'on peut passer en argument, stocker dans une variable, ou retourner par une autre fonction
c) Une fonction définie avec `def` (par opposition aux méthodes)
d) Une fonction qui ne prend aucun argument

---

**3. Que retourne l'appel `exterieure()` ci-dessous ?**
```python
def exterieure():
    message = "salut"
    def interieure():
        return message
    return interieure

resultat = exterieure()
print(resultat())
```
a) Une erreur, `message` n'existe plus après le `return` de `exterieure`
b) `salut`
c) `None`
d) La fonction `interieure` elle-même, sans l'exécuter

---

**4. Comment s'appelle le mécanisme illustré dans la question précédente (une fonction imbriquée qui "se souvient" d'une variable de la fonction englobante) ?**
a) Un générateur
b) Une closure (fermeture)
c) Une récursion
d) Un décorateur

---

**5. Que fait `*args` dans une signature de fonction comme `def f(*args):` ?**
a) Il force l'appelant à passer exactement un argument nommé `args`
b) Il collecte tous les arguments positionnels dans un tuple
c) Il collecte tous les arguments nommés dans un dictionnaire
d) Il rend tous les arguments optionnels avec valeur par défaut `None`

---

**6. Et `**kwargs` ?**
a) Il collecte les arguments nommés (mot-clé) dans un dictionnaire
b) Il collecte les arguments positionnels dans une liste
c) Il sert à déballer un tuple
d) Il n'existe pas en Python, seul `*args` existe

---

**7. Que va afficher ce code ?**
```python
def appliquer(fonction, valeur):
    return fonction(valeur)

def carre(x):
    return x * x

print(appliquer(carre, 5))
```
a) Erreur : on ne peut pas passer une fonction en argument
b) `25`
c) `<function carre>`
d) `carre(5)`

---

**8. Une fonction peut-elle retourner une autre fonction (sans l'exécuter) ?**
a) Non, une fonction ne peut retourner que des données (int, str, liste...)
b) Oui, une fonction est un objet comme un autre et peut être retournée
c) Oui, mais seulement si elle est déclarée avec `lambda`
d) Non, cela provoquerait une erreur de récursion infinie

---

**9. Que fait `*` (étoile) lors d'un appel de fonction comme `f(*ma_liste)` ?**
a) Il multiplie chaque élément de `ma_liste`
b) Il déballe `ma_liste` pour passer chacun de ses éléments comme argument positionnel séparé
c) Il transforme `ma_liste` en dictionnaire
d) Il provoque une erreur car `*` n'est utilisable que dans une définition de fonction

---

**10. Que va afficher ce code ?**
```python
def compteur():
    n = 0
    def incrementer():
        nonlocal n
        n += 1
        return n
    return incrementer

c = compteur()
print(c())
print(c())
```
a) `1` puis `1`
b) `0` puis `1`
c) `1` puis `2`
d) Une erreur car `n` n'est pas accessible dans `incrementer`

---

*Ces 10 questions couvrent exactement ce qu'il faut maîtriser avant d'aborder les décorateurs (fonctions objets, imbrication, closures, `nonlocal`, `*args`/`**kwargs`, déballage d'arguments). Donne-moi tes réponses ou dis-moi si tu veux directement le corrigé et les explications.*
