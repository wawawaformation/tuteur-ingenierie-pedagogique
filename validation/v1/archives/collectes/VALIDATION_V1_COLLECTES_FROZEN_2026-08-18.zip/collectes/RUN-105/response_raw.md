Avant de figer l'activité, un point de vigilance A2/A3 : je ne connais pas l'état des paliers réel de l'apprenant sur les notions que ce mini-exercice mobilise. Je les énumère, avec une hypothèse de statut, et je conçois l'activité pour que **une seule** soit réellement nouvelle — à toi de confirmer les autres.

**Notions mobilisées (état des paliers — hypothèses à confirmer)**

| Notion | Palier requis | Statut supposé |
|---|---|---|
| Syntaxe fonction Python (def, return, paramètres) | 3 — Appliquer | Attesté (prérequis) |
| Lire/exécuter des tests fournis (pytest ou équivalent) | 3 — Appliquer | Attesté (prérequis) |
| Fonctions imbriquées, `*args`/`**kwargs` pour transmettre des arguments | 3 — Appliquer | **À vérifier** — voir note ci-dessous |
| Patron du décorateur (`@nom`, wrapper qui encapsule un appel) appliqué à la journalisation | 3 — Appliquer | **Notion nouvelle** (budget A3) |

Note : si la gestion de `*args`/`**kwargs` n'est pas déjà attestée, l'activité comme demandée mobiliserait deux inconnues à la fois. Pour respecter A3, je fournis le squelette du wrapper (signature et `return func(*args, **kwargs)` déjà écrits) et je restreins la nouveauté à l'ajout de la ligne de journalisation et au branchement `@`. Si tu confirmes que `*args`/`**kwargs` est déjà attesté chez l'apprenant, ce garde-fou peut être retiré.

---

## Fiche d'Activité — « Décorateur de journalisation »

### Volet remis à l'apprenant

**Intention** : Voir comment on ajoute un comportement (ici, une trace de journalisation) autour d'une fonction existante sans toucher à son code ni casser ses tests.

**Consigne** : À partir de la fonction et des tests fournis ci-dessous, complète le décorateur `log_calls` pour qu'il journalise chaque appel, puis applique-le à la fonction avec `@log_calls`.

**Matériel de départ** :

```python
# fonction.py
def calculer_total(prix, quantite):
    return prix * quantite
```

```python
# test_fonction.py
from fonction import calculer_total

def test_calculer_total():
    assert calculer_total(10, 3) == 30
```

```python
# squelette fourni — à compléter
import logging
logging.basicConfig(level=logging.INFO)

def log_calls(func):
    def wrapper(*args, **kwargs):
        # ligne à ajouter : journaliser le nom de la fonction et ses arguments
        return func(*args, **kwargs)
    return wrapper

# ligne à ajouter : appliquer le décorateur à calculer_total
def calculer_total(prix, quantite):
    return prix * quantite
```

**Contraintes** :
- Ne modifie ni le corps de `calculer_total`, ni le fichier de tests.
- Utilise uniquement `logging` (déjà importé) — pas de bibliothèque tierce.
- Le décorateur doit s'appliquer via la syntaxe `@log_calls`.

**Critère de réussite** : Les tests fournis passent toujours, et chaque appel à `calculer_total` affiche une ligne de log mentionnant le nom de la fonction.

---

### Volet conservé par le formateur

**Palier visé** : 3 — Appliquer (mettre en œuvre le patron du décorateur sur un cas simple, dans des conditions balisées).

**Notion nouvelle (A3)** : le patron du décorateur Python appliqué à la journalisation — c'est-à-dire comprendre qu'un décorateur remplace la fonction par un wrapper qui exécute du code autour de l'appel d'origine. Toutes les autres notions (syntaxe de fonction, transmission d'arguments, lecture de tests) sont supposées déjà attestées.

**Production attendue** :

```python
def log_calls(func):
    def wrapper(*args, **kwargs):
        logging.info(f"Appel de {func.__name__} avec args={args}, kwargs={kwargs}")
        return func(*args, **kwargs)
    return wrapper

@log_calls
def calculer_total(prix, quantite):
    return prix * quantite
```

**Critères d'acceptation** (ce qui fait passer la ligne « décorateur simple » à *attesté* dans `etat_des_paliers.md`, rien de plus) :
- `pytest test_fonction.py` passe sans modification du test.
- Un appel à `calculer_total` produit une trace de log contenant au moins le nom de la fonction.
- Le décorateur est appliqué via `@log_calls` (pas d'appel manuel du type `calculer_total = log_calls(calculer_total)`).

**Erreur fréquente attendue et sa reformulation** :
Oubli du `return func(*args, **kwargs)` dans le wrapper (la fonction décorée « disparaît », renvoie `None`, le test échoue).
Diagnostic à formuler sans donner la réponse : *« Le test attend 30, que reçoit-il à la place ? Qu'est-ce que ton wrapper renvoie, en ce moment, à la fin ? »*

---

Si tu me confirmes le statut réel de `*args`/`**kwargs` chez l'apprenant, je peux ajuster (retirer le squelette pré-rempli si c'est déjà attesté, ou au contraire prévoir un atelier intermédiaire si ce n'est pas le cas).
