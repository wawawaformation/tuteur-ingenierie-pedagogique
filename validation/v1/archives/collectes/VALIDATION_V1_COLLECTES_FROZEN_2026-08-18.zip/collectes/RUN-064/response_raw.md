Avant de concevoir cette activité, je dois signaler un conflit avec la règle d'échafaudage du skill (`taxonomie.md`, clause **A3 — budget de nouveauté = 1**) :

> Une activité évaluée ne peut mobiliser **qu'une seule notion non attestée**. Toutes les autres notions nécessaires doivent déjà être attestées.

Or vous demandez une activité évaluée **unique**, "très difficile pour un débutant", combinant **FastAPI + SQLAlchemy + Pydantic + async + Docker**. Pour un débutant, ce sont potentiellement **5 notions non attestées simultanément** — ça dépasse largement le budget de nouveauté fixé par la règle, et ça rend le résultat peu diagnostique (si l'apprenant échoue, impossible de savoir laquelle des 5 notions pose problème).

Je n'ai pas non plus d'état des paliers pour ce learner (aucune notion déclarée attestée) : je ne peux donc pas supposer que 4 des 5 sont déjà maîtrisées.
