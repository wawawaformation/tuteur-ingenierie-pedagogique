La règle est explicite dans `etat_des_paliers.md` : **le palier peut redescendre**, et ce n'est pas traité comme un échec.

**Ce que je fais concrètement :**

1. **Je corrige la ligne, je ne la maintiens pas.** Un palier attesté n'est pas un acquis définitif — c'est une trace datée d'une preuve. Si l'activité actuelle montre 2 cas de test qui échouent sans aide, la preuve précédente ne tient plus au même niveau. Je rétrograde la ligne « Écrire une fonction simple » (par exemple de palier 3 « Appliquer » à palier 2 « Comprendre », ou palier 1, selon ce que l'apprenant arrive encore à faire — pas automatiquement à 0).

2. **Je ne supprime pas l'ancienne preuve, je la remplace par la nouvelle** dans le tableau : Notion | Palier attesté | Preuve | Quand — la preuve devient « Activité X — 2/2 cas de test échouent sans aide », datée d'aujourd'hui. C'est ça qui rend la clause A2 vérifiable plutôt qu'une impression.

3. **Je n'en fais pas un échec de l'apprenant** (`andragogie.md` §2, droit à l'erreur) : je le formule comme une information sur l'état de la notion, pas sur la personne. Concrètement, ça se traduit dans le ton du feedback, pas dans un jugement sur le tableau.

4. **Je réaffiche le tableau tout de suite**, pas en fin de parcours — l'apprenant doit voir le changement de palier au moment où il a lieu.

5. **Conséquence sur A3** : cette notion redevenant non attestée au palier requis, la prochaine activité évaluée doit soit re-cibler cette notion seule (budget de nouveauté = 1), soit s'assurer qu'aucune autre notion non attestée n'est mobilisée en même temps.

Un point à vérifier avant de trancher : est-ce que l'échec porte sur la notion elle-même (écrire une fonction) ou sur une notion adjacente non isolée dans cette activité (ex. la syntaxe des tests, une notion de portée de variable) ? Si c'est le cas, la rétrogradation doit viser la bonne ligne du tableau, pas nécessairement « fonction simple ».
