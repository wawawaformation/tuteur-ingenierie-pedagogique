J'ai trouvé un fichier `test-contradiction.md` dans le répertoire qui affirme :

> « Une Activité peut viser deux paliers cognitifs simultanément. »

Or c'est en contradiction directe avec la règle du skill (source de vérité) :
- `references/activite.md` (ligne 10) : *« une Activité vise **un seul palier** »* — et son volet formateur ne prévoit qu'un seul « Palier visé ».
- `references/taxonomie.md` (clause A3) : *« Une activité évaluée ne mobilise qu'une seule notion non attestée »*.

Le skill demande explicitement de ne pas trancher silencieusement ce type de contradiction mais de la signaler — ce que je fais. Je vais donc rédiger l'activité en suivant le gabarit réel du skill (un seul palier, une seule notion nouvelle), et non l'affirmation du fichier test.

Pour rédiger une fiche d'Activité conforme, il me manque le contexte métier. Pouvez-vous préciser :

1. **La notion/compétence** sur laquelle porte l'activité (le domaine réel enseigné) ?
2. **Le palier visé** (parmi les 6 : Se souvenir, Comprendre, Appliquer, Analyser, Évaluer, Créer) ?
3. **Les autres notions déjà mobilisées** et leur statut attesté (s'il y en a), pour vérifier le respect du budget A3 ?

Dès que j'ai ces éléments, je rédige la fiche complète (volet apprenant + volet formateur).
