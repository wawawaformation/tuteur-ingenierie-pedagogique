## USER

Je forme des développeurs Python adultes.
Crée-moi un exercice de 15 minutes pour leur apprendre les décorateurs Python.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-063/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-063/.claude/skills/tuteur-ingenierie-pedagogique/references/activite.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-063/.claude/skills/tuteur-ingenierie-pedagogique/references/opo.md

## ASSISTANT

Voici une fiche d'Activité de 15 minutes, ciblée sur **un seul palier nouveau** : la syntaxe et la mécanique du décorateur.

**Hypothèse de prérequis** (à ajuster si besoin) : ce groupe de développeurs maîtrise déjà les fonctions comme objets de première classe, `*args`/`**kwargs`, et les fermetures (closure). C'est la seule façon de tenir le budget de nouveauté à 1 — sinon il faudrait d'abord attester ces notions séparément.

---

## Volet remis aux apprenants

**Intention** : voir comment on peut ajouter un comportement à une fonction (ici : chronométrer son exécution) sans toucher à son code.

**Matériel de départ** :
```python
def calcul_lent(n):
    total = 0
    for i in range(n):
        total += i
    return total

resultat = calcul_lent(1_000_000)
print(resultat)
```

**Consigne** : écrivez un décorateur `chrono` qui affiche le temps d'exécution de la fonction décorée, puis appliquez-le à `calcul_lent` avec la syntaxe `@chrono`.

**Contraintes** :
- Interdiction de modifier le corps de `calcul_lent`.
- Utilisez le module `time` (`time.perf_counter()`).
- La fonction décorée doit continuer à renvoyer sa valeur normalement (le `print(resultat)` doit toujours afficher le bon total).

**Critère de réussite** : en exécutant le script, la console affiche le temps d'exécution *avant* le résultat, et le résultat affiché est identique à celui obtenu sans le décorateur.

---

## Volet formateur

- **Palier visé** : 3 — Appliquer (mettre en œuvre le patron du décorateur sur un cas simple).
- **Notion nouvelle (A3)** : la syntaxe `@decorateur` et le mécanisme sous-jacent (une fonction qui reçoit une fonction et renvoie une fonction wrapper). Tout le reste (fonctions objets, `*args`/`**kwargs`, closures) doit déjà être attesté.

**Production attendue** :
```python
import time

def chrono(func):
    def wrapper(*args, **kwargs):
        debut = time.perf_counter()
        resultat = func(*args, **kwargs)
        fin = time.perf_counter()
        print(f"Temps d'exécution : {fin - debut:.4f}s")
        return resultat
    return wrapper

@chrono
def calcul_lent(n):
    total = 0
    for i in range(n):
        total += i
    return total

resultat = calcul_lent(1_000_000)
print(resultat)
```

**Critères d'acceptation** :
- `wrapper` appelle bien `func(*args, **kwargs)` (pas `func()` sans arguments).
- `wrapper` **retourne** le résultat de `func`.
- `chrono` retourne `wrapper` (pas `wrapper()`).
- `@chrono` est utilisé, pas un appel manuel type `calcul_lent = chrono(calcul_lent)` (ça marcherait aussi, mais ce n'est pas la notion visée ici).

**Erreur fréquente attendue** : oublier le `return resultat` dans `wrapper`. Le script tourne sans erreur, affiche le temps, mais `print(resultat)` affiche `None`.

Question de diagnostic à poser (jamais "c'est faux") : *"Qu'est-ce que `wrapper` renvoie actuellement à celui qui l'appelle, une fois que `func` a fini de s'exécuter ?"*

---

**Minutage suggéré (15 min)** : 2 min lecture de la consigne + matériel → 10 min écriture individuelle → 3 min comparaison avec la production de référence et diagnostic de l'erreur fréquente si elle apparaît.
