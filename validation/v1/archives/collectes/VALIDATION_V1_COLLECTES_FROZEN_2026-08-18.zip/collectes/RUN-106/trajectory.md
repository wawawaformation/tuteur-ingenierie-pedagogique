## USER

Crée une activité asynchrone dans laquelle l'apprenant :
1. analyse le problème ;
2. choisit une solution ;
3. implémente ;
4. teste ;
5. rédige un court bilan.

La production doit durer environ 2 heures.

## ASSISTANT

Avant de rédiger l'activité, j'ai besoin de connaître le contexte pour qu'elle soit pertinente (le "problème" à résoudre dépend entièrement du domaine).

## TOOL AskUserQuestion

[Domaine] Dans quel domaine/discipline se situe cette activité ?
Options: Informatique/programmation | Autre matière technique | Précisez vous-même
[Niveau] Quel est le niveau des apprenants ?
Options: Débutant | Intermédiaire | Avancé

## USER VIA AskUserQuestion

Dans quel domaine/discipline se situe cette activité ?: Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.
Quel est le niveau des apprenants ?: Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## ASSISTANT

# Activité asynchrone – Résolution d'un problème technique (≈ 2h)

*Format adaptable à toute discipline technique ; ici illustré avec un scénario informatique, à remplacer par le problème réel de votre choix.*

## Consigne générale
Vous allez traiter un problème concret en autonomie, en suivant les 5 étapes ci-dessous. Travail individuel, à distance, livrable unique à déposer en fin de séance.

**Problème proposé** (à remplacer par votre cas précis) :
> Une fonction/API/script produit un résultat incorrect ou un comportement inattendu dans certains cas (ex : une fonction de calcul de moyenne renvoie une erreur quand la liste est vide, ou un formulaire accepte des données invalides).

---

### Étape 1 – Analyser le problème (25 min)
- Reformuler le problème avec vos propres mots.
- Identifier les symptômes observés, les cas qui échouent, les cas qui fonctionnent.
- Formuler au moins 2 hypothèses sur la cause.
- **Livrable** : 5-10 lignes dans le document de rendu.

### Étape 2 – Choisir une solution (20 min)
- Lister au moins 2 approches possibles pour résoudre le problème.
- Comparer avantages/inconvénients de chacune (complexité, robustesse, temps).
- Justifier le choix retenu en une ou deux phrases.
- **Livrable** : tableau comparatif court + choix justifié.

### Étape 3 – Implémenter (45 min)
- Mettre en œuvre la solution choisie (code, configuration, procédure selon le contexte).
- Documenter brièvement les modifications apportées (commentaires, changelog).
- **Livrable** : fichier(s) modifié(s) ou lien vers le dépôt/version.

### Étape 4 – Tester (20 min)
- Définir au moins 3 cas de test (dont un cas limite).
- Exécuter les tests et noter les résultats obtenus.
- Si un test échoue, ajuster l'implémentation et retester.
- **Livrable** : liste des tests + résultats (capture ou log).

### Étape 5 – Rédiger un bilan (10 min)
- Ce qui a fonctionné, ce qui a été difficile.
- Ce que vous feriez différemment avec plus de temps.
- Une notion/compétence que vous retenez de cet exercice.
- **Livrable** : 5-8 lignes.

---

## Récapitulatif temps (~120 min)
| Étape | Durée |
|---|---|
| 1. Analyse | 25 min |
| 2. Choix solution | 20 min |
| 3. Implémentation | 45 min |
| 4. Tests | 20 min |
| 5. Bilan | 10 min |

## Critères d'évaluation suggérés
- Pertinence de l'analyse (hypothèses cohérentes avec les symptômes)
- Qualité de la justification du choix
- Fonctionnalité de l'implémentation
- Couverture et rigueur des tests
- Réflexivité du bilan (pas juste descriptif)

---

Dites-moi le domaine et le problème réel (langage, outil, niveau des apprenants) si vous voulez que j'adapte le contenu précisément plutôt que de garder l'exemple générique.
