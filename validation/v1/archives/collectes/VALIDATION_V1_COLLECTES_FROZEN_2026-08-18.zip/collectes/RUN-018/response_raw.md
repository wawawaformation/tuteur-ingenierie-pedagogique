## Activité évaluée : Ajouter un décorateur de journalisation

### Contexte
Voici une fonction déjà implémentée et testée. Votre travail : ajouter un décorateur simple qui journalise chaque appel (nom de la fonction, arguments, valeur de retour), sans modifier le comportement métier de la fonction.

### Code fourni (`calculs.py`)

```python
def diviser(a, b):
    """Retourne le quotient de a par b."""
    if b == 0:
        raise ValueError("division par zéro impossible")
    return a / b
```

### Tests fournis (`test_calculs.py`)

```python
import logging
import pytest
from calculs import diviser

def test_diviser_cas_normal():
    assert diviser(10, 2) == 5

def test_diviser_par_zero():
    with pytest.raises(ValueError):
        diviser(10, 0)

def test_diviser_journalise_appel(caplog):
    with caplog.at_level(logging.INFO):
        diviser(8, 4)
    assert "diviser" in caplog.text
    assert "(8, 4)" in caplog.text or "8" in caplog.text
    assert "2.0" in caplog.text

def test_diviser_journalise_exception(caplog):
    with caplog.at_level(logging.INFO):
        with pytest.raises(ValueError):
            diviser(1, 0)
    assert "diviser" in caplog.text
```

### Consigne

1. Créez un décorateur `journaliser` (dans un fichier `decorateurs.py` ou directement dans `calculs.py`) qui :
   - logge (niveau `INFO`, via le module `logging`) le nom de la fonction appelée et ses arguments **avant** l'exécution ;
   - logge la valeur de retour **après** l'exécution ;
   - logge aussi le cas où une exception est levée (avant de la relancer) ;
   - utilise `functools.wraps` pour préserver le nom et la docstring de la fonction décorée.
2. Appliquez ce décorateur à `diviser` avec la syntaxe `@journaliser`.
3. Les tests fournis doivent tous passer sans modification.
4. Contrainte : le décorateur doit être générique (utilisable sur n'importe quelle fonction, via `*args, **kwargs`), pas codé spécifiquement pour `diviser`.

### Barème (10 points)

| Critère | Points |
|---|---|
| Le décorateur utilise `*args, **kwargs` et fonctionne sur une fonction quelconque | 2 |
| `functools.wraps` est utilisé (nom/docstring préservés) | 1 |
| Log de l'appel (nom + arguments) avant exécution | 2 |
| Log du résultat après exécution | 2 |
| Log de l'exception avant relance (`raise`) | 2 |
| Tous les tests fournis passent | 1 |

### Corrigé attendu (pour l'évaluateur)

```python
import functools
import logging

logger = logging.getLogger(__name__)

def journaliser(fonction):
    @functools.wraps(fonction)
    def wrapper(*args, **kwargs):
        logger.info("Appel de %s(%s, %s)", fonction.__name__, args, kwargs)
        try:
            resultat = fonction(*args, **kwargs)
        except Exception as exc:
            logger.info("%s a levé %r", fonction.__name__, exc)
            raise
        logger.info("%s a retourné %r", fonction.__name__, resultat)
        return resultat
    return wrapper

@journaliser
def diviser(a, b):
    """Retourne le quotient de a par b."""
    if b == 0:
        raise ValueError("division par zéro impossible")
    return a / b
```

Voulez-vous que j'adapte cette activité à un autre langage, une autre fonction métier, ou que je durcisse/allège le barème ?
