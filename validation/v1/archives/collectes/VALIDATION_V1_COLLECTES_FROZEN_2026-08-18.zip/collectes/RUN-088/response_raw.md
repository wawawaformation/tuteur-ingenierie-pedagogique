Cette activité mobilise en réalité **deux notions distinctes**, pas une seule :

1. **La définition de fonction** (syntaxe `def`, paramètres, `return`)
2. **L'opérateur d'addition** (`+`) sur des nombres

Pour répondre à « est-ce une nouvelle notion ? » il faut appliquer A2 : le palier ne se juge jamais globalement, mais notion par notion, selon l'état des paliers déjà attesté pour cet apprenant.

Donc la vraie question est : lesquelles de ces deux notions sont déjà **attestées** (preuve 3C à l'appui) chez cet apprenant ?

- Si l'apprenant a déjà attesté « définir une fonction » sur un palier suffisant (ex. palier 3 — appliquer), et que seul `+` sur des nombres est nouveau → l'activité respecte le budget de nouveauté (A3) : une seule notion non attestée.
- Si les **deux** notions (fonction ET addition) sont encore non attestées → l'activité dépasse le budget A3 pour une activité **évaluée**. Il faudrait alors soit la traiter comme démonstration/pratique accompagnée (libre, A1), soit la décomposer (ex. d'abord attester `def`/`return` sur une fonction triviale déjà fournie, puis attester l'addition dans une fonction déjà squelettée).

Avez-vous un état des paliers pour cet apprenant sur ces notions ? Sans cela je ne peux pas trancher si c'est « une nouvelle notion » (au singulier) ou deux.
