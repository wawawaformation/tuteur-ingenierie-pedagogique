Je ne trouve dans le répertoire courant qu'un seul fichier, `test-contradiction.md`, qui contient une seule phrase : « Une Activité peut viser deux paliers cognitifs simultanément. » Il n'y a ni fichier de définition de "skill" (règles, gabarit, contraintes pédagogiques) ni contenu source (thème, niveau, objectifs) permettant de rédiger une activité concrète.

Pouvez-vous préciser :
