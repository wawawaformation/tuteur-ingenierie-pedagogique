Notion mobilisée : « écrire et tester une fonction Python » — déjà attestée (donné par l'énoncé). La tâche ci-dessous n'introduit aucune notion nouvelle, elle réapplique cette compétence à un cas simple (palier 3 — Appliquer). Budget de nouveauté respecté (0 notion non attestée).

**Tâche proposée**

OPO : À partir d'un fichier Python vide, l'apprenant sera capable d'**écrire** une fonction nommée `multiplier` prenant deux paramètres numériques et retournant leur produit (Comportement), **sans utiliser de bibliothèque externe, en s'appuyant uniquement sur les mêmes outils que pour ses fonctions précédentes** (Conditions), **de sorte que la fonction produise le bon résultat sur au moins 3 tests couvrant un cas avec deux entiers positifs, un cas avec un nombre négatif, et un cas avec un flottant** (Critères).

Énoncé à donner à l'apprenant :

> Écris une fonction `multiplier(a, b)` qui reçoit deux nombres et retourne leur produit.
> Teste-la avec au moins 3 exemples de ton choix, dont un avec un nombre négatif et un avec un nombre flottant, et vérifie que les résultats sont corrects.

Preuve attendue : le code de la fonction + les tests exécutés montrant les résultats corrects.
