## USER

Crée un Atelier asynchrone sur les tests unitaires en Python.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-089/.claude/skills/tuteur-ingenierie-pedagogique/references/atelier.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-089/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-089/.claude/skills/tuteur-ingenierie-pedagogique/references/opo.md

## ASSISTANT

Voici la fiche d'Atelier asynchrone sur les tests unitaires en Python.

**État des paliers (A2)** — notions mobilisées :

| Notion | Palier requis | Statut |
|---|---|---|
| Écrire une fonction Python (paramètres, `return`) | 3 – Appliquer | Supposé attesté (prérequis d'entrée à l'atelier) |
| Tests unitaires avec `pytest` | 3 – Appliquer | **Non attesté — notion visée par cet atelier** |

Budget de nouveauté (A3) respecté : une seule notion nouvelle (`pytest`), la notion « écrire une fonction » est supposée déjà maîtrisée. Si ce n'est pas le cas pour l'apprenant visé, il faut d'abord une activité libre (A1) sur les fonctions avant de proposer cet atelier.

---

## Fiche remise à l'apprenant

### 1. Documents fournis
- Un fichier `calculs.py` contenant trois fonctions déjà écrites et fonctionnelles : `diviser(a, b)`, `est_pair(n)`, `moyenne(liste_nombres)`.
- Un fichier vide `test_calculs.py` comme point de départ.

### 2. Objectifs de l'atelier
- Installer et configurer `pytest` dans un environnement Python.
- Écrire des tests unitaires qui vérifient le comportement attendu d'une fonction, y compris les cas limites.
- Exécuter une suite de tests et interpréter un rapport d'échec.

### 3. Durée estimée
Entre 1h30 et 2h. Cette durée est indicative : elle dépend de votre aisance avec l'environnement Python et n'est en aucun cas un plafond — prenez le temps qu'il vous faut.

### 4. Organisation et outils
Vous êtes libre du choix de votre éditeur et de la façon dont vous gérez votre environnement virtuel. Seule contrainte : utiliser la bibliothèque `pytest` (et non `unittest`), pour rester cohérent avec l'objectif de l'atelier.

### 5. Méthode proposée
1. Installez `pytest` dans votre environnement de travail.
2. Placez `calculs.py` et `test_calculs.py` dans le même dossier.
3. Pour chaque fonction de `calculs.py`, écrivez au moins un test qui vérifie un cas normal (exemple : `moyenne([2, 4, 6])` renvoie bien `4`).
4. Ajoutez ensuite, pour chaque fonction, au moins un test qui vérifie un cas limite ou une erreur attendue (exemple : que `diviser(a, 0)` lève bien une exception).
5. Exécutez la suite de tests avec `pytest` et corrigez vos tests jusqu'à ce qu'ils passent tous.

### 6. Ce qui est supposé par défaut
- Les fonctions fournies dans `calculs.py` sont considérées comme correctes : l'atelier porte sur l'écriture des tests, pas sur la correction du code testé.
- `diviser(a, b)` est censée lever une `ZeroDivisionError` quand `b` vaut 0 — c'est un comportement volontaire du code fourni, pas un bug à corriger.
- Aucune convention de nommage des fonctions de test n'est imposée au-delà de celle exigée par `pytest` (préfixe `test_`).

> **Bon à savoir** — Le fichier `calculs.py` est volontairement minimal. En situation réelle, on teste rarement du code aussi simple : l'objectif ici est d'isoler la logique des tests, pas la complexité du code testé.

### 7. Livrable attendu
- Le fichier `test_calculs.py` complété, contenant l'ensemble de vos tests.
- Une copie-écran ou un export texte de la sortie de la commande `pytest` montrant que tous les tests passent.

### 8. Critère simple
*Si vous exécutez `pytest` et que le rapport annonce que tous les tests sont passés, sans qu'aucun n'ait été écrit pour toujours réussir quel que soit le résultat de la fonction, c'est gagné.*

> **Vigilance** — Un test qui ne vérifie rien (par exemple `assert True`) fait passer la suite sans rien prouver. Le critère de réussite porte sur la pertinence des vérifications, pas seulement sur le fait que `pytest` ne renvoie pas d'erreur.

---

## Volet formateur (non remis à l'apprenant)

**Production attendue** : au minimum 6 tests (un cas normal + un cas limite par fonction), utilisant `assert` et `pytest.raises` pour le cas de la division par zéro.

**Grille de correction :**
| Critère | Attendu |
|---|---|
| Couverture | Chaque fonction a au moins un test cas normal et un test cas limite |
| Usage de `pytest.raises` | Présent pour tester `ZeroDivisionError` sur `diviser` |
| Tests non triviaux | Aucun test du type `assert True` ou qui ne peut pas échouer |
| Exécution | La commande `pytest` s'exécute sans erreur de collecte et affiche le nombre de tests passés |

**Alignement 3C vérifié** : Comportement = écrire des tests (verbe « Utiliser/réaliser », palier 3) ; Conditions = à partir de fonctions déjà correctes fournies, avec `pytest` ; Critère = tests pertinents qui passent tous. Cohérent avec la section 8 remise à l'apprenant.
