## USER

Crée une activité dont l'objectif est :
« Expliquer avec ses propres mots ce qu'est une fonction Python. »

Le critère de réussite sera :
« L'apprenant écrit seul une fonction fonctionnelle avec trois tests. »

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-032/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-032/.claude/skills/tuteur-ingenierie-pedagogique/references/activite.md

## ASSISTANT

En appliquant le skill, je repère un problème d'alignement avant de rédiger la fiche.

**Décalage entre l'objectif et le critère de réussite :**

- Objectif « Expliquer avec ses propres mots ce qu'est une fonction Python » → verbe *expliquer/reformuler* = **palier 2 (Comprendre)**.
- Critère de réussite « L'apprenant écrit seul une fonction fonctionnelle avec trois tests » → *écrire, tester* = **palier 3 (Appliquer)**, voire plus si on exige l'autonomie complète.

Le gabarit d'Activité (`activite.md`) impose : *« Le critère de réussite du volet apprenant teste exactement le palier visé, ni plus haut ni plus bas »*. Ici le critère teste un palier plus haut que l'objectif annoncé — ce n'est pas une simple activité de reformulation, c'est une mise en pratique.

Trois façons de résoudre ça, selon ce que vous visez réellement :

## TOOL AskUserQuestion

[Alignement palier] Comment souhaitez-vous résoudre le décalage entre l'objectif (palier 2 – expliquer) et le critère de réussite (palier 3 – écrire une fonction testée) ?
Options: Garder le critère, monter l'objectif (Recommandé) | Garder l'objectif, adapter le critère | Deux activités séparées

## ASSISTANT

Bien sûr — qu'aimeriez-vous clarifier ou préciser avant qu'on tranche ce point d'alignement ?

## USER

Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-032/.claude/skills/tuteur-ingenierie-pedagogique/references/opo.md

## ASSISTANT

Je poursuis avec la résolution recommandée : l'objectif est relevé au palier 3 (Appliquer) pour correspondre exactement au critère de réussite fourni ; la reformulation orale devient une étape libre (non évaluée, A1) qui précède la production évaluée.

**Point de vigilance signalé, pas tranché silencieusement** : la clause A3 (budget de nouveauté = 1) suppose que « écrire un test simple (assert) » est déjà attesté chez l'apprenant. Si ce n'est pas le cas, cette activité mobilise deux notions non attestées à la fois (syntaxe de fonction *et* écriture de test) et perd sa valeur diagnostique. Je l'indique dans le volet formateur ci-dessous plutôt que de l'ignorer.

---

## Fiche d'Activité — Écrire une fonction Python testée

### Volet remis à l'apprenant

**1. Intention**
Vérifier qu'on sait transformer une définition de fonction en code qui marche vraiment, pas seulement en théorie.

**2. Consigne**
- D'abord, reformule à l'oral ou par écrit, avec tes propres mots, ce qu'est une fonction Python (à quoi ça sert, ce que ça prend, ce que ça renvoie) — pas noté, juste pour clarifier tes idées.
- Ensuite, **écris** une fonction Python de ton choix (ex. calculer une remise, convertir une température, valider un mot de passe...) et **écris** trois tests qui vérifient qu'elle fonctionne.

**3. Matériel de départ**
Un fichier vide `ma_fonction.py`.

**4. Contraintes**
- Une seule fonction, avec au moins un paramètre et un `return`.
- Les trois tests utilisent `assert` (pas besoin de framework de test).
- Aucune bibliothèque tierce requise.

**5. Critère de réussite**
En exécutant le fichier, les trois `assert` passent sans erreur — et si tu changes volontairement une valeur attendue dans un test, il doit échouer (preuve que le test teste vraiment quelque chose).

---

### Volet formateur

**1. Palier visé** : 3 — Appliquer.

**2. Notion nouvelle (A3)** : syntaxe de définition d'une fonction Python (`def`, paramètres, `return`).
⚠️ Prérequis supposé déjà attesté : écrire un test simple par `assert`. À vérifier dans `etat_des_paliers.md` avant de lancer l'activité — si ce n'est pas attesté, scinder en deux activités séparées (palier 2 sur les tests d'abord).

**3. Production attendue**
```python
def appliquer_remise(prix, pourcentage):
    return prix - (prix * pourcentage / 100)

assert appliquer_remise(100, 10) == 90
assert appliquer_remise(50, 0) == 50
assert appliquer_remise(200, 50) == 100
```

**4. Critères d'acceptation**
- La fonction est définie avec `def`, au moins un paramètre, un `return`.
- Les trois `assert` s'exécutent sans `AssertionError`.
- Un test modifié volontairement (valeur attendue fausse) déclenche bien une erreur.

**5. Erreur fréquente attendue et sa reformulation**
Erreur probable : la fonction utilise `print()` au lieu de `return`, donc les `assert` échouent même si le calcul est correct.
Diagnostic à poser à l'apprenant : « Qu'est-ce que ta fonction renvoie à celui qui l'appelle, concrètement ? » — plutôt que « c'est faux ».
