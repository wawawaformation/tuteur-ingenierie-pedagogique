## USER

L'apprenant n'a jamais vu les décorateurs Python.
Montre-lui un exemple concret de décorateur déjà écrit et explique ce qu'il fait.
Ne lui demande pas de produire du code.

## ASSISTANT

Voici un décorateur Python concret et courant : mesurer le temps d'exécution d'une fonction.

```python
import time
from functools import wraps

def chrono(fonction):
    @wraps(fonction)
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = fonction(*args, **kwargs)
        duree = time.time() - debut
        print(f"{fonction.__name__} a pris {duree:.4f} secondes")
        return resultat
    return wrapper


@chrono
def calcul_long(n):
    total = 0
    for i in range(n):
        total += i
    return total


calcul_long(10_000_000)
```

Ce que fait ce code, étape par étape :

**1. `chrono` est une fonction qui prend une autre fonction en paramètre**
`fonction` ici, c'est `calcul_long` — le décorateur reçoit "la fonction à décorer".

**2. Elle définit une fonction interne `wrapper`**
C'est cette fonction `wrapper` qui va réellement s'exécuter à la place de `calcul_long` quand on l'appelle. Elle :
- note l'heure de début,
- appelle la vraie fonction (`fonction(*args, **kwargs)`) et récupère son résultat,
- calcule le temps écoulé,
- affiche la durée,
- puis renvoie le résultat comme si de rien n'était.

**3. `chrono` renvoie `wrapper`**
Donc après décoration, `calcul_long` ne pointe plus vers la fonction d'origine, mais vers `wrapper`.

**4. La syntaxe `@chrono` au-dessus de `def calcul_long(n):`**
C'est un raccourci strictement équivalent à écrire :
```python
calcul_long = chrono(calcul_long)
```

Autrement dit, `@chrono` "enveloppe" la fonction dans un comportement supplémentaire (ici, du chronométrage) sans toucher au code interne de `calcul_long`.

**Pourquoi `@wraps(fonction)` ?**
Sans ça, `calcul_long.__name__` deviendrait `"wrapper"` au lieu de `"calcul_long"` — `@wraps` préserve les métadonnées (nom, docstring) de la fonction d'origine.

**L'idée générale** : un décorateur permet d'ajouter du comportement (logging, chronométrage, vérification de droits, mise en cache, etc.) *autour* d'une fonction, sans modifier son code, et de réutiliser ce comportement sur n'importe quelle autre fonction juste en ajoutant `@chrono` au-dessus.
