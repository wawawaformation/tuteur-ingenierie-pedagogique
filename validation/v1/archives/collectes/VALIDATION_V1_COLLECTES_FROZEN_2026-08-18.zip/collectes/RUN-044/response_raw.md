Avant de valider cette activité évaluée, il faut vérifier le budget de nouveauté (règle A3 du skill) : **une activité évaluée ne peut mobiliser qu'une seule notion non attestée**.

Or l'activité proposée mobilise au moins quatre notions distinctes :

| Notion | Palier attesté connu |
|---|---|
| Héritage de classe (POO Python) | ? |
| **Décorateurs Python** | **non attesté — jamais utilisé** |
| API de base des middlewares LangChain (classe de base, méthodes à surcharger) | ? |
| Clé de redirection du graphe (concept propre au graphe LangChain) | ? |

Je ne connais le statut que d'une seule de ces notions (décorateurs = non attesté). Si l'héritage, l'API des middlewares LangChain et la clé de redirection ne sont pas déjà attestés (au sens des Critères 3C, pas juste "vus en démo"), l'activité dépasse le budget de nouveauté : en cas d'échec, impossible de savoir si le problème vient des décorateurs, de l'héritage, de l'API LangChain ou du concept de redirection.

Peux-tu me dire, pour les trois autres notions du tableau, si l'apprenant les a déjà pratiquées avec preuve (code produit seul, sans aide) ? Selon la réponse :

- si tout le reste est attesté → l'activité est valide telle quelle, le décorateur étant la seule variable neuve ;
- sinon → je la décompose en étapes (ex. : d'abord écrire le middleware par héritage sans décorateur ni redirection avancée, puis une activité suivante ajoutant seulement le décorateur une fois le reste solide).
