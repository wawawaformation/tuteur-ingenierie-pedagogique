Avant de plonger dans le code, j'aimerais savoir où tu en es pour ne pas te réexpliquer des choses que tu maîtrises déjà.

Deux questions rapides :

1. **Qu'est-ce qui t'amène aux décorateurs ?** Tu as croisé `@quelque_chose` dans du code (Flask, pytest, un chrono...) et tu veux comprendre ce que ça fait, ou tu as un besoin précis en tête (mesurer le temps d'exécution, logger des appels, vérifier des droits...) ?

2. **En Python, est-ce que tu as déjà manipulé des fonctions comme ça** :
   ```python
   def dire_bonjour():
       print("Bonjour")

   f = dire_bonjour   # sans les parenthèses
   f()
   ```
   Ce genre d'écriture (assigner une fonction à une variable, ou passer une fonction en argument d'une autre fonction) te dit quelque chose, ou c'est nouveau ?

D'accord, je pars sur un cas concret classique : un **décorateur qui mesure le temps d'exécution d'une fonction** — utile pour repérer quelle fonction est lente dans un programme.

On va construire ça brique par brique. Avant le décorateur lui-même, il faut un prérequis : **en Python, une fonction est une valeur comme une autre**. On peut l'assigner à une variable, la passer en argument, la retourner depuis une autre fonction. Regarde :

```python
def dire_bonjour():
    print("Bonjour")

f = dire_bonjour   # on assigne la fonction (sans l'appeler, donc sans parenthèses)
f()                # -> affiche "Bonjour"
```

**Question rapide pour caler le point de départ** : dans ce code, `f = dire_bonjour` puis `f()` — est-ce que tu vois pourquoi ça marche (qu'est-ce que `f` contient exactement) ? Réponds avec tes mots, même approximatif, ça me dit où démarrer la suite.
