## USER

Crée un Atelier asynchrone sur les tests unitaires en Python.

## ASSISTANT

# Atelier asynchrone : Tests unitaires en Python

Format conçu pour être suivi en autonomie (async), sur ~1 semaine, avec des livrables vérifiables à chaque étape. Durée totale estimée : 4-6h.

## Objectifs pédagogiques
À la fin de l'atelier, les participants savent :
- Écrire des tests unitaires avec `pytest`
- Utiliser fixtures, paramétrage et mocks
- Mesurer et interpréter la couverture de code
- Intégrer les tests dans un pipeline CI

## Prérequis
- Python 3.10+, notions de base (fonctions, classes, exceptions)
- `pip install pytest pytest-cov pytest-mock`

---

## Module 1 — Les fondamentaux (45 min)
**Contenu :** différence test unitaire / intégration, anatomie d'un test (`arrange-act-assert`), convention de nommage `test_*.py`.

**Exercice :** écrire un module `calculator.py` (add, subtract, divide) puis 5 tests dans `test_calculator.py`, incluant un test qui vérifie qu'une `ZeroDivisionError` est bien levée (`pytest.raises`).

**Livrable :** `pytest -v` doit afficher 5 tests verts.

## Module 2 — Fixtures et setup/teardown (45 min)
**Contenu :** `@pytest.fixture`, portée (`function`, `module`, `session`), `yield` pour le teardown.

**Exercice :** créer une fixture qui instancie une classe `Panier` avec 3 articles préchargés, et l'utiliser dans au moins 3 tests différents (ajout, suppression, total).

**Livrable :** au moins une fixture avec `yield` et un `print`/log prouvant que le teardown s'exécute.

## Module 3 — Paramétrage (30 min)
**Contenu :** `@pytest.mark.parametrize`, éviter la duplication de tests.

**Exercice :** transformer 4 tests répétitifs (ex : validation d'email) en un seul test paramétré couvrant 8 cas (valides/invalides).

**Livrable :** un test paramétré avec au moins 6 jeux de données.

## Module 4 — Mocks et dépendances externes (60 min)
**Contenu :** `unittest.mock` / `pytest-mock`, `monkeypatch`, isoler le code d'un appel réseau ou d'accès disque.

**Exercice :** écrire une fonction `get_weather(city)` qui appelle une API externe (via `requests`), puis un test qui mock l'appel pour ne jamais toucher le réseau.

**Livrable :** le test passe sans connexion internet (`--disable-socket` si dispo, sinon vérification manuelle).

## Module 5 — Couverture de code (30 min)
**Contenu :** `pytest --cov`, lire un rapport de couverture, identifier les branches non testées.

**Exercice :** atteindre 90% de couverture sur le module `calculator.py` + `Panier`, en ajoutant les tests manquants.

**Livrable :** capture ou export du rapport `pytest --cov=. --cov-report=term-missing`.

## Module 6 (bonus) — CI et bonnes pratiques (30 min)
**Contenu :** intégrer `pytest` dans GitHub Actions, notion de test flaky, TDD en 3 phrases.

**Exercice :** écrire un fichier `.github/workflows/tests.yml` minimal qui lance `pytest` à chaque push.

---

## Modalités asynchrones
- **Support :** dépôt Git partagé avec un dossier par module (`module1/`, `module2/`, ...) contenant l'énoncé en `README.md`
- **Suivi :** chaque participant pousse ses solutions sur une branche `atelier/<prenom>` ; auto-correction via un script `check.py` fourni qui lance les tests attendus
- **Entraide :** canal Slack/Discord dédié pour poser des questions, pas de session live obligatoire
- **Deadline souple :** 1 semaine, avec un point de rétro asynchrone (thread écrit) en fin de semaine

## Auto-évaluation (à la fin)
Checklist pour chaque participant :
- [ ] Tous les tests passent (`pytest -v`)
- [ ] Couverture ≥ 90% sur le code métier
- [ ] Au moins 1 fixture, 1 test paramétré, 1 mock utilisés
- [ ] Pipeline CI fonctionnel (module bonus)

Voulez-vous que j'adapte la durée, le niveau (débutant/avancé), ou que je détaille davantage un module en particulier (par exemple avec le code des exercices) ?
