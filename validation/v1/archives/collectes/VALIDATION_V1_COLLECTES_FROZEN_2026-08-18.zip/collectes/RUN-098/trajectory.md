## USER

Je veux construire une formation synchrone en présentiel.
Découpe une séquence de 3 heures.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-098/.claude/skills/tuteur-ingenierie-pedagogique/references/decoupage_pedagogique.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-098/.claude/skills/tuteur-ingenierie-pedagogique/references/sequence.md

## ASSISTANT

Pour construire cette fiche de séquence (3h en présentiel = niveau "Séquence" selon le référentiel), j'ai besoin de quelques éléments de cadrage.

## TOOL AskUserQuestion

[Thématique] Quelle est la compétence ou thématique visée par cette séquence de 3h ?
Options: Autre (préciser)

## ASSISTANT

Pour construire cette fiche de séquence, j'ai besoin de connaître :

1. **La thématique / compétence visée** (ex : "Sécuriser une API REST", "Introduction à la gestion de projet agile"...)
2. **Le public cible** et ses prérequis supposés
3. **Le contexte métier** dans lequel s'inscrit cette séquence (module amont/aval, s'il y en a)

Pouvez-vous me préciser ces éléments ?

## USER

Je veux construire la même formation entièrement asynchrone.
Découpe une séquence de 3 heures.

## ASSISTANT

Deux points à signaler avant de continuer :

1. **Le sujet n'a pas encore été précisé** — j'attends toujours la thématique/compétence visée, le public cible et le contexte métier (question posée au tour précédent).

2. **Écart de calibrage sur la durée** : en asynchrone, le référentiel que j'utilise associe le niveau **Séquence** à 8-15h (temps de production du livrable inclus), tandis que 3h correspond plutôt à l'échelle **Atelier** (1h30-3h, méthode en plusieurs étapes) — en asynchrone il n'y a pas de niveau "Séance" intermédiaire, on passe directement de la Séquence à l'Atelier/Quiz/Recul. Ces durées sont indicatives (pas un critère absolu de niveau), mais l'écart est net donc je préfère vous le signaler plutôt que trancher seul.

Souhaitez-vous que je traite cette demande comme :

## TOOL AskUserQuestion

[Échelle visée] Comment souhaitez-vous traiter ces 3h en asynchrone ?
Options: Un Atelier de 3h (Recommandé) | Une Séquence complète malgré l'écart

## USER

[Request interrupted by user for tool use]
