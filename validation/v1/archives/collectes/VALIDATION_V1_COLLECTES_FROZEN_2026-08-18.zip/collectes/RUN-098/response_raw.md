Pour construire cette fiche de séquence (3h en présentiel = niveau "Séquence" selon le référentiel), j'ai besoin de quelques éléments de cadrage.

Pour construire cette fiche de séquence, j'ai besoin de connaître :

1. **La thématique / compétence visée** (ex : "Sécuriser une API REST", "Introduction à la gestion de projet agile"...)
2. **Le public cible** et ses prérequis supposés
3. **Le contexte métier** dans lequel s'inscrit cette séquence (module amont/aval, s'il y en a)

Pouvez-vous me préciser ces éléments ?

Deux points à signaler avant de continuer :

1. **Le sujet n'a pas encore été précisé** — j'attends toujours la thématique/compétence visée, le public cible et le contexte métier (question posée au tour précédent).

2. **Écart de calibrage sur la durée** : en asynchrone, le référentiel que j'utilise associe le niveau **Séquence** à 8-15h (temps de production du livrable inclus), tandis que 3h correspond plutôt à l'échelle **Atelier** (1h30-3h, méthode en plusieurs étapes) — en asynchrone il n'y a pas de niveau "Séance" intermédiaire, on passe directement de la Séquence à l'Atelier/Quiz/Recul. Ces durées sont indicatives (pas un critère absolu de niveau), mais l'écart est net donc je préfère vous le signaler plutôt que trancher seul.

Souhaitez-vous que je traite cette demande comme :
