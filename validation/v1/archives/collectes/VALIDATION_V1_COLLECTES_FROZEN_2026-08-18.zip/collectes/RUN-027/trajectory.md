## USER

Je forme des développeurs Python adultes.
Crée-moi un exercice de 15 minutes pour leur apprendre les décorateurs Python.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-027/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-027/.claude/skills/tuteur-ingenierie-pedagogique/references/opo.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-027/.claude/skills/tuteur-ingenierie-pedagogique/references/activite.md

## ASSISTANT

Voici une fiche d'Activité (15 min, un seul palier visé) sur les décorateurs Python, pour un public de développeurs Python adultes.

## Volet remis à l'apprenant

**Intention** — Comprendre en pratique comment un décorateur intercepte l'appel d'une fonction, en écrivant le vôtre.

**Consigne** — À partir du fichier fourni, **écrivez** un décorateur `chrono` qui affiche le temps d'exécution de la fonction décorée, puis appliquez-le à `calculer()`.

**Matériel de départ** :
```python
import time

def calculer(n):
    """Simule un traitement un peu long."""
    total = sum(i**2 for i in range(n))
    time.sleep(0.5)
    return total

# TODO : décorer calculer avec @chrono
resultat = calculer(1000)
print(resultat)
```

**Contraintes** :
- Utiliser uniquement `time` et `functools.wraps` (pas de bibliothèque tierce).
- `chrono` doit accepter n'importe quels arguments positionnels et nommés (le décorateur doit rester générique).
- `calculer` doit continuer à retourner sa valeur normalement — le décorateur ne doit pas « avaler » le résultat.

**Critère de réussite** — En exécutant le script, vous voyez s'afficher le temps écoulé (ex: `calculer a mis 0.50s`) **et** la valeur de `resultat` s'affiche toujours correctement ensuite.

---

## Volet formateur

**Palier visé** : 3 — Appliquer (mettre en œuvre une méthode sur un cas simple, dans des conditions définies).

**Notion nouvelle (budget = 1)** : le mécanisme du décorateur — `@chrono` au-dessus de `def calculer` équivaut à `calculer = chrono(calculer)`, où `chrono` reçoit une fonction et retourne une fonction wrapper.
Prérequis supposés déjà attestés chez ce public (à vérifier avant l'activité, sinon la reporter) : fonctions comme objets de première classe, closures, `*args`/`**kwargs`.

**Production attendue** (code de référence) :
```python
import time
from functools import wraps

def chrono(fonction):
    @wraps(fonction)
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = fonction(*args, **kwargs)
        duree = time.time() - debut
        print(f"{fonction.__name__} a mis {duree:.2f}s")
        return resultat
    return wrapper

@chrono
def calculer(n):
    total = sum(i**2 for i in range(n))
    time.sleep(0.5)
    return total

resultat = calculer(1000)
print(resultat)
```

**Critères d'acceptation** :
- Le wrapper retourne bien `resultat` (pas de `return` oublié après l'appel de `fonction`).
- `*args, **kwargs` sont transmis tels quels à `fonction`, sans supposer une signature fixe.
- `@wraps(fonction)` est présent (même si son absence ne casse pas l'exécution, son omission signale que le mécanisme n'est pas pleinement compris — à noter mais ne bloque pas si le reste fonctionne).

**Erreur fréquente attendue et sa reformulation** :
Oubli du `return resultat` dans `wrapper` (le décorateur exécute la fonction mais avale la valeur, `resultat` vaut `None` à l'extérieur).
Diagnostic à formuler : *« Que retourne `wrapper` quand `fonction(*args, **kwargs)` a fini de s'exécuter ? »* — plutôt que « c'est faux, il manque un return ».
