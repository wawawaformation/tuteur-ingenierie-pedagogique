## USER

Explique les middlewares LangChain puis donne immédiatement
une spécification complète :

« Écris ton propre middleware qui hérite de la classe de base,
utilise le décorateur approprié et configure la clé de redirection du graphe. »

Je veux une activité évaluée et autonome.

## ASSISTANT

## Les middlewares LangChain

Dans le nouveau framework d'agents LangChain (`create_agent`, ex-`langchain.agents.middleware`), un **middleware** est un composant qui s'insère dans le graphe d'exécution de l'agent (construit sur LangGraph) pour intercepter et modifier le cycle : appel du modèle, appel des outils, entrée/sortie de l'agent — un peu comme les middlewares Express/Django s'insèrent dans le traitement d'une requête HTTP.

**Pourquoi** : garde-fous (guardrails), logging/observabilité, retry, caching, résumé automatique de l'historique, sélection dynamique du modèle, redaction de PII, limitation de coût/tokens, human-in-the-loop, etc. — sans toucher au code métier de l'agent.

**Points d'accroche (hooks) disponibles :**

| Hook | Moment | Décorateur équivalent |
|---|---|---|
| `before_agent` / `after_agent` | avant/après toute l'exécution de l'agent | `@before_agent` / `@after_agent` |
| `before_model` | juste avant l'appel au LLM | `@before_model` |
| `wrap_model_call` | englobe l'appel au LLM (avant + après, avec accès au retour) | `@wrap_model_call` |
| `after_model` | juste après la réponse du LLM | `@after_model` |
| `wrap_tool_call` | englobe l'exécution d'un outil | `@wrap_tool_call` |
| `dynamic_prompt` | recalcule le prompt système à chaque tour | `@dynamic_prompt` |

**Classe de base :** `langchain.agents.middleware.AgentMiddleware` (ou `AgentMiddlewarePayload`/état typé selon la version).

**Redirection du graphe :** chaque hook peut retourner un dict contenant la clé **`jump_to`**, qui pointe vers un nœud du graphe (`"model"`, `"tools"`, `"end"`) pour court-circuiter le flux normal — par exemple sauter directement à `"end"` si un garde-fou détecte un contenu interdit, sans appeler le modèle.

Deux façons d'écrire un middleware :
1. **Décorateur fonctionnel** (rapide, stateless) : `@before_model` sur une fonction.
2. **Classe héritant de `AgentMiddleware`** (stateful, réutilisable, testable) : on redéfinit une ou plusieurs méthodes (`before_model`, `wrap_model_call`, etc.), on peut y stocker de la config dans `__init__`, et on l'instancie dans la liste `middleware=[...]` passée à `create_agent`.

---

## Spécification de l'activité — « Écris ton propre middleware LangChain »

### Objectif pédagogique
À l'issue de l'activité, l'apprenant sait créer un middleware LangChain orienté classe, l'enregistrer dans un agent, et l'utiliser pour rediriger dynamiquement le flux du graphe.

### Prérequis
- Python 3.10+, `langchain` (version avec `create_agent` / `AgentMiddleware`) installé.
- Notions de base : agents LangChain, notion de nœud/graphe (LangGraph), décorateurs Python, héritage de classe.

### Contexte fourni à l'apprenant
```python
from langchain.agents import create_agent
from langchain.agents.middleware import AgentMiddleware, hook_config  # nom du décorateur selon version

# Un agent "métier" simple, déjà fonctionnel
def get_weather(city: str) -> str:
    """Retourne une météo factice pour une ville."""
    return f"Il fait 22°C et ensoleillé à {city}."

BASE_AGENT_TOOLS = [get_weather]
```

### Consigne (à réaliser seul, sans aide extérieure)
1. Crée une classe `BlocklistMiddleware` qui **hérite de `AgentMiddleware`**.
2. Dans `__init__`, accepte une liste de mots interdits (`banned_words: list[str]`) et stocke-la.
3. Implémente le hook approprié en utilisant **le décorateur correspondant sur la méthode** (ex. `@before_model` sur la méthode qui inspecte le dernier message utilisateur).
4. Si un mot banni est détecté dans le dernier message :
   - construis une réponse de refus,
   - **retourne un dict contenant la clé `jump_to`** positionnée sur `"end"` pour court-circuiter l'appel au modèle et terminer directement l'agent.
5. Si aucun mot banni n'est détecté, ne retourne rien (`None`) pour laisser le flux normal continuer.
6. Instancie l'agent avec :
   ```python
   agent = create_agent(
       model="...",
       tools=BASE_AGENT_TOOLS,
       middleware=[BlocklistMiddleware(banned_words=["arme", "explosif"])],
   )
   ```
7. Écris **3 tests autonomes** (`assert` ou `pytest`) :
   - un message neutre → l'agent répond normalement (le modèle est appelé),
   - un message contenant un mot banni → l'agent renvoie le message de refus sans appeler le modèle,
   - vérifie que `jump_to` est bien effectif (ex. via un mock ou un compteur d'appels au modèle qui doit rester à 0 dans le cas refusé).

### Livrable
Un unique fichier `blocklist_middleware.py` contenant : la classe, l'instanciation de l'agent, et les 3 tests, exécutable avec `python blocklist_middleware.py` ou `pytest`.

### Grille d'évaluation (autonome — l'apprenant s'auto-corrige avant/après remise)

| Critère | Points |
|---|---|
| Hérite bien de `AgentMiddleware` (pas de duck-typing) | 2 |
| Décorateur correct utilisé sur la bonne méthode de hook | 2 |
| `jump_to` correctement positionné sur `"end"` et fonctionnel (le modèle n'est pas appelé si refus) | 3 |
| Cas nominal (pas de mot banni) laisse le flux continuer normalement | 2 |
| Les 3 tests passent sans intervention manuelle | 3 |
| **Total** | **/12** |

**Seuil de réussite auto-évalué :** ≥ 9/12.

### Autonomie
- Aucune assistance requise : la doc officielle du module `langchain.agents.middleware` et le tableau des hooks ci-dessus suffisent.
- Auto-correction possible en exécutant les tests fournis dans la consigne (point 7) — un échec de test pointe directement vers le critère non rempli dans la grille.

### Durée estimée
45–60 minutes.
