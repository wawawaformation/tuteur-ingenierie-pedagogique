Je vais avoir besoin de précisions avant de rédiger la fiche.

Bien sûr, dites-moi ce que vous voulez préciser.

Comme aucune matière n'a été précisée, je pars sur un exemple simple de mathématiques (niveau collège). Voici la fiche, directement dans la conversation.

---

## Fiche d'activité — Résolution d'équations du premier degré

**Énoncé**

Résous les équations suivantes et vérifie ta solution en la remplaçant dans l'équation de départ.

1. `3x + 5 = 20`
2. `2(x − 4) = 10`
3. `7x − 3 = 2x + 12`
4. `5x + 8 = 3x − 6`
5. `(x + 1) / 2 = 4`

---

**Solution complète**

1. `3x + 5 = 20`
   → `3x = 15`
   → `x = 5`
   Vérification : `3×5 + 5 = 20` ✓

2. `2(x − 4) = 10`
   → `2x − 8 = 10`
   → `2x = 18`
   → `x = 9`
   Vérification : `2×(9−4) = 2×5 = 10` ✓

3. `7x − 3 = 2x + 12`
   → `7x − 2x = 12 + 3`
   → `5x = 15`
   → `x = 3`
   Vérification : `7×3 − 3 = 18` et `2×3 + 12 = 18` ✓

4. `5x + 8 = 3x − 6`
   → `5x − 3x = −6 − 8`
   → `2x = −14`
   → `x = −7`
   Vérification : `5×(−7) + 8 = −27` et `3×(−7) − 6 = −27` ✓

5. `(x + 1) / 2 = 4`
   → `x + 1 = 8`
   → `x = 7`
   Vérification : `(7+1)/2 = 4` ✓

---

Si vous aviez une matière ou un niveau précis en tête (programmation, français, autre exercice de maths, etc.), dites-le-moi et j'adapte la fiche.
