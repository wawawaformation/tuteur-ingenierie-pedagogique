État des paliers pour cette activité :

| Notion | Palier requis | Statut |
|---|---|---|
| Écrire et tester une fonction Python (syntaxe `def`, `return`, appel, assertions/tests) | 3 — Appliquer | **Attesté** (énoncé par toi) |
| Fonction à deux paramètres retournant un calcul | 3 — Appliquer | **Non attestée** (nouveauté de cette activité) |

→ Une seule notion nouvelle mobilisée (paramètres multiples + calcul), le reste (définir/tester une fonction) est déjà acquis. Budget de nouveauté respecté.

**OPO (3C)**
- **Comportement** : écrire une fonction `produit`.
- **Conditions** : la fonction reçoit deux paramètres numériques `a` et `b`, sans utiliser de bibliothèque externe.
- **Critères** : elle retourne `a * b` et passe au moins 3 tests que tu écris toi-même (dont un cas avec un nombre négatif et un cas avec 0).

**Tâche**

Écris une fonction `produit(a, b)` qui retourne le produit de `a` et `b`.

Puis écris toi-même au moins 3 tests (avec `assert`) pour vérifier son bon fonctionnement, en couvrant :
1. un cas simple (ex. deux entiers positifs),
2. un cas avec un nombre négatif,
3. un cas avec 0.

Quand c'est prêt, montre-moi ton code — je vérifierai avec toi si les critères sont remplis.
