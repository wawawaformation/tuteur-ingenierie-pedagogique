## USER

L'apprenant n'a jamais utilisé les décorateurs Python.
Donne-lui une activité évaluée dans laquelle il doit écrire seul un décorateur.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-070/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-070/.claude/skills/tuteur-ingenierie-pedagogique/references/activite.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-070/.claude/skills/tuteur-ingenierie-pedagogique/references/opo.md

## ASSISTANT

Notion nouvelle : le **décorateur**. Pour respecter A3 (une seule notion non attestée), je pars du principe que les prérequis suivants sont déjà attestés chez l'apprenant : fonctions comme objets de première classe, fonctions imbriquées, `*args`/`**kwargs`. Si l'un de ces prérequis n'est pas acquis, dis-le-moi et je décompose davantage avant.

**Palier visé : 3 — Appliquer** (mettre en œuvre le patron décorateur sur un cas simple, avec un canevas fourni — pas de conception libre, ce serait le palier 6).

---

## Volet remis à l'apprenant

**Intention** : Écrire un décorateur qui chronomètre l'exécution d'une fonction, pour comprendre comment Python permet d'ajouter un comportement à une fonction sans modifier son code.

**Consigne** : Écris un décorateur `chrono` qui, appliqué à n'importe quelle fonction, affiche son temps d'exécution en secondes après son appel, puis retourne le résultat normal de la fonction.

**Matériel de départ** :
```python
import time

def calcul_lent(n):
    total = 0
    for i in range(n):
        total += i
    return total

# Applique ton décorateur ici
@chrono
def calcul_lent(n):
    ...

resultat = calcul_lent(1_000_000)
print(resultat)
```

**Contraintes** :
- Tu peux utiliser `time.time()` ou `time.perf_counter()`.
- Le décorateur doit fonctionner avec une fonction qui prend n'importe quel nombre d'arguments (pas seulement `calcul_lent`).
- Le décorateur doit retourner la valeur que renvoie la fonction décorée — `resultat` doit contenir la vraie valeur, pas `None`.
- Pas de bibliothèque tierce (`functools.wraps` est optionnel, pas exigé).

**Critère de réussite** : En exécutant le script, tu vois s'afficher une durée en secondes, **et** `print(resultat)` affiche bien la somme calculée (pas `None`).

---

## Volet formateur

**Palier visé** : 3 — Appliquer.

**Notion nouvelle** : le décorateur (syntaxe `@`, fonction qui prend une fonction et retourne une fonction).

**Production attendue** :
```python
import time

def chrono(func):
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = func(*args, **kwargs)
        fin = time.time()
        print(f"Temps d'exécution : {fin - debut:.4f} secondes")
        return resultat
    return wrapper

@chrono
def calcul_lent(n):
    total = 0
    for i in range(n):
        total += i
    return total

resultat = calcul_lent(1_000_000)
print(resultat)
```

**Critères d'acceptation** (ce qui fait passer la ligne « décorateur : palier 3 » dans l'état des paliers) :
1. Le script s'exécute sans erreur.
2. La durée s'affiche avant la valeur de `resultat`.
3. `resultat` contient la vraie somme, pas `None`.
4. Le décorateur utilise `*args, **kwargs` dans `wrapper` (preuve qu'il ne l'a pas codé en dur pour un seul cas).

**Erreur fréquente attendue et sa reformulation** :
L'apprenant oublie le `return resultat` dans `wrapper` (il retourne implicitement `None`, ou oublie carrément de capturer la valeur de `func(...)`).
Diagnostic à poser, jamais « c'est faux » : *« Que reçoit `resultat` dans `resultat = calcul_lent(1_000_000)` — qu'est-ce que ta fonction `wrapper` renvoie exactement à la fin ? »*
