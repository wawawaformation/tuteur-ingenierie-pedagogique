## USER

Crée un quiz d'auto-positionnement Python avant une séquence sur les décorateurs.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-078/.claude/skills/tuteur-ingenierie-pedagogique/references/quiz.md

## ASSISTANT

Voici un quiz d'auto-positionnement sur les prérequis aux décorateurs Python (fonctions comme objets, fonctions imbriquées, *args/**kwargs, portée des variables), conforme au gabarit du skill (non noté, feedback immédiat, paliers 1-2 uniquement).

---

## Quiz d'auto-positionnement — Avant les décorateurs

**Intention** : ce quiz sert à repérer ce qui est déjà solide chez vous concernant les fonctions en Python — bases indispensables pour comprendre les décorateurs — et ce qui mérite d'être révisé avant d'aborder la séquence. Il n'est pas noté : l'objectif n'est pas de tout réussir, mais d'identifier ce qui est déjà acquis et ce qui mérite d'être approfondi.

---

**Q1.** On écrit ce code :
```python
def saluer():
    return "bonjour"

f = saluer
```
Que contient `f` ?

A. La chaîne `"bonjour"`
B. La fonction `saluer` elle-même
C. Une erreur, car `saluer` n'a pas été appelée avec `()`
D. `None`

**Réponse : B.**
*Feedback* : en Python, une fonction est un objet comme un autre. Écrire `saluer` sans parenthèses désigne la fonction elle-même, pas son résultat. `f` devient un second nom pour la même fonction ; `f()` produirait `"bonjour"`.

---

**Q2.** Quelle affirmation est vraie ?

A. Une fonction ne peut être passée en argument qu'à des fonctions natives comme `print`
B. On peut passer une fonction en argument à une autre fonction, comme n'importe quelle valeur
C. Passer une fonction en argument l'exécute immédiatement
D. Seules les méthodes, pas les fonctions, peuvent être passées en argument

**Réponse : B.**
*Feedback* : c'est la conséquence directe de « les fonctions sont des objets » — elles peuvent circuler comme des arguments, être stockées dans des variables ou des listes, être retournées par une autre fonction.

---

**Q3.** Que fait ce code ?
```python
def externe():
    def interne():
        return "je suis interne"
    return interne

x = externe()
```

A. `x` vaut `"je suis interne"`
B. `x` est la fonction `interne`, pas encore appelée
C. Une erreur, car `interne` n'existe pas hors de `externe`
D. `x` vaut `None`

**Réponse : B.**
*Feedback* : `externe()` s'exécute et retourne la fonction `interne` elle-même (sans l'appeler). Pour obtenir la chaîne, il faudrait écrire `x()`. C'est le mécanisme de base d'une fonction qui « fabrique » une autre fonction — central pour les décorateurs.

---

**Q4.** Dans l'exemple précédent, si on ajoute `print(x())`, qu'obtient-on ?

A. Une erreur
B. `interne`
C. `"je suis interne"`
D. `None`

**Réponse : C.**
*Feedback* : `x` désignait la fonction `interne` ; `x()` l'appelle et déclenche son exécution, qui retourne la chaîne.

---

**Q5.** Qu'est-ce qu'une closure (fonction imbriquée qui « capture » une variable) ?

A. Une fonction qui ne peut jamais accéder aux variables de la fonction qui l'entoure
B. Une fonction interne qui se souvient d'une variable de la fonction externe, même après que celle-ci a fini de s'exécuter
C. Une fonction qui referme (ferme) un fichier automatiquement
D. Un synonyme de méthode de classe

**Réponse : B.**
*Feedback* : c'est le point souvent contre-intuitif. La fonction externe a fini de s'exécuter, mais la fonction interne garde un lien vers la variable qu'elle utilisait. C'est exactement ce qui permet à un décorateur de « se souvenir » de la fonction qu'il décore.

---

**Q6.** Que fait `*args` dans une signature de fonction ?

A. Force l'appelant à donner exactement un argument nommé `args`
B. Regroupe tous les arguments positionnels non prévus dans un tuple
C. Multiplie les arguments entre eux
D. N'a aucun effet, c'est une convention stylistique sans portée

**Réponse : B.**
*Feedback* : `*args` permet à une fonction d'accepter un nombre variable d'arguments positionnels, rassemblés dans un tuple nommé `args`. Utile pour écrire une fonction « générique » qui doit s'adapter à n'importe quelle fonction qu'elle enveloppe.

---

**Q7.** Et `**kwargs` ?

A. Regroupe les arguments nommés (mot-clé) non prévus dans un dictionnaire
B. Sert uniquement pour les fonctions mathématiques
C. Est obligatoire dans toute définition de fonction
D. Remplace `*args`, ils ne peuvent pas coexister

**Réponse : A.**
*Feedback* : `**kwargs` capture les arguments passés par mot-clé (ex. `nom="Alice"`) dans un dictionnaire. `*args` et `**kwargs` coexistent fréquemment dans une même signature, notamment pour écrire une fonction capable d'en « envelopper » une autre sans connaître sa signature exacte.

---

**Q8.** Que produit ce code ?
```python
def multiplicateur(n):
    def multiplier(x):
        return x * n
    return multiplier

fois3 = multiplicateur(3)
print(fois3(5))
```

A. `15`
B. `3`
C. Une erreur, car `n` n'existe plus quand `multiplier` est appelée
D. `8`

**Réponse : A.**
*Feedback* : grâce à la closure, `multiplier` se souvient de `n = 3` même après la fin de `multiplicateur`. `fois3(5)` calcule donc `5 * 3 = 15`. Si ce résultat vous a surpris, c'est le signe qu'il vaut la peine de revoir les closures avant les décorateurs.

---

**Q9.** Une fonction peut-elle retourner une autre fonction ?

A. Non, une fonction ne peut retourner que des types simples (nombres, chaînes, listes)
B. Oui, une fonction est une valeur comme une autre et peut donc être retournée
C. Oui, mais uniquement si elle porte le mot-clé `return function`
D. Non, il faut obligatoirement utiliser une classe pour cela

**Réponse : B.**
*Feedback* : rien de spécial n'est requis. C'est la même idée qu'aux questions 1 et 3, vue sous l'angle du `return` plutôt que de l'affectation.

---

**Q10.** À quoi sert, selon vous, la syntaxe `@quelque_chose` juste au-dessus d'une définition de fonction (même si vous ne l'avez jamais utilisée) ?

A. C'est un commentaire, ignoré par Python
B. C'est une façon abrégée de faire quelque chose comme `fonction = quelque_chose(fonction)`
C. Cela déclare que la fonction est privée
D. Cela sert uniquement à l'import de modules

**Réponse : B.**
*Feedback* : c'est exactement ce que fait un décorateur : il remplace la fonction par le résultat d'un appel à une autre fonction, qui l'enveloppe. Il n'y a pas de mauvaise réponse ici si vous n'avez jamais vu cette syntaxe — l'objectif est justement de voir si l'intuition est déjà présente.

---

### Checklist auto-cochée

Cochez ce qui vous semble déjà familier (il est normal de ne pas tout cocher) :

- [ ] Je sais qu'une fonction en Python est un objet qu'on peut stocker dans une variable.
- [ ] J'ai déjà écrit une fonction qui en retourne une autre.
- [ ] J'ai déjà utilisé `*args` ou `**kwargs` dans une fonction que j'ai écrite moi-même.
- [ ] Je comprends pourquoi une fonction interne peut encore accéder à une variable de la fonction externe après la fin de celle-ci.
- [ ] J'ai déjà vu la syntaxe `@quelque_chose` sans forcément savoir comment elle fonctionne.

---

### Ce qu'il faut faire de son résultat

Ce quiz ne donne pas de score à interpréter seul. Repérez plutôt les questions où vous avez hésité ou été surpris :

- **Q1, Q2, Q9** ratées ou hésitantes → revoir *fonctions comme objets de première classe* avant tout le reste ; c'est le socle de toute la séquence.
- **Q3, Q4, Q5, Q8** ratées ou hésitantes → revoir *fonctions imbriquées et closures* ; c'est le point le plus souvent sous-estimé et celui qui bloque le plus dans la compréhension des décorateurs.
- **Q6, Q7** ratées ou hésitantes → revoir *`*args`/`**kwargs`* ; nécessaire pour écrire des décorateurs génériques, mais peut s'aborder en cours de séquence si le reste est solide.
- **Q10** : aucune réponse n'est « mauvaise » ici, c'est un indicateur d'intuition de départ, pas un prérequis.

**État des paliers** (voir `taxonomie.md`/`etat_des_paliers.md`) : ce quiz atteste au maximum le palier 2 (Comprendre) sur les notions listées — reconnaître/expliquer une closure via QCM n'équivaut pas à en écrire une. La production effective d'une closure ou d'un décorateur (palier 3) reste à évaluer par une activité dédiée dans la séquence.
