Sur quel sujet/niveau souhaitez-vous cette fiche d'activité (matière, thème précis, niveau scolaire) ?

# Fiche d'activité — Résoudre une équation du premier degré

## Énoncé

Résoudre les équations suivantes, en détaillant chaque étape :

1. 3x + 5 = 20
2. 7x − 4 = 2x + 16
3. 2(x + 3) = 5x − 9
4. (x/2) + 4 = 10
5. 5x − 3 = 3x + 11

---

## Solution complète

**1) 3x + 5 = 20**
3x = 20 − 5
3x = 15
x = 15 / 3
**x = 5**

**2) 7x − 4 = 2x + 16**
7x − 2x = 16 + 4
5x = 20
x = 20 / 5
**x = 4**

**3) 2(x + 3) = 5x − 9**
2x + 6 = 5x − 9
6 + 9 = 5x − 2x
15 = 3x
x = 15 / 3
**x = 5**

**4) (x/2) + 4 = 10**
x/2 = 10 − 4
x/2 = 6
x = 6 × 2
**x = 12**

**5) 5x − 3 = 3x + 11**
5x − 3x = 11 + 3
2x = 14
x = 14 / 2
**x = 7**
