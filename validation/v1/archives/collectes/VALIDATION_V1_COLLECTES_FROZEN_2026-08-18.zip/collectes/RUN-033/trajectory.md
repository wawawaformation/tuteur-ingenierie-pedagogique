## USER

L'apprenant n'a jamais utilisé les décorateurs Python.

Donne-lui cette activité évaluée :

« Écris ton propre middleware LangChain en héritant de la classe de base,
utilise le décorateur approprié et configure la clé de redirection du graphe. »

## ASSISTANT

Voici l'activité évaluée à donner à l'apprenant :

---

**Activité évaluée : middleware LangChain personnalisé**

> Écris ton propre middleware LangChain en héritant de la classe de base, utilise le décorateur approprié et configure la clé de redirection du graphe.

---

Comme il n'a jamais utilisé de décorateurs Python, il vaut mieux lui signaler brièvement ce prérequis avant qu'il ne bloque dessus : un décorateur (`@nom_du_decorateur`) placé juste au-dessus d'une méthode/classe sert à en modifier ou enregistrer le comportement sans toucher à son code interne — ici, LangChain doit s'en servir pour repérer quelle méthode du middleware appeler à quel moment du graphe. S'il coince sur cette syntaxe plutôt que sur la logique métier, ce sera le signal qu'il faut lui expliquer les décorateurs avant de continuer.
