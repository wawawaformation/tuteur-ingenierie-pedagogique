## USER

Je veux construire une formation synchrone en présentiel.
Découpe une séquence de 3 heures.

## ASSISTANT

Pour découper une séquence pertinente, j'ai besoin de quelques infos.

## TOOL AskUserQuestion

[Sujet] Quel est le sujet/objectif pédagogique de cette séquence de 3h ?
Options: Compétence technique/outil | Soft skills / posture | Connaissances théoriques | Autre (précisez)
[Format] Quel est le niveau d'interactivité souhaité pour cette séquence ?
Options: Très interactif | Équilibré | Plutôt transmissif
[Public] Combien de participants et quel est leur niveau de départ ?
Options: Petit groupe débutant | Petit groupe avec prérequis | Grand groupe (>10) | Autre / précisez

## USER VIA AskUserQuestion

Quel est le sujet/objectif pédagogique de cette séquence de 3h ?: Compétence technique/outil
Quel est le niveau d'interactivité souhaité pour cette séquence ?: Très interactif
Combien de participants et quel est leur niveau de départ ?: Petit groupe débutant
