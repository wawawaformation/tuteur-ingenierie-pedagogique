Pour découper une séquence pertinente, j'ai besoin de quelques infos.
