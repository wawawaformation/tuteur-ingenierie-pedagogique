## USER

L'apprenant sait faire des fonctions simples et des tests.

Je voudrais qu'il construise seul un mécanisme qui ajoute automatiquement
un comportement avant et après l'exécution d'une fonction.

Fais-moi une activité évaluée.

## ASSISTANT

Avant de rédiger l'activité, j'ai besoin de préciser le contexte pédagogique.

## TOOL AskUserQuestion

[Langage] Dans quel langage l'apprenant doit-il réaliser cette activité ?
Options: Python | JavaScript/TypeScript | Java | Autre (précisez)
[Niveau] Quel est le niveau/contexte de la formation pour calibrer la difficulté et le barème ?
Options: Débutant en autonomie | Intermédiaire | Peu importe / à toi de choisir

## USER VIA AskUserQuestion

Dans quel langage l'apprenant doit-il réaliser cette activité ?: Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.
Quel est le niveau/contexte de la formation pour calibrer la difficulté et le barème ?: Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## ASSISTANT

# Activité évaluée — "Le majordome de fonctions"

## Contexte pédagogique
Public : apprenant sait écrire des fonctions simples et des tests (unitaires). Il ne connaît pas encore les décorateurs — l'objectif est qu'il **redécouvre le mécanisme par lui-même**, sans qu'on lui donne le mot-clé ou la syntaxe à l'avance.

Durée estimée : 1h30 à 2h, en autonomie.

---

## Énoncé à donner à l'apprenant

### Mise en situation
Tu développes plusieurs fonctions métier (calculs, traitements de données...). Ton équipe te demande, pour chacune d'elles, de pouvoir :
- afficher un message **avant** son exécution (ex: `"Appel de la fonction X"`),
- afficher un message **après** son exécution, avec le **temps d'exécution**,
- sans jamais modifier le code interne des fonctions concernées.

Tu ne dois **pas** copier-coller ce comportement dans chaque fonction. Il doit être écrit **une seule fois** et pouvoir s'appliquer à **n'importe quelle fonction**, quels que soient son nom, ses arguments et sa valeur de retour.

### Consignes

1. Écris au moins deux fonctions métier de test, par exemple :
   - `addition(a, b)` qui retourne `a + b`
   - `attendre_et_saluer(nom)` qui fait une petite pause puis retourne `f"Bonjour {nom}"`

2. Construis un mécanisme générique — une fonction, ou tout autre outil que tu juges pertinent — capable de :
   - prendre en entrée n'importe quelle fonction,
   - retourner une nouvelle version de cette fonction qui exécute automatiquement un comportement **avant** et **après** l'appel,
   - conserver le bon fonctionnement de la fonction d'origine (arguments, valeur de retour).

3. Ton mécanisme doit fonctionner **sans connaître à l'avance** le nombre ou le nom des arguments de la fonction ciblée.

4. Écris des **tests** qui prouvent que :
   - la fonction décorée renvoie toujours le bon résultat,
   - le comportement "avant" et "après" s'exécute bien (tu peux capturer les sorties, ou utiliser un compteur/log dans une liste pour vérifier).

5. Applique ton mécanisme à tes deux fonctions métier sans modifier leur code source.

### Contraintes
- Le code du comportement "avant/après" ne doit exister qu'à un seul endroit.
- Aucune duplication du code de logging/chronométrage dans les fonctions métier.
- Le mécanisme doit être réutilisable tel quel sur une troisième fonction que tu inventeras pour la démo finale.

### Livrables
- Un fichier de code contenant : les fonctions métier, le mécanisme générique, son application aux fonctions.
- Un fichier de tests.
- Un court paragraphe (5 lignes max) expliquant avec tes mots comment fonctionne ton mécanisme.

---

## Grille d'évaluation (/20)

| Critère | Points |
|---|---|
| Le mécanisme s'applique à une fonction avec un nombre variable d'arguments | 4 |
| Le comportement "avant" s'exécute correctement | 3 |
| Le comportement "après" s'exécute correctement (et a accès au résultat / temps écoulé) | 3 |
| La valeur de retour de la fonction d'origine est préservée | 3 |
| Aucune duplication de code entre les fonctions décorées | 3 |
| Tests couvrant résultat + comportement avant/après | 3 |
| Explication claire du fonctionnement (paragraphe) | 1 |

**Bonus (+2)** : le mécanisme accepte un paramètre de configuration (ex: activer/désactiver le chronométrage, personnaliser le message).

---

## Indices à donner seulement si l'apprenant bloque (à révéler progressivement)
1. *"Une fonction peut-elle prendre une autre fonction en paramètre, et en renvoyer une nouvelle ?"*
2. *"Comment appeler une fonction dont tu ne connais pas les arguments à l'avance ?"* (→ `*args, **kwargs`)
3. *"Que se passe-t-il si tu définis une fonction à l'intérieur d'une autre fonction ?"* (→ closures)

Ne pas mentionner "décorateur" ni la syntaxe `@` avant la correction — laisser l'apprenant y arriver seul ou proche de la solution ; révéler ensuite que Python offre une syntaxe sucrée (`@mon_mecanisme`) pour ce qu'il vient de construire.
