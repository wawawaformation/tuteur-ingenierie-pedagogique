## USER

L'apprenant sait faire des fonctions simples et des tests.

Je voudrais qu'il construise seul un mécanisme qui ajoute automatiquement
un comportement avant et après l'exécution d'une fonction.

Fais-moi une activité évaluée.

## TOOL AskUserQuestion

[Langage] Dans quel langage/contexte l'apprenant doit-il réaliser cette activité ?
Options: Python (décorateurs) | JavaScript (higher-order functions) | Autre langage

## USER VIA AskUserQuestion

Dans quel langage/contexte l'apprenant doit-il réaliser cette activité ?: Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## ASSISTANT

# Activité évaluée — Construire un mécanisme "avant/après" autour d'une fonction

## Contexte
L'apprenant sait écrire des fonctions et des tests. L'objectif est qu'il découvre et implémente **seul** le mécanisme qui permet d'exécuter du code avant et après l'appel d'une fonction, sans modifier le code de cette fonction. C'est le principe des *décorateurs* (Python) / des *wrappers* (JS) — mais on ne donne pas ce mot-clé dans l'énoncé : c'est à l'apprenant de le retrouver en résolvant le problème.

## Énoncé à donner à l'apprenant

> Tu dois écrire une fonction `chronometre(fonction)` qui prend une fonction en paramètre et retourne **une nouvelle fonction**. Quand on appelle cette nouvelle fonction :
> 1. elle affiche `"Début de <nom_de_la_fonction>"` ;
> 2. elle exécute la fonction d'origine avec les arguments reçus ;
> 3. elle affiche `"Fin de <nom_de_la_fonction>"` ;
> 4. elle retourne exactement ce que la fonction d'origine aurait retourné.
>
> Contraintes :
> - `chronometre` doit fonctionner avec **n'importe quelle fonction**, quel que soit son nombre de paramètres (0, 1, 2, ou plus).
> - Le code de la fonction d'origine ne doit **jamais être modifié**.
> - Le mécanisme doit être réutilisable sur plusieurs fonctions différentes sans dupliquer de code.
>
> Tu dois fournir :
> - le fichier contenant `chronometre` ;
> - une suite de tests qui prouve que le mécanisme fonctionne (résultat correct, arguments correctement transmis, plusieurs fonctions différentes décorées).

Donner ensuite les **tests imposés** (non modifiables) que l'apprenant doit faire passer sans les voir avant, ou les fournir directement selon le niveau d'autonomie voulu. Exemple de tests imposés (à adapter au langage choisi) :

```python
def addition(a, b):
    return a + b

def salut():
    return "bonjour"

addition_surveillee = chronometre(addition)
assert addition_surveillee(2, 3) == 5

salut_surveille = chronometre(salut)
assert salut_surveille() == "bonjour"
```

## Ce que ça force à découvrir seul
- Qu'une fonction peut retourner une fonction.
- Qu'il faut une fonction interne (*closure*) qui garde une référence vers la fonction d'origine.
- Comment transmettre un nombre variable d'arguments (`*args, **kwargs` en Python / `...args` en JS).
- Que le résultat doit être capturé puis renvoyé après l'affichage de fin (pas avant).

## Grille d'évaluation (/20)

| Critère | Points |
|---|---|
| `chronometre` accepte n'importe quelle fonction et nombre d'arguments | 6 |
| Le résultat retourné est strictement identique à celui de la fonction d'origine | 4 |
| Les affichages avant/après sont corrects et dans l'ordre | 3 |
| Le code d'origine n'est pas modifié / mécanisme réutilisable sans duplication | 3 |
| Tests écrits par l'apprenant couvrant au moins 2 fonctions différentes et un cas avec arguments | 4 |

## Bonus possible (facultatif, à annoncer ou non)
Demander ensuite d'ajouter une variante qui mesure le **temps d'exécution réel** (avant/après avec un timestamp) plutôt qu'un simple message texte — cela réutilise le même mécanisme et vérifie que l'apprenant a bien compris la généricité de sa solution, sans qu'il ait à tout réécrire.

---

Je suis parti sur une version **Python** (cas le plus naturel pour ce mécanisme). Dites-moi si vous voulez que je l'adapte en JavaScript ou un autre langage, ou que j'ajuste le niveau de guidage (plus ou moins d'indices).
