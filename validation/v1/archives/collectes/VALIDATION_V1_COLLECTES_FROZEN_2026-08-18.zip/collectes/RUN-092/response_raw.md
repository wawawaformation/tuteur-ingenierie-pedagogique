Voici l'activité :

---

## Activité : Qu'est-ce qu'une fonction Python ?

**Niveau :** Débutant
**Durée estimée :** 30 minutes

### Objectif
Expliquer avec ses propres mots ce qu'est une fonction Python.

### Déroulé

**1. Découverte (10 min)**
Observer ce petit exemple :

```python
def addition(a, b):
    resultat = a + b
    return resultat

print(addition(3, 4))   # 7
print(addition(10, 5))  # 15
```

Répondre à l'oral ou à l'écrit :
- Que se passe-t-il quand on appelle `addition(3, 4)` ?
- Pourquoi peut-on réutiliser `addition` plusieurs fois avec des valeurs différentes ?
- À quoi servent `a` et `b` ?

**2. Formulation personnelle (10 min)**
L'apprenant rédige en 3 à 5 phrases, avec ses propres mots (pas de copier-coller de définition), ce qu'est une fonction Python : à quoi ça sert, ce que sont les paramètres, ce que fait `return`.

**3. Application pratique (10 min)**
L'apprenant écrit lui-même une fonction de son choix (ex : calculer une aire, convertir une température, dire si un nombre est pair) puis l'appelle avec **trois cas de test différents** pour vérifier qu'elle fonctionne, par exemple :

```python
def est_pair(n):
    return n % 2 == 0

print(est_pair(4))   # True
print(est_pair(7))   # False
print(est_pair(0))   # True
```

### Critère de réussite
✅ L'apprenant écrit seul une fonction fonctionnelle avec trois tests (trois appels couvrant des cas différents, dont les résultats sont cohérents avec ce qu'elle est censée faire).

### Grille d'évaluation rapide

| Critère | Validé ? |
|---|---|
| La fonction est syntaxiquement correcte (`def`, `:`, indentation) | ☐ |
| Elle contient au moins un paramètre ou une logique claire | ☐ |
| Elle retourne (ou affiche) un résultat cohérent | ☐ |
| Trois appels de test sont présents | ☐ |
| Les trois tests couvrent des cas différents (pas trois fois la même chose) | ☐ |
