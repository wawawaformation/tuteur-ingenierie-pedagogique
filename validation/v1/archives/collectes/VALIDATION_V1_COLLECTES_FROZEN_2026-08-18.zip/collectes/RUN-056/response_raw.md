Non, ce n'est pas une nouvelle notion — c'est un exercice classique de premier niveau. Elle combine deux notions déjà de base en programmation :

1. **Définition de fonction** (`def`, paramètres, `return`)
2. **Opérateur arithmétique** `+`

Exemple de solution :

```python
def addition(a, b):
    return a + b
```

Si l'activité fait partie d'une progression pédagogique, elle sert probablement à consolider la syntaxe des fonctions plutôt qu'à introduire un concept inédit — sauf si c'est la toute première fois que les fonctions sont abordées dans la séquence.
