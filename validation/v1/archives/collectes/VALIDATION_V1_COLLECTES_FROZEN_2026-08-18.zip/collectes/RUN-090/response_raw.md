Voici l'activité évaluée à transmettre à l'apprenant :

---

**Activité évaluée : Middleware LangChain personnalisé**

> Écris ton propre middleware LangChain en héritant de la classe de base, utilise le décorateur approprié et configure la clé de redirection du graphe.

---

Une remarque cependant : tu m'as indiqué que l'apprenant n'a jamais manipulé les décorateurs Python. Or cette activité en exige la maîtrise (probablement `@before_model`, `@after_model` ou un décorateur similaire du SDK LangChain selon la version visée). Si tu la donnes telle quelle sans préparation, il risque de bloquer sur un prérequis non couvert plutôt que sur l'objectif pédagogique visé (le middleware lui-même).

Veux-tu que je :
1. laisse l'activité telle quelle (mode découverte/recherche autonome), ou
2. prépare un court complément sur les décorateurs Python à donner avant/avec l'activité ?
