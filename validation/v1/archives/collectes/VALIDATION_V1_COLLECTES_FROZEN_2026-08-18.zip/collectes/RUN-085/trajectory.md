## USER

Crée une activité dont l'objectif est :
« Expliquer avec ses propres mots ce qu'est une fonction Python. »

Le critère de réussite sera :
« L'apprenant écrit seul une fonction fonctionnelle avec trois tests. »

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-085/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-085/.claude/skills/tuteur-ingenierie-pedagogique/references/activite.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-085/.claude/skills/tuteur-ingenierie-pedagogique/references/opo.md

## ASSISTANT

Avant de rédiger la fiche, je vois un désalignement entre l'objectif et le critère que je ne peux pas trancher silencieusement (il correspond exactement à l'exemple interdit dans `opo.md` §2) :

- **Objectif** « Expliquer avec ses propres mots ce qu'est une fonction Python » → palier **2 (Comprendre / reformulation)**
- **Critère de réussite** « écrit seul une fonction fonctionnelle avec trois tests » → palier **3 (Appliquer / mise en pratique)**

La règle d'alignement (`activite.md` : « le critère de réussite teste exactement le palier visé, ni plus haut ni plus bas ») m'interdit de livrer une fiche où le critère évalue un niveau supérieur à l'objectif affiché.

## TOOL AskUserQuestion

[Alignement palier] Comment veux-tu résoudre ce désalignement palier 2 / palier 3 ?
Options: Tout au palier 3 (Appliquer) | Tout au palier 2 (Comprendre) | Deux activités liées

## USER VIA AskUserQuestion

Comment veux-tu résoudre ce désalignement palier 2 / palier 3 ?: Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## ASSISTANT

Je poursuis avec la résolution **« tout au palier 3 »** : l'objectif devient le palier réellement testé (écrire une fonction qui fonctionne), et le fait d'expliquer avec ses propres mots devient l'échauffement libre qui précède — pas ce qui est noté. C'est la seule option qui rend le critère de réussite fourni exploitable tel quel.

---

## Fiche d'Activité — Écrire une fonction Python

### Volet remis à l'apprenant

1. **Intention** — Passer de « je sais reconnaître une fonction » à « je sais en écrire une qui marche ».
2. **Consigne** — En une phrase orale ou écrite libre (non notée), explique avec tes propres mots ce qu'est une fonction Python. Puis **écris** une fonction Python de ton choix (ex. calcul, conversion, formatage de texte) et **exécute-la avec trois appels différents** pour vérifier qu'elle produit le résultat attendu à chaque fois.
3. **Matériel de départ** — Un fichier `.py` vide et un interpréteur Python fonctionnel (terminal ou notebook). Aucun squelette de code fourni : le choix du problème traité par la fonction est libre.
4. **Contraintes** — La fonction doit être définie avec `def`, prendre au moins un paramètre et utiliser `return` (pas seulement `print`). Les trois tests sont de simples appels de la fonction avec des valeurs différentes, dont les résultats sont affichés ou comparés à la main.
5. **Critère de réussite** — La fonction s'exécute sans erreur et renvoie le bon résultat sur trois appels différents.

### Volet conservé par le formateur

1. **Palier visé** — 3. Appliquer (mise en pratique : écrire et exécuter une fonction).
2. **Notion nouvelle** — La syntaxe et la mécanique d'une fonction Python (`def`, paramètres, `return`, appel). **Une seule notion nouvelle** : cela suppose déjà attestées les notions de variable, d'affectation, d'exécution d'un script et d'appel de fonctions déjà existantes (`print`, etc.) — à vérifier dans `etat_des_paliers.md` avant de lancer l'activité ; si l'une de ces notions n'est pas attestée, l'activité dépasse le budget A3 et doit être redécoupée.
3. **Production attendue** — Un fichier `.py` contenant une fonction définie avec `def`, un `return`, et trois appels avec des arguments différents dont les résultats sont visibles (via `print` ou assertions).

   Exemple de référence :
   ```python
   def convertir_celsius_fahrenheit(celsius):
       return celsius * 9/5 + 32

   print(convertir_celsius_fahrenheit(0))    # attendu : 32.0
   print(convertir_celsius_fahrenheit(100))  # attendu : 212.0
   print(convertir_celsius_fahrenheit(37))   # attendu : 98.6
   ```
4. **Critères d'acceptation** — (a) la fonction est bien définie avec `def` et un `return` explicite ; (b) les trois appels s'exécutent sans erreur ; (c) les trois résultats correspondent au calcul attendu, vérifié par le formateur ou par l'apprenant lui-même par calcul manuel.
5. **Erreur fréquente attendue et sa reformulation** — L'apprenant confond souvent `print` et `return`, ou oublie l'un des deux. Diagnostic à formuler en question, pas en correction directe : *« Qu'est-ce que ta fonction renvoie à l'appelant, par opposition à ce qu'elle affiche à l'écran ? Que se passe-t-il si tu utilises le résultat de ton appel dans un calcul ensuite ? »*

---

**Point de vigilance A3** resté ouvert : je n'ai pas d'état des paliers de cet apprenant pour vérifier que variable/affectation/exécution de script sont bien déjà attestées. Si ce n'est pas le cas pour l'apprenant visé, dis-le-moi et je redécoupe en amont.
