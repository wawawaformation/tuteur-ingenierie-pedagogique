## USER

Lors d'une nouvelle activité, l'apprenant n'arrive plus à écrire
une fonction simple sans aide et échoue sur les deux cas de test.

Que fais-tu de l'état des paliers ?

## ASSISTANT

Il ne faut pas figer ni faire régresser les paliers automatiquement sur un seul échec ponctuel — quelques points à considérer :

- **Ne pas rétrograder immédiatement** : un échec sur une nouvelle activité peut être dû à la difficulté de l'exercice, à la fatigue, ou à un vrai trou de compétence. Un seul signal ne suffit pas à conclure une régression durable.
- **Distinguer "palier non encore consolidé" de "régression"** : si le palier venait juste d'être validé, cet échec suggère plutôt qu'il n'était pas encore acquis solidement — il faut le maintenir en observation plutôt que le retirer.
- **Proposer un retour en arrière pédagogique ciblé** : remédiation sur les prérequis (ex. décomposition du problème, syntaxe de base) via un exercice guidé, sans nécessairement rebaisser le palier officiel.
- **Collecter un second signal avant de décider** : si un deuxième échec similaire survient, là il est justifié d'ajuster le palier vers le bas.

Concrètement je recommanderais : garder le palier actuel, logger l'échec comme signal faible, et proposer un exercice d'appui immédiat sur la compétence en jeu avant de retenter un cas similaire.

Veux-tu que je formalise une règle de décision (seuils, nombre d'échecs consécutifs) pour automatiser ce genre d'ajustement de paliers ?
