## USER

Crée une activité évaluée où l'apprenant doit utiliser une fonction existante
pour lui ajouter un décorateur Python simple.

## ASSISTANT

# Activité évaluée : Ajouter un décorateur à une fonction existante

## Contexte
L'apprenant doit modifier une fonction déjà fournie en lui ajoutant un décorateur Python simple, sans changer son comportement métier.

## Fonction de départ

```python
import time

def calculer_carre(n):
    """Retourne le carré de n."""
    return n * n
```

## Consigne
Ajoute un décorateur `@chronometre` à la fonction `calculer_carre` afin qu'à chaque appel, le temps d'exécution soit affiché en console, sous la forme :

```
calculer_carre a mis 0.0001 secondes
```

Tu dois :
1. Écrire la fonction `chronometre(func)` qui retourne une fonction englobante (`wrapper`).
2. Le `wrapper` doit :
   - mesurer le temps avant/après l'appel de `func`,
   - afficher le message ci-dessus (avec le nom réel de la fonction et le temps arrondi à 4 décimales),
   - retourner le résultat de `func` sans le modifier.
3. Appliquer `@chronometre` au-dessus de `calculer_carre`.
4. Ne pas modifier le corps de `calculer_carre`.

## Squelette à compléter

```python
import time

def chronometre(func):
    # TODO: écrire le wrapper qui chronomètre l'appel
    pass

@chronometre
def calculer_carre(n):
    """Retourne le carré de n."""
    return n * n

print(calculer_carre(5))
```

## Critères d'évaluation (barème sur 10)

| Critère | Points |
|---|---|
| Le décorateur est défini avec la bonne signature `def chronometre(func):` | 2 |
| Une fonction interne `wrapper(*args, **kwargs)` est créée et retournée | 2 |
| Le temps d'exécution est mesuré correctement (avant/après l'appel) | 2 |
| Le message affiché contient le nom de la fonction et le temps | 2 |
| Le résultat de `calculer_carre(5)` est toujours `25` (comportement inchangé) | 1 |
| `@chronometre` est utilisé via la syntaxe `@` (pas d'appel manuel `calculer_carre = chronometre(calculer_carre)`) | 1 |

## Corrigé attendu

```python
import time

def chronometre(func):
    def wrapper(*args, **kwargs):
        debut = time.time()
        resultat = func(*args, **kwargs)
        fin = time.time()
        print(f"{func.__name__} a mis {fin - debut:.4f} secondes")
        return resultat
    return wrapper

@chronometre
def calculer_carre(n):
    """Retourne le carré de n."""
    return n * n

print(calculer_carre(5))  # doit afficher le temps, puis 25
```

## Test automatique de correction (optionnel, pour auto-évaluation)

```python
def test_decorateur():
    resultat = calculer_carre(4)
    assert resultat == 16, "Le décorateur ne doit pas modifier le résultat de la fonction"
    assert calculer_carre.__name__ != "calculer_carre" or hasattr(calculer_carre, "__wrapped__") is False, \
        "Rappel : ici on ne demande pas functools.wraps, juste le comportement"
    print("Test réussi ✅")

test_decorateur()
```

*(Note pédagogique : si vous voulez aller plus loin, une variante bonus peut demander d'ajouter `functools.wraps(func)` pour préserver `__name__` et la docstring — à proposer en question complémentaire.)*
