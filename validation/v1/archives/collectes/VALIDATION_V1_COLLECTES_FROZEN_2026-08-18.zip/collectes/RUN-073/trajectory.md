## USER

Crée une activité asynchrone dans laquelle l'apprenant :
1. analyse le problème ;
2. choisit une solution ;
3. implémente ;
4. teste ;
5. rédige un court bilan.

La production doit durer environ 2 heures.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-073/.claude/skills/tuteur-ingenierie-pedagogique/references/atelier.md

## ASSISTANT

Pour respecter le cadrage pédagogique (A2/A3 : une seule notion non attestée par activité évaluée), j'ai besoin de préciser le contexte avant de rédiger la fiche.

## TOOL AskUserQuestion

[Domaine] Quel est le domaine/la compétence technique visée par cet atelier ?
Options: Développement logiciel | Data / analyse | Autre domaine
[Notion visée] Quelle est la notion précise (nouvelle, non encore attestée) que cet atelier doit faire acquérir ?
Options: Je précise en texte libre
[Prérequis] Quelles notions l'apprenant maîtrise-t-il déjà (paliers attestés) et qui serviront de socle pour cet atelier ?
Options: Je précise en texte libre

## TOOL AskUserQuestion

[Domaine] Quel est le domaine/la compétence technique visée par cet atelier ?
Options: Développement logiciel | Data / analyse | Autre domaine

## USER VIA AskUserQuestion

Quel est le domaine/la compétence technique visée par cet atelier ?: Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-073/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## ASSISTANT

Comme je n'ai pas plus de précisions, je pose les hypothèses suivantes (à ajuster si besoin) :

- **Domaine** : développement logiciel (Python), car la séquence analyse→solution→implémentation→test→bilan est la plus naturelle dans ce domaine.
- **Notion unique non attestée** (budget A3) : la gestion des erreurs avec `try/except` (palier visé : **3. Appliquer**).
- **Prérequis supposés déjà attestés** : écrire une fonction Python avec paramètres/retour, exécuter un script, écrire un test simple avec `assert`.

Voici la fiche d'Atelier (asynchrone, ~2h), au format standard à 8 sections.

---

## Atelier — Rendre une fonction robuste aux entrées invalides

**1. Documents fournis**
- Le fichier `calcul.py` contenant une fonction `diviser(a, b)` qui effectue `a / b` sans aucune vérification.
- Trois exemples d'appels qui font planter le programme : `diviser(10, 0)`, `diviser(10, "deux")`, `diviser("dix", 2)`.

**2. Objectifs de l'atelier**
- Diagnostiquer les cas où une fonction échoue face à des entrées imprévues.
- Choisir une stratégie de gestion des erreurs et justifier ce choix.
- Mettre en œuvre cette stratégie avec des blocs `try/except`.
- Vérifier par des tests que la fonction se comporte correctement, y compris sur les cas limites.

**3. Durée estimée**
Environ 2 heures. Cette durée est indicative : elle sert de repère, pas de plafond. Certains iront plus vite, d'autres prendront plus de temps pour explorer — c'est normal.

**4. Organisation et outils**
Libre. Utilisez l'éditeur et l'environnement Python de votre choix. Aucun outil de test spécifique n'est imposé : `assert` dans un script suffit, un framework comme `pytest` est accepté si vous le connaissez déjà.

**5. Méthode proposée**
1. **Analyser** : exécutez les trois appels fournis, notez précisément ce qui se passe pour chacun (message d'erreur, type d'exception, ou résultat incorrect).
2. **Choisir une solution** : pour chaque cas identifié, décidez comment la fonction doit réagir (lever une exception explicite ? renvoyer une valeur particulière ? afficher un message ?) et notez en une ou deux phrases pourquoi ce choix vous semble le plus adapté.
3. **Implémenter** : modifiez `diviser` en utilisant `try/except` pour appliquer la stratégie choisie.
4. **Tester** : écrivez au moins 4 tests couvrant : un cas normal, une division par zéro, une entrée non numérique, un cas limite de votre choix.
5. **Rédiger un bilan** : en une demi-page maximum, ce qui a été difficile, ce que vous changeriez avec plus de temps, et une phrase sur l'utilité de cette pratique en situation réelle.

**6. Ce qui est supposé par défaut**
- Le message d'erreur affiché à l'utilisateur final n'a pas besoin d'être traduit ou peaufiné : le fond compte plus que la forme.
- Il n'y a pas de « bonne » stratégie unique entre lever une exception ou renvoyer une valeur sentinelle : le critère porte sur la cohérence et la justification du choix, pas sur la solution en elle-même.
- Vous pouvez traiter les trois cas fournis avec la même stratégie ou avec des stratégies différentes selon le cas.

**7. Livrable attendu**
- Le fichier `calcul.py` modifié.
- Un fichier de tests (`test_calcul.py` ou équivalent) contenant au moins 4 tests.
- Un court texte de bilan (quelques phrases, dans un fichier séparé ou en commentaire).

**8. Critère simple**
*Si vous relancez les trois appels fournis (et au moins un cas limite de votre choix) et qu'aucun ne fait planter le programme de façon incontrôlée — chacun produit soit un résultat correct, soit un message d'erreur clair et voulu — c'est gagné.*

> 💡 **Bon à savoir** — Le brief ne précise pas quel message d'erreur afficher : c'est volontaire, cette ambiguïté existe aussi dans un vrai projet.
> ⚠️ **Vigilance** — L'atelier ne demande pas de gérer *tous* les types d'erreurs possibles en Python, seulement les trois cas fournis plus un cas limite de votre choix.

---

### Volet formateur (non remis à l'apprenant)

**Notions mobilisées et paliers requis**

| Notion | Palier requis | Statut dans cet atelier |
|---|---|---|
| Écrire une fonction Python (paramètres/retour) | 3 | Déjà attesté (prérequis) |
| Écrire un test simple (`assert`) | 3 | Déjà attesté (prérequis) |
| Gestion des erreurs avec `try/except` | 3 | **Notion nouvelle, non attestée — objet de l'atelier** |

**Grille de correction indicative**
- Les 3 cas fournis + 1 cas limite sont bien identifiés à l'étape 1 (analyse).
- Une stratégie est choisie et justifiée, même brièvement (étape 2) — pas d'exigence sur *quelle* stratégie.
- Le code utilise effectivement `try/except` (pas de simple `if` déguisé qui contournerait l'objectif).
- Les tests couvrent bien les 4 cas minimum et passent.
- Le bilan est présent et personnel (pas un copié-collé générique).

---

Si le domaine réel est différent (data, infra, autre langage) ou si la notion cible n'est pas la gestion des erreurs, dites-le-moi et je réadapte la fiche en conservant la même structure.
