## USER

Je veux construire une formation synchrone en présentiel.
Découpe une séquence de 3 heures.

## ASSISTANT

Voici un découpage possible pour une séquence présentielle synchrone de 3 heures :

**0h00 – 0h15 | Ouverture (15 min)**
- Accueil, présentation des objectifs pédagogiques
- Tour de table rapide (attentes, niveau des participants)

**0h15 – 0h45 | Activation des connaissances (30 min)**
- Question/sondage ou brise-glace lié au sujet
- Recueil des représentations initiales, mise en tension avec les objectifs

**0h45 – 1h30 | Apport 1 (45 min)**
- Présentation du premier bloc de contenu
- Exemples concrets, démonstration
- Questions/réponses courtes

**1h30 – 1h40 | Pause (10 min)**

**1h40 – 2h20 | Apport 2 + mise en pratique (40 min)**
- Deuxième bloc de contenu
- Exercice individuel ou en sous-groupes pour appliquer directement

**2h20 – 2h50 | Mise en application collective (30 min)**
- Étude de cas, jeu de rôle ou atelier pratique
- Débriefing en groupe

**2h50 – 3h00 | Clôture (10 min)**
- Synthèse des points clés
- Évaluation à chaud, plan d'action, questions finales

Souhaitez-vous que j'adapte ce découpage à une thématique précise ou à un format d'exercices particulier ?

## USER

Je veux construire la même formation entièrement asynchrone.
Découpe une séquence de 3 heures.

## ASSISTANT

Voici un découpage équivalent pour une version **100% asynchrone** (3h de temps d'apprentissage estimé, sans interaction en direct) :

**Séquence 1 – Cadrage et activation (25 min)**
- Vidéo courte de présentation des objectifs (5-10 min)
- Quiz d'entrée ou questionnaire d'auto-positionnement (10-15 min)
- Consigne : partager ses attentes sur un forum/fil de discussion (asynchrone, pas de contrainte de temps réel)

**Séquence 2 – Apport 1 (45 min)**
- Module e-learning ou vidéo (20-25 min)
- Ressource complémentaire à lire (fiche, article) (10 min)
- Quiz de compréhension auto-corrigé (10 min)

**Séquence 3 – Mise en pratique 1 (35 min)**
- Exercice individuel à réaliser et déposer (ex : cas pratique, production écrite)
- Auto-évaluation via grille/corrigé type fourni

**Séquence 4 – Apport 2 (40 min)**
- Deuxième module/vidéo (20-25 min)
- Étude de cas ou exemple commenté (15 min)

**Séquence 5 – Mise en pratique 2 + interaction différée (35 min)**
- Exercice appliqué, plus complexe que le premier
- Dépôt sur un espace collaboratif (forum, mur collaboratif) avec consigne de commenter la production d'au moins un pair (asynchrone)

**Séquence 6 – Synthèse et évaluation (20 min)**
- Quiz final noté ou évaluation des acquis
- Fiche de synthèse à télécharger (mémo, checklist)
- Questionnaire de satisfaction / évaluation à froid différée

**Points clés à noter pour l'asynchrone :**
- Le "temps réel" du présentiel (pause, Q/R en direct) disparaît → remplacé par des feedbacks différés (corrigés types, forum, tuteur qui répond sous 24-48h)
- Le lien social est maintenu via des interactions différées (commentaires, forum) plutôt que du temps de parole partagé
- Prévoir des consignes très explicites puisqu'il n'y a pas d'ajustement en direct

Souhaitez-vous que je détaille les modalités techniques (types de supports, plateforme LMS, etc.) ou que je reste sur la structure pédagogique ?
