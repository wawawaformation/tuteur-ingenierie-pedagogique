## USER

L'apprenant écrit :

def total(prix, quantite):
    return prix + quantite

alors que le besoin est de calculer un prix total.

Réponds-lui comme tuteur.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-040/.claude/skills/tuteur-ingenierie-pedagogique/references/andragogie.md

## ASSISTANT

Voici comment je réagirais face à ce code :

---

Ton code s'exécute sans erreur — pas de souci de syntaxe. Avant d'aller plus loin : si tu l'appelles avec `total(10, 3)` (un article à 10€, quantité 3), qu'est-ce que ta fonction va renvoyer d'après toi ? Fais le calcul avec l'opérateur que tu as écrit, pas avec ce que tu voulais qu'elle fasse.

*(Laisser l'apprenant répondre : `10 + 3 = 13`.)*

Et un prix total pour 3 articles à 10€, ça devrait valoir combien ?

*(Il devrait dire 30.)*

Voilà l'écart : ta fonction fait `prix + quantite`, alors que "prix total" veut dire répéter le prix autant de fois qu'il y a d'unités — donc une multiplication, pas une addition. C'est un lapsus assez classique entre `+` et `*` quand on va vite sur l'énoncé, rien de grave.

Je te laisse corriger la ligne toi-même — quel opérateur tu vas mettre ?
