## USER

Rédige uniquement une fiche de Séance de 45 minutes
sur la validation des données avec Pydantic.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-009/.claude/skills/tuteur-ingenierie-pedagogique/references/seance.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-009/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-009/.claude/skills/tuteur-ingenierie-pedagogique/references/opo.md

## ASSISTANT

# Fiche de Séance — Valider des données avec Pydantic (45 min)

## 1. Intitulé et place dans la séquence
**Séance amont** : Type hints et classes en Python (dataclasses, typage des attributs).
**Séance aval** : Écrire des validateurs personnalisés (`@field_validator`) pour les règles métier que les types seuls ne peuvent pas exprimer.

## 2. OPO de la séance (3C)

> À la fin de la séance, l'apprenant sera capable d'**écrire** une classe Pydantic (`BaseModel`) avec des champs typés (Comportement), **à partir d'une spécification de payload fournie** (ex. données d'inscription utilisateur reçues en JSON) et d'un jeu de données de test valides/invalides (Conditions), **de manière à ce que le modèle lève une `ValidationError` sur toutes les données invalides du jeu de test et accepte sans erreur toutes les données valides** (Critères).

Palier visé : **3. Appliquer**.

*Notions mobilisées et déjà attestées* : type hints Python, définition de classe, dictionnaires et déballage `**data`. *Notion nouvelle (budget = 1)* : déclaration et comportement de validation d'un `BaseModel` Pydantic.

## 3. Ancrage / Pourquoi (0–5 min)
Montrer une fonction Python classique qui reçoit un dictionnaire brut (par ex. un payload JSON d'inscription : `{"nom": "Ana", "age": "vingt-cinq"}`). Sans garde-fou, ce dictionnaire circule dans le code jusqu'à provoquer un `TypeError` incompréhensible loin de sa cause réelle (ex. dans un calcul sur `age`), ou pire : la donnée fausse est silencieusement acceptée et stockée.

Montrer ensuite le même payload passé à un modèle Pydantic : l'erreur est détectée immédiatement, à la frontière, avec un message précis (« champ `age`, attendu `int`, reçu une chaîne non convertible »). Le message qui porte la séance : *valider tôt, c'est transformer un bug lointain et flou en une erreur immédiate et lisible.*

## 4. Apport (5–15 min)

Pydantic est une bibliothèque qui définit un **schéma de données à partir de type hints Python**, et valide automatiquement toute donnée qui tente de s'y conformer.

- **`BaseModel`** : classe de base à hériter pour déclarer un schéma. Chaque attribut annoté devient un champ validé :
  ```python
  from pydantic import BaseModel

  class Utilisateur(BaseModel):
      nom: str
      age: int
  ```
- **Validation à l'instanciation** : `Utilisateur(**data)` déclenche la validation. Si les données ne correspondent pas au schéma, Pydantic lève une `pydantic.ValidationError` listant précisément chaque champ fautif et la raison.
- **Coercition** : par défaut, Pydantic essaie de convertir les types compatibles (ex. la chaîne `"25"` devient l'entier `25`), mais rejette ce qui n'est pas convertible (ex. `"vingt-cinq"`). Ce n'est pas une simple vérification de type strict — c'est une validation avec conversion raisonnable.
- **Champs optionnels** : `Optional[str] = None` — le `= None` est indispensable ; sans valeur par défaut, le champ reste obligatoire même annoté `Optional`.
- **Où c'est utilisé** : à toute frontière où des données non fiables entrent dans le programme — corps de requête HTTP (FastAPI), fichiers de configuration, résultats d'API externes.

## 5. Déroulé minuté

| Minutage | Temps | Palier visé | Rôle du formateur |
|---|---|---|---|
| 0–5 | Ancrage : le bug loin de sa cause | — (non évalué) | Montre, raconte |
| 5–15 | Apport : `BaseModel`, validation, coercition | — (non évalué) | Expose, fait reformuler |
| 15–40 | Activité évaluée : écrire le modèle `Utilisateur` (ou équivalent) et le confronter à un jeu de données valides/invalides fourni | 3. Appliquer | Circule, débloque sans faire à la place |
| 40–45 | Reprise collective et transition | — | Synthétise à partir des productions, relève les erreurs fréquentes observées |

**Le minutage est un budget, pas un script** : si l'activité déborde, sacrifier en priorité le temps de reprise collective (peut se faire en fin de séance suivante), jamais le temps de pratique.

## 6. Erreurs fréquentes attendues

- **Confondre `Optional` et facultatif** : l'apprenant écrit `age: Optional[int]` sans `= None` et s'étonne que le champ reste obligatoire. *Reformulation* : « Que dit le message d'erreur sur ce champ ? Qu'est-ce qui manque pour qu'il devienne vraiment facultatif ? »
- **S'étonner de la coercition** : l'apprenant attend un rejet strict quand `"25"` est accepté pour un champ `int`. *Reformulation* : « Le champ a-t-il été rejeté ou converti ? Que nous dit la valeur finale stockée dans l'objet ? »
- **Réflexe de sur-validation manuelle** : ajouter des `if`/`else` de vérification en plus du modèle, par habitude, alors que Pydantic l'a déjà fait. *Reformulation* : « Cette vérification, à quel moment a-t-elle déjà eu lieu ? »
- **Ignorer le contenu du message de `ValidationError`** et redéboguer à l'aveugle. *Reformulation* : « Le message d'erreur nomme un champ précis — lequel, et pourquoi celui-là ? »

## 7. Transition
« Le modèle qu'on vient d'écrire rejette les mauvais types — mais que se passe-t-il si l'âge est bien un entier, tout à fait valide, mais négatif ? La prochaine séance porte sur l'écriture de validateurs personnalisés pour ces règles métier que les types seuls ne peuvent pas exprimer. »
