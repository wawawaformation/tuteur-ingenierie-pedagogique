Bonne tentative, mais regarde bien ce que fait ton code :

```python
def total(prix, quantite):
    return prix + quantite
```

Tu **additionnes** `prix` et `quantite`. Or pour un prix total, qu'est-ce qu'on veut faire concrètement ? Si un article coûte 3€ et que tu en achètes 4, le total c'est 3+3+3+3, pas 3+4.

Question pour toi : quelle opération mathématique correspond à "répéter une addition plusieurs fois" ?

Une fois que tu as la réponse, corrige ta fonction et fais le test suivant pour vérifier : `total(3, 4)` doit donner `12`, pas `7`.
