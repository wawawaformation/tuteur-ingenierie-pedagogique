## USER

Crée une activité évaluée :
« À partir de cette fonction et de ces tests fournis,
ajoute un décorateur simple qui journalise l'appel. »

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-107/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-107/.claude/skills/tuteur-ingenierie-pedagogique/references/activite.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-107/.claude/skills/tuteur-ingenierie-pedagogique/references/opo.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-107/.claude/skills/tuteur-ingenierie-pedagogique/references/etat_des_paliers.md

## TOOL Bash

## ASSISTANT

Je n'ai pas encore de quoi construire l'activité : la fonction et les tests que tu mentionnes ne sont ni collés dans le message ni présents dans le dossier du projet (qui est vide en dehors du skill). Il me manque aussi l'état des paliers de l'apprenant — sans lui, je ne peux pas vérifier le budget de nouveauté (A3), qui limite une activité évaluée à **une seule** notion non attestée.

Avant de rédiger la fiche, j'ai besoin de deux choses :

1. **La fonction et les tests** que tu veux utiliser comme matériel de départ (colle-les ici, ou indique le chemin du fichier).
2. **L'état des notions déjà attestées** pour cet apprenant — en particulier, pour que « décorateur » soit la *seule* notion nouvelle, il faut que les prérequis suivants soient déjà acquis :
   - définir/appeler une fonction en Python (palier ≥ 3),
   - `*args` / `**kwargs`,
   - exécuter une suite de tests fournie (ex. pytest) pour vérifier son travail.

Si l'un de ces prérequis n'est pas encore attesté, l'activité proposée dépasserait le budget de nouveauté et il faudrait soit la redécouper, soit choisir un prérequis déjà solide comme point de départ.

Peux-tu me fournir la fonction/les tests, et me dire où en est l'apprenant sur ces prérequis (ou me confirmer qu'aucun état des paliers n'existe encore, auquel cas je le pose en hypothèse par défaut) ?

## USER

État :

| Notion | Palier attesté | Preuve | Quand |
|---|---|---|---|
| fonctions Python | 3. Appliquer | activité F1 | J1 |
| paramètres | 3. Appliquer | activité F2 | J1 |
| tests | 3. Appliquer | activité T1 | J1 |
| décorateur Python | 0 | aucune preuve | J2 |

## ASSISTANT

Bien noté — le budget de nouveauté est respecté : fonctions, paramètres et tests sont attestés au palier 3 (Appliquer), seul le décorateur est à 0. Le décorateur est donc la seule notion nouvelle, l'activité est recevable.

Il me manque encore la fonction et les tests eux-mêmes (le « matériel de départ » de la fiche). Peux-tu me les coller ici ?

Si tu préfères que je choisisse un exemple neutre par défaut plutôt que d'attendre, dis-le moi et je pars sur une fonction simple (ex. `calculer_total(prix, quantite)`) avec 2-3 tests fournis.

## USER

Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## ASSISTANT

## Fiche d'Activité — Décorateur de journalisation

**Palier visé :** 3. Appliquer
**Notion nouvelle (unique, A3) :** décorateur Python
*Prérequis mobilisés (déjà attestés au palier 3) : fonctions, paramètres, tests — aucun autre budget de nouveauté engagé.*

---

### Volet remis à l'apprenant

**Intention** — Voir comment on peut ajouter un comportement (ici : tracer les appels) à une fonction existante sans toucher à son code interne.

**Matériel de départ**

```python
# fonction.py
def calculer_total(prix, quantite):
    return prix * quantite
```

```python
# test_fonction.py
from fonction import calculer_total

def test_calculer_total_simple():
    assert calculer_total(10, 3) == 30

def test_calculer_total_zero():
    assert calculer_total(5, 0) == 0

def test_calculer_total_decimal():
    assert calculer_total(2.5, 4) == 10.0
```

**Consigne** — À partir de `calculer_total` et des tests fournis, ajoute un décorateur simple qui journalise l'appel (nom de la fonction et arguments reçus) avant chaque exécution.

**Contraintes**
- Tu ne modifies ni la signature de `calculer_total`, ni le fichier de tests.
- Le décorateur doit fonctionner quels que soient les arguments passés (positionnels ou nommés).
- La journalisation peut se faire avec un simple `print`.

**Critère de réussite** — Les 3 tests fournis passent toujours sans modification, et chaque appel de `calculer_total` affiche une ligne mentionnant le nom de la fonction et les arguments reçus.

---

### Volet conservé par le formateur

**Production attendue**

```python
def log_appel(fonction):
    def wrapper(*args, **kwargs):
        print(f"Appel de {fonction.__name__} avec args={args}, kwargs={kwargs}")
        return fonction(*args, **kwargs)
    return wrapper

@log_appel
def calculer_total(prix, quantite):
    return prix * quantite
```

**Critères d'acceptation** (ce qui fait passer « décorateur Python » à palier 3 dans l'état des paliers) :
- les 3 tests fournis passent sans qu'aucun n'ait été modifié ;
- une ligne de log apparaît à chaque appel, contenant le nom de la fonction et les arguments.

**Erreur fréquente attendue et sa reformulation**
Oubli du `return` dans `wrapper` (le décorateur exécute la fonction mais n'en renvoie pas le résultat → `calculer_total` renvoie `None`, les tests échouent).
Question de diagnostic à poser plutôt que « c'est faux » : *« Que fait ta fonction `wrapper` avec le résultat de `fonction(*args, **kwargs)` une fois qu'elle l'a calculé ? »*

---

Une fois l'activité réalisée, la ligne « décorateur Python » de l'état des paliers passera de 0 à 3 si les deux critères d'acceptation ci-dessus sont remplis — dis-moi quand c'est fait pour que je mette la trace à jour.
