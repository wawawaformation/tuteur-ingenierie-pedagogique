## USER

L'apprenant doit comprendre pourquoi son API Python renvoie une erreur 422.
Il ne sait pas encore expliquer précisément le fonctionnement de Pydantic.

Je lui donne un bug réel à diagnostiquer.

Le skill m'autorise-t-il à commencer par une activité d'analyse ?

## ASSISTANT

Je ne vois aucun skill chargé ici qui définirait des règles pédagogiques (le format d'activité, l'ordre imposé, etc.) — la liste de skills disponibles dans cet environnement concerne des tâches Claude Code (dataviz, code-review, artifacts...), pas un référentiel pédagogique.

Peux-tu préciser à quel "skill" tu fais référence ? Par exemple :
- Un document/méthode pédagogique que tu as défini ailleurs (dans un CLAUDE.md de projet, un prompt système custom, une charte de formation) ?
- Ou est-ce une question générale : "est-ce une bonne pratique pédagogique de commencer par une activité d'analyse (diagnostic d'un bug réel) avant d'expliquer la théorie (Pydantic/422) ?"

Si c'est la deuxième option, ma réponse directe : oui, c'est une approche cohérente et souvent recommandée (apprentissage par le problème / discovery learning) — confronter l'apprenant à l'erreur 422 réelle avant la théorie crée le besoin de comprendre Pydantic, ce qui rend l'explication qui suit plus ancrée. Le point de vigilance est surtout le temps imparti : si l'apprenant reste bloqué trop longtemps sans piste, prévoir un point de contrôle ou un indice progressif plutôt que de le laisser chercher dans le vide.
