## USER

Crée une fiche d'activité avec l'énoncé et, juste sous l'énoncé,
mets la solution complète pour que l'apprenant puisse vérifier
pendant qu'il travaille.

## ASSISTANT

Il me manque le sujet de la fiche d'activité (quelle compétence technique, quel niveau, quel contexte d'apprentissage).

## TOOL AskUserQuestion

[Sujet] Sur quelle compétence ou notion technique porte cette fiche d'activité ?
Options: Préciser le sujet

## ASSISTANT

Il me manque le sujet précis pour créer cette fiche. Pouvez-vous préciser sur quelle compétence ou notion technique elle doit porter (langage, outil, niveau visé) ?

## USER

Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-112/.claude/skills/tuteur-ingenierie-pedagogique/references/activite.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-112/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## ASSISTANT

Aucun sujet n'ayant été précisé, j'ai choisi un exemple générique et autonome : **Python — filtrer une liste avec une compréhension de liste**. Je place la solution juste sous l'énoncé (sous un séparateur clair), comme demandé — ce qui déroge volontairement au gabarit standard qui sépare le volet apprenant du volet formateur, puisque c'est explicitement ce que vous avez demandé pour l'auto-vérification.

---

## Fiche d'Activité — Filtrer une liste (Python)

**Intention** : Vérifier que tu sais transformer une boucle de filtrage classique en une compréhension de liste.

**Consigne** : Écris une compréhension de liste qui retourne uniquement les nombres pairs de la liste `nombres`.

**Matériel de départ** :
```python
nombres = [3, 8, 15, 22, 7, 40, 11, 6]
```

**Contraintes** :
- Le résultat doit être stocké dans une variable `pairs`.
- Tu dois utiliser une compréhension de liste (pas de boucle `for` classique avec `.append()`).
- Format attendu : une liste Python.

**Critère de réussite** : `pairs` contient exactement `[8, 22, 40, 6]`, dans cet ordre.

---

### ✅ Solution (à consulter pour te vérifier)

```python
nombres = [3, 8, 15, 22, 7, 40, 11, 6]
pairs = [n for n in nombres if n % 2 == 0]
print(pairs)  # [8, 22, 40, 6]
```

**Explication rapide** :
- `n for n in nombres` parcourt chaque élément de la liste.
- `if n % 2 == 0` filtre pour ne garder que les nombres divisibles par 2 (pairs).
- Le tout est équivalent à :
  ```python
  pairs = []
  for n in nombres:
      if n % 2 == 0:
          pairs.append(n)
  ```
  mais en une seule ligne.

**Erreur fréquente** : écrire `[n % 2 == 0 for n in nombres]` — cela retourne une liste de `True`/`False`, pas les nombres eux-mêmes. Si tu obtiens `[False, True, False, True, ...]`, relis où se place la condition `if` par rapport à l'expression de retour.

---

*Repère pédagogique (info, pas à remettre à l'apprenant) : palier visé = 3 (Appliquer) ; notion nouvelle = syntaxe de la compréhension de liste avec filtre ; prérequis supposés attestés = variables, listes, boucles `for`, opérateur modulo.*

Dites-moi si vous voulez que je l'adapte à un autre sujet, langage ou niveau.
