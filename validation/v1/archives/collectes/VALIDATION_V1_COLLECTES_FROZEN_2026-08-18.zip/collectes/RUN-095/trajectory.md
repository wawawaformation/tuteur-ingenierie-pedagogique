## USER

Je forme des développeurs Python adultes.
Crée-moi un exercice de 15 minutes pour leur apprendre les décorateurs Python.

## ASSISTANT

Voici un exercice de 15 minutes sur les décorateurs Python.

## Exercice : Décorateur de chronométrage (15 min)

### Contexte
Vous développez une application et voulez mesurer le temps d'exécution de certaines fonctions sans modifier leur code.

### Consigne (10 min)

Créez un décorateur `chrono` qui affiche le temps d'exécution d'une fonction, puis appliquez-le à la fonction fournie.

```python
import time

# TODO: écrire le décorateur ici
def chrono(fonction):
    ...

@chrono
def calcul_lent(n):
    total = 0
    for i in range(n):
        total += i ** 2
    return total

resultat = calcul_lent(1_000_000)
print(resultat)
```

**Résultat attendu** (le temps exact variera) :
```
calcul_lent a mis 0.0842 secondes
499999666667000000
```

Contraintes :
- Le décorateur doit fonctionner avec des fonctions ayant des arguments quelconques (`*args`, `**kwargs`).
- La fonction décorée doit toujours retourner sa valeur normale (`calcul_lent(1_000_000)` doit toujours renvoyer le résultat du calcul, pas `None`).

### Bonus si le temps le permet (3 min)
Ajoutez `functools.wraps` pour préserver le nom et la docstring de la fonction d'origine, et vérifiez avec :
```python
print(calcul_lent.__name__)  # doit afficher "calcul_lent", pas "wrapper"
```

### Correction (2 min — à distribuer après)

```python
import time
from functools import wraps

def chrono(fonction):
    @wraps(fonction)
    def wrapper(*args, **kwargs):
        debut = time.perf_counter()
        resultat = fonction(*args, **kwargs)
        fin = time.perf_counter()
        print(f"{fonction.__name__} a mis {fin - debut:.4f} secondes")
        return resultat
    return wrapper
```

**Points pédagogiques à souligner à l'oral** :
- Un décorateur est une fonction qui prend une fonction et en retourne une autre (closure).
- `*args, **kwargs` rendent le wrapper générique.
- Sans `return resultat`, la fonction décorée perd sa valeur de retour — piège classique.
- `functools.wraps` évite de casser l'introspection (`__name__`, `__doc__`), utile avec des frameworks comme Flask ou pytest qui s'appuient dessus.
