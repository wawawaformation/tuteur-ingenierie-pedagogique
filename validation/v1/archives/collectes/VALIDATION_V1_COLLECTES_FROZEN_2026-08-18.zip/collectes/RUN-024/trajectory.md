## USER

L'apprenant n'a jamais utilisé les décorateurs Python.
Donne-lui une activité évaluée dans laquelle il doit écrire seul un décorateur.

## ASSISTANT

# Activité évaluée : Écrire son premier décorateur Python

## Contexte
Un décorateur est une fonction qui **enveloppe** une autre fonction pour lui ajouter un comportement, sans modifier son code source.

Rappel de la mécanique de base :
```python
def mon_decorateur(fonction):
    def wrapper(*args, **kwargs):
        # code avant l'appel
        resultat = fonction(*args, **kwargs)
        # code après l'appel
        return resultat
    return wrapper
```

## Consigne

Écris **seul** un décorateur `chronometre` qui affiche le temps d'exécution d'une fonction.

**Fichier à produire : `decorateur.py`**

1. Écris un décorateur `chronometre` qui :
   - mesure le temps avant et après l'exécution de la fonction décorée (module `time`, fonction `time.perf_counter()`)
   - affiche un message du type : `"calcul a mis 0.1234 secondes"`
   - retourne bien le résultat de la fonction décorée (ne pas l'oublier !)

2. Applique-le avec `@chronometre` à une fonction `calcul(n)` qui fait une boucle (par exemple somme des carrés de 0 à n).

3. Appelle `calcul(1000000)` et vérifie que :
   - le résultat du calcul est bien retourné (fais un `print(resultat)` du retour de l'appel)
   - le message du temps s'affiche

## Contraintes (pour vérifier que tu as compris le mécanisme, pas juste copié)

- Interdiction d'utiliser `functools.wraps` (on le verra plus tard)
- Le décorateur doit fonctionner avec **une fonction qui prend des arguments** (utilise `*args, **kwargs` dans le `wrapper`)
- Ajoute une deuxième fonction décorée `addition(a, b)` qui retourne `a + b`, pour prouver que ton décorateur marche sur plusieurs fonctions différentes

## Critères d'évaluation

| Critère | Points |
|---|---|
| Le décorateur retourne bien le résultat de la fonction décorée | 3 |
| Le décorateur accepte des fonctions avec arguments (`*args, **kwargs`) | 3 |
| Le temps affiché est cohérent (pas de valeur négative ou nulle absurde) | 2 |
| Le décorateur est appliqué avec la syntaxe `@` (pas d'appel manuel type `calcul = chronometre(calcul)`) | 2 |

**Question bonus (à l'oral ou en commentaire dans le code) :** pourquoi `wrapper` doit-il accepter `*args, **kwargs` alors que `chronometre`, lui, n'accepte qu'un seul argument (`fonction`) ?
