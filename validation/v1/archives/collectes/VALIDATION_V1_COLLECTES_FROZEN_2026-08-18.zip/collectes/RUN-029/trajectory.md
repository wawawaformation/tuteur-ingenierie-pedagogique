## USER

Crée une activité asynchrone dans laquelle l'apprenant :
1. analyse le problème ;
2. choisit une solution ;
3. implémente ;
4. teste ;
5. rédige un court bilan.

La production doit durer environ 2 heures.

## ASSISTANT

Voici une activité asynchrone d'environ 2 heures, structurée en 5 étapes.

---

## Activité asynchrone — Résolution d'un problème technique

**Durée estimée : 2h**
**Modalité : individuelle, à distance, livrable écrit**

### Contexte à adapter
Remplacez `[PROBLÈME]` par un cas concret tiré de votre domaine (bug logiciel, panne système, dysfonctionnement de processus, etc.). L'énoncé doit être suffisamment ouvert pour permettre plusieurs solutions possibles.

---

### Consigne donnée à l'apprenant

> Vous êtes confronté au problème suivant : **[PROBLÈME]**
> Vous disposez de 2h pour produire une solution testée et un bilan réflexif. Documentez chaque étape au fur et à mesure — le raisonnement compte autant que le résultat final.

---

### Déroulé (5 étapes, ~2h)

| Étape | Consigne | Durée indic. | Livrable attendu |
|---|---|---|---|
| **1. Analyser** | Décrire le problème dans ses propres mots, identifier les causes possibles, lister les contraintes (techniques, temps, ressources) | 20 min | Un paragraphe d'analyse + liste de contraintes |
| **2. Choisir** | Proposer 2 solutions envisageables minimum, comparer leurs avantages/inconvénients, justifier le choix retenu | 20 min | Tableau comparatif + justification (5-10 lignes) |
| **3. Implémenter** | Mettre en œuvre la solution choisie | 45 min | Le livrable concret (code, procédure, document, etc.) |
| **4. Tester** | Vérifier que la solution fonctionne, dans au moins un cas nominal et un cas limite | 20 min | Preuve de test (capture, log, résultat, jeu d'essai) |
| **5. Bilan** | Rédiger un court retour réflexif : ce qui a fonctionné, ce qui a été difficile, ce qu'on referait autrement | 15 min | 10-15 lignes max |

---

### Critères d'évaluation suggérés

- **Analyse** : le problème est reformulé et les causes/contraintes identifiées (pas de copier-coller de l'énoncé)
- **Choix** : au moins une alternative a été réellement envisagée, pas seulement mentionnée
- **Implémentation** : la solution est fonctionnelle et cohérente avec le choix justifié
- **Test** : au moins un cas limite est couvert, pas seulement le cas idéal
- **Bilan** : réflexion personnelle, pas une simple synthèse des étapes précédentes

### Format de rendu
Un seul document (ou dépôt/lien) regroupant les 5 sections dans l'ordre, avec horodatage ou minutage approximatif par étape pour donner de la visibilité sur le temps réellement passé.

---

Voulez-vous que j'adapte cette trame à un problème précis (ex. un bug de code, une panne réseau, un cas métier) ?
