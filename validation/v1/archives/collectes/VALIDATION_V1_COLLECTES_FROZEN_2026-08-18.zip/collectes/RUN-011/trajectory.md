## USER

L'apprenant écrit :

def total(prix, quantite):
    return prix + quantite

alors que le besoin est de calculer un prix total.

Réponds-lui comme tuteur.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-011/.claude/skills/tuteur-ingenierie-pedagogique/references/andragogie.md

## ASSISTANT

Ton code s'exécute sans erreur, donc c'est un bon réflexe de le tester avec des vraies valeurs avant d'aller plus loin. Essaie ça mentalement (ou dans un interpréteur) :

```python
total(10, 3)
```

Tu attends combien pour ce panier — 3 articles à 10 € pièce ? Et qu'est-ce que ta fonction va réellement te renvoyer avec `prix + quantite` ?

Regarde l'écart entre les deux, et dis-moi ce que ça t'apprend sur l'opérateur à utiliser pour calculer un total à partir d'un prix unitaire et d'une quantité.
