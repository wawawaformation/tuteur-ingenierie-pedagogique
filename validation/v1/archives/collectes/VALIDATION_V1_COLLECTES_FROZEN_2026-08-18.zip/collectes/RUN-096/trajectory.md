## USER

L'activité demande simplement :
« Écris une fonction Python qui prend deux nombres et retourne leur somme. »

Est-ce une nouvelle notion ?

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-096/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## ASSISTANT

Pour répondre, il faut d'abord décomposer les **notions mobilisées** par cette activité (A2), avant de pouvoir dire laquelle est « nouvelle » :

1. **Syntaxe de définition de fonction** (`def nom(params):`)
2. **Paramètres** (en recevoir deux)
3. **Opérateur `+` / addition sur des nombres**
4. **Instruction `return`** (renvoyer une valeur vs. l'afficher)

« Est-ce une nouvelle notion ? » n'a de sens que **notion par notion**, et seulement au regard de ce qui est déjà attesté chez cet apprenant précis (A2) — je n'ai pas cette information pour l'instant.

Deux cas typiques :

- Si l'apprenant a déjà attesté `def`/paramètres/`return` sur d'autres exemples, et que seule l'**addition sur deux paramètres** est nouvelle → une seule notion non attestée, l'activité respecte le budget A3, elle est proposable telle quelle.
- Si `def`, paramètres **et** `return` sont tous encore non attestés → 3 notions non attestées à la fois, l'activité dépasse le budget de nouveauté (A3) et devrait être décomposée (ex. d'abord une fonction sans paramètre qui `return` une constante, puis une fonction avec un paramètre, puis deux paramètres avec opération).

Peux-tu me donner l'état des paliers actuel de l'apprenant sur ces notions (ou dire s'il s'agit d'un tout premier contact avec les fonctions Python) ? Cela permettra de trancher précisément laquelle, s'il y en a une, est la notion non attestée du budget.
