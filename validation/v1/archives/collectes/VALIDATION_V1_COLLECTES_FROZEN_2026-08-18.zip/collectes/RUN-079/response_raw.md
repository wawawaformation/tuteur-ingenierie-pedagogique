## Les middlewares LangChain, en bref

Dans le système d'agents récent de LangChain (`create_agent`), un middleware est un point d'interception placé sur le graphe d'exécution de l'agent (le cycle modèle → outils → modèle...). Il permet d'insérer de la logique à des moments précis sans toucher au cœur de l'agent :

- **Hooks disponibles** : `before_agent`, `before_model`, `wrap_model_call`, `after_model`, `wrap_tool_call`, `after_agent`.
- **Deux façons de les écrire** :
  - hériter de la classe de base `AgentMiddleware` et redéfinir les méthodes correspondantes (style orienté objet, utile quand le middleware a un état ou plusieurs hooks liés) ;
  - utiliser un décorateur fonctionnel (`@before_model`, `@after_model`, `@wrap_model_call`, `@wrap_tool_call`...) pour une fonction unique, plus léger quand un seul point d'interception suffit.
- **Redirection du graphe** : un hook peut renvoyer un dict contenant la clé `jump_to`, qui indique au graphe de sauter directement vers un nœud donné (`"model"`, `"tools"`, `"end"`...) au lieu de suivre l'enchaînement par défaut. C'est ce qui permet, par exemple, de court-circuiter l'appel au modèle si une condition est déjà remplie, ou d'interrompre la boucle d'outils.

Cas d'usage typiques : garde-fous de sécurité, logging, retry, injection de contexte, limitation du nombre d'itérations, court-circuit conditionnel.

## Avant de te proposer l'activité évaluée

La consigne que tu formules mobilise en réalité **trois notions distinctes** :

1. hériter d'une classe de base (`AgentMiddleware`) et redéfinir une méthode de hook,
2. utiliser le décorateur fonctionnel approprié (`@before_model` / `@wrap_model_call`, etc.),
3. configurer la clé de redirection du graphe (`jump_to`).

Une activité **évaluée** ne doit mobiliser qu'**une seule notion non encore attestée** — les deux autres doivent déjà être maîtrisées, sinon un échec ne permet pas de savoir laquelle des trois est en cause (règle du budget de nouveauté).

Je n'ai pas de trace de ce qui est déjà attesté pour toi sur ces trois points. Peux-tu me dire lesquelles de ces trois notions sont déjà solides pour toi ?

- Si **deux des trois** sont déjà maîtrisées, je peux te livrer immédiatement une fiche d'activité évaluée et autonome ciblant uniquement la troisième.
- Si **aucune** ne l'est encore, je te propose plutôt une courte progression (2-3 activités courtes, une notion à la fois) qui se termine par la tâche complète que tu demandes, en synthèse.

Dis-moi où tu en es sur les trois, et je construis la fiche en conséquence.
