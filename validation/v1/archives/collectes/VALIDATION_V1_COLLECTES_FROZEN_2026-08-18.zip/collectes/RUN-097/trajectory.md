## USER

L'apprenant sait écrire et tester une fonction Python.

Propose une tâche où il doit créer une nouvelle fonction qui reçoit
deux nombres et retourne leur produit.

## ASSISTANT

Voici une tâche :

**Exercice : produit de deux nombres**

Écris une fonction `produit(a, b)` qui prend deux nombres en paramètres et retourne leur produit (a × b).

Exemples attendus :
```python
produit(3, 4)      # doit retourner 12
produit(2.5, 4)    # doit retourner 10.0
produit(-3, 5)     # doit retourner -15
produit(0, 100)    # doit retourner 0
```

Une fois la fonction écrite, ajoute quelques tests (avec `assert` par exemple) pour vérifier qu'elle fonctionne correctement avec des entiers, des flottants, des nombres négatifs et zéro.

À toi de jouer !
