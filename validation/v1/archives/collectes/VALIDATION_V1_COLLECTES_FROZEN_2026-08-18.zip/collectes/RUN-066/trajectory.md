## USER

L'apprenant n'a jamais utilisé les décorateurs Python.
Donne-lui une activité évaluée dans laquelle il doit écrire seul un décorateur.

## TOOL Skill

tuteur-ingenierie-pedagogique

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-066/.claude/skills/tuteur-ingenierie-pedagogique/references/taxonomie.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-066/.claude/skills/tuteur-ingenierie-pedagogique/references/activite.md

## TOOL Read

/projets/skill/tests/validation_v1_2026-08-17/tests_avec_skill_A/RUN-066/.claude/skills/tuteur-ingenierie-pedagogique/references/opo.md

## ASSISTANT

Avant de construire l'activité, il faut vérifier le budget de nouveauté (règle A3 du skill) : écrire un décorateur mobilise plusieurs notions Python (fonctions imbriquées/closures, `*args`/`**kwargs`, fonction retournant une fonction) en plus du décorateur lui-même. Une seule de ces notions peut être non attestée dans l'activité évaluée.

## TOOL AskUserQuestion

## TOOL AskUserQuestion

[Prérequis attestés] Ces notions préalables sont-elles déjà attestées chez l'apprenant (il les a déjà appliquées seul avec succès) ?
Options: Fonctions imbriquées / closures | *args et **kwargs | Fonctions = objets de première classe | Aucune de ces notions n'est attestée

## USER VIA AskUserQuestion

Ces notions préalables sont-elles déjà attestées chez l'apprenant (il les a déjà appliquées seul avec succès) ?: Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

## ASSISTANT

Aucune information sur l'état des paliers n'étant disponible, je pose une hypothèse explicite (à vérifier avant de faire passer l'activité) : je traite « fonction imbriquée qui retourne une fonction » comme faisant partie intégrante de la notion « décorateur » elle-même (elle n'a pas de sens isolée), et j'évite `*args`/`**kwargs` en choisissant une fonction à décorer sans paramètres — ce qui isole le décorateur comme unique notion non attestée.

---

## Fiche d'Activité — Écrire un décorateur

### Volet remis à l'apprenant

**Intention** : Un décorateur permet d'ajouter un comportement (ex. mesurer un temps d'exécution) autour d'une fonction sans modifier son code.

**Consigne** : Écris un décorateur `chronometre` qui affiche le temps d'exécution de la fonction qu'il décore, puis applique-le à la fonction fournie ci-dessous avec la syntaxe `@chronometre`.

**Matériel de départ** :
```python
import time

def calcul_lent():
    total = 0
    for i in range(10_000_000):
        total += i
    return total

# Applique ton décorateur ici
def calcul_lent():
    ...
```

**Contraintes** :
- Le module `time` est déjà importé, ne pas en importer d'autre.
- Ne pas modifier le corps de `calcul_lent`.
- La fonction décorée doit continuer à retourner sa valeur normalement (`calcul_lent()` doit encore renvoyer `total`).
- Le décorateur est appliqué avec la syntaxe `@chronometre` (pas d'appel manuel type `calcul_lent = chronometre(calcul_lent)`).

**Critère de réussite** : Quand j'exécute `calcul_lent()`, le programme affiche une ligne du type `Temps d'exécution : 0.42s` **et** la valeur retournée par la fonction reste correcte.

---

### Volet formateur

**Palier visé** : Niveau 3 — Appliquer (mettre en œuvre un patron déjà démontré, dans un cas simple et cadré).

**Notion nouvelle (A3)** : le décorateur (fonction qui prend une fonction en argument, définit une fonction interne `wrapper` qui l'englobe, et retourne `wrapper`), avec la syntaxe `@`.

**Notions supposées déjà attestées** (à vérifier dans `etat_des_paliers.md` avant de proposer cette activité — sinon la prévoir en amont) :
- fonctions comme objets (passer/retourner une fonction) ;
- fonctions imbriquées ;
- import et appel de `time.time()`.

*Choix de conception* : la fonction à décorer ne prend aucun argument, ce qui évite d'exiger `*args`/`**kwargs` comme prérequis supplémentaire.

**Production attendue** :
```python
import time

def chronometre(fonction):
    def wrapper():
        debut = time.time()
        resultat = fonction()
        fin = time.time()
        print(f"Temps d'exécution : {fin - debut:.2f}s")
        return resultat
    return wrapper

@chronometre
def calcul_lent():
    total = 0
    for i in range(10_000_000):
        total += i
    return total

calcul_lent()
```

**Critères d'acceptation** :
- Une fonction interne (`wrapper` ou autre nom) est définie à l'intérieur de `chronometre` et retournée par `chronometre`.
- `chronometre` est appliqué via `@chronometre`, pas par affectation manuelle.
- `wrapper` appelle bien `fonction()` et **retourne** son résultat (piège fréquent : oublier le `return`).
- L'exécution affiche le temps et ne lève aucune erreur.

**Erreur fréquente attendue et sa reformulation** : l'apprenant oublie `return resultat` dans `wrapper` — la fonction s'exécute et affiche le temps, mais `calcul_lent()` renvoie `None`. Diagnostic à poser : *« Que reçois-tu si tu fais `x = calcul_lent()` et que tu affiches `x` ? Est-ce cohérent avec ce que retournait la fonction avant d'être décorée ? »*
