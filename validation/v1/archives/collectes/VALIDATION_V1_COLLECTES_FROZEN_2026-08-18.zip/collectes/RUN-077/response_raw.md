Voici une activité clé en main.

## Activité : Explique-moi une fonction Python

**Niveau :** débutant
**Durée estimée :** 20-30 minutes

**Objectif d'apprentissage**
Expliquer avec ses propres mots ce qu'est une fonction Python.

**Déroulement**

1. **Découverte (5 min)** — L'apprenant observe cet exemple :
```python
def addition(a, b):
    resultat = a + b
    return resultat

print(addition(3, 4))  # 7
```

2. **Reformulation (5 min)** — Sans regarder de documentation, l'apprenant rédige en 3-4 phrases, avec ses propres mots, ce qu'est une fonction Python : à quoi ça sert, ce que sont les paramètres, ce que fait `return`.

3. **Mise en pratique (10-15 min)** — L'apprenant écrit seul une fonction de son choix (par exemple : convertir une température, calculer une moyenne, dire si un nombre est pair) puis rédige **trois tests** qui vérifient son bon fonctionnement, par exemple :
```python
def est_pair(n):
    return n % 2 == 0

assert est_pair(4) == True
assert est_pair(7) == False
assert est_pair(0) == True
print("Tous les tests passent !")
```

**Critère de réussite**
✅ L'apprenant écrit seul une fonction fonctionnelle avec trois tests (les tests s'exécutent sans erreur et couvrent des cas pertinents).

**Point de vigilance pour l'évaluateur**
Vérifier que l'apprenant a écrit la fonction *lui-même* (pas copiée), que les trois tests sont distincts (pas de répétition triviale) et que la fonction s'exécute réellement sans erreur.
