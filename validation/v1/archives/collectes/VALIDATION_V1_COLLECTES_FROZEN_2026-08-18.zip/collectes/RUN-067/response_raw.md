# Exercice noté — API de gestion de bibliothèque (FastAPI + SQLAlchemy async + Pydantic + Docker)

## Contexte

Vous devez développer une API REST permettant de gérer une bibliothèque : livres, auteurs, membres et emprunts. L'API doit être entièrement asynchrone, containerisée, et respecter des contraintes métier strictes.

Note : cet exercice est volontairement exigeant. Il combine plusieurs notions rarement vues ensemble en début d'apprentissage (async ORM, relations, transactions, validation avancée, containerisation multi-services). Prévoyez du temps et n'hésitez pas à consulter la documentation officielle.

---

## 1. Stack imposée

- **FastAPI** (routes async)
- **SQLAlchemy 2.0** en mode **async** (`AsyncSession`, `create_async_engine`)
- **Pydantic v2** (schémas + validation)
- **PostgreSQL** comme base de données (pas SQLite)
- **Docker** + **docker-compose** (2 services minimum : `api` et `db`)
- **Alembic** pour les migrations (pas de `create_all` en production)

---

## 2. Modèle de données

Quatre entités liées :

- **Author** : `id`, `name`, `birth_year`
- **Book** : `id`, `title`, `isbn` (unique), `published_year`, `available_copies`, `author_id` (FK)
- **Member** : `id`, `email` (unique), `name`, `registered_at`
- **Loan** : `id`, `book_id` (FK), `member_id` (FK), `borrowed_at`, `due_at`, `returned_at` (nullable)

Relations : un auteur a plusieurs livres ; un livre peut avoir plusieurs emprunts (historique) ; un membre peut avoir plusieurs emprunts.

---

## 3. Endpoints requis

| Méthode | Route | Contrainte métier |
|---|---|---|
| POST | `/authors` | — |
| GET | `/authors/{id}` | Doit inclure la liste des livres (relation chargée en async, `selectinload`) |
| POST | `/books` | ISBN validé par regex (format ISBN-13) |
| GET | `/books?author_id=&available=` | Filtres optionnels combinables |
| POST | `/members` | Email validé (Pydantic `EmailStr`) |
| POST | `/loans` | **Voir règles ci-dessous** |
| PATCH | `/loans/{id}/return` | Marque `returned_at`, incrémente `available_copies` |
| GET | `/members/{id}/loans` | Historique complet, y compris emprunts rendus |

### Règles métier pour `POST /loans` (le cœur de la difficulté)

1. Refuser si `available_copies == 0` (HTTP 409).
2. Refuser si le membre a déjà **3 emprunts non rendus** (HTTP 403).
3. L'opération (vérification + décrément de `available_copies` + création du `Loan`) doit être **atomique** : utilisez une transaction explicite et gérez le cas de concurrence (deux requêtes simultanées ne doivent jamais faire passer `available_copies` en négatif). Indice : `SELECT ... FOR UPDATE` ou un verrou optimiste avec retry.
4. `due_at` = `borrowed_at` + 14 jours, calculé côté serveur.

---

## 4. Contraintes techniques précises

- Toute la couche base de données doit utiliser des fonctions `async def` (pas d'appel bloquant type `requests` ou driver sync).
- Utiliser le driver `asyncpg`.
- Les schémas Pydantic doivent séparer clairement : `Create` (entrée), `Read` (sortie), et éventuellement `Update`. Pas de modèle unique réutilisé partout.
- Utiliser `response_model` sur chaque route.
- Gérer les erreurs avec des `HTTPException` explicites (pas de 500 pour des cas prévisibles).
- Le fichier `docker-compose.yml` doit :
  - définir un `healthcheck` sur le service `db`
  - faire attendre l'API que la DB soit prête (`depends_on: condition: service_healthy`)
  - utiliser une variable d'environnement pour l'URL de connexion (pas de mot de passe en dur dans le code)
- Fournir un `Dockerfile` multi-stage (build + runtime) pour l'API.

---

## 5. Livrables

1. Code source complet (structure de projet libre mais organisée : `app/models`, `app/schemas`, `app/routers`, `app/db.py`, etc.)
2. `Dockerfile`, `docker-compose.yml`, `.env.example`
3. Dossier `alembic/` avec au moins une migration initiale
4. Un fichier `README.md` expliquant comment lancer le projet (`docker-compose up`) et listant les endpoints
5. Au moins **5 tests** avec `pytest` + `httpx.AsyncClient` (ou `pytest-asyncio`) couvrant : création de livre, emprunt réussi, emprunt refusé (0 copie), emprunt refusé (3 max), retour de livre

---

## 6. Barème indicatif (/20)

| Critère | Points |
|---|---|
| Modélisation SQLAlchemy correcte (relations, contraintes) | 3 |
| Endpoints CRUD fonctionnels avec bons codes HTTP | 4 |
| Règles métier des emprunts (dont gestion de la concurrence) | 5 |
| Qualité des schémas Pydantic (séparation Create/Read, validation) | 3 |
| Docker/docker-compose fonctionnel (healthcheck, multi-stage) | 3 |
| Tests automatisés | 2 |

**Bonus (+2)** : ajouter une authentification JWT sur les routes d'emprunt (seul un membre authentifié peut emprunter en son propre nom).

---

## 7. Ce qui rend cet exercice difficile pour un débutant

- L'async avec SQLAlchemy casse beaucoup de réflexes appris en sync (pas de lazy loading implicite, sessions à gérer explicitement).
- La gestion de concurrence sur `available_copies` est un vrai piège classique (race condition) rarement traité en exercice débutant.
- Le multi-stage Docker + `depends_on healthy` exige de comprendre l'ordre de démarrage des conteneurs, pas juste "ça marche sur ma machine".
- Alembic (au lieu de `create_all`) introduit la notion de migration versionnée, absente des tutoriels basiques.

Voulez-vous que je détaille une **solution de référence** (corrigé) pour que vous puissiez noter, ou préférez-vous garder l'énoncé seul pour l'instant ?
