Middlewares LangChain
======================

## Ce que c'est

Un middleware LangChain (côté `langgraph`/agents LangChain, ex. `AgentExecutor` moderne ou `create_react_agent`) est un composant qui s'intercale dans le cycle de vie d'un agent pour observer ou modifier son comportement à des points précis, sans toucher à la logique métier de l'agent lui-même. C'est le pendant, pour les agents, des middlewares HTTP (Express, Django...) : chaque middleware reçoit un état/contexte, peut le transformer, et décide de passer la main au composant suivant ou de dérouter le flux.

## Points d'accroche typiques

Un middleware peut s'exécuter à différents moments :
- **avant l'appel au modèle** (`before_model` / `on_start`) : modifier le prompt, injecter du contexte, valider une entrée ;
- **après l'appel au modèle** (`after_model`) : logger, filtrer une sortie toxique, réécrire une réponse ;
- **avant/après l'exécution d'un outil (tool call)** : valider les arguments, mesurer la latence, mettre en cache ;
- **sur erreur** : retry, fallback vers un autre modèle.

## Pourquoi c'est utile

- **Séparation des responsabilités** : logging, sécurité, retry, garde-fous ne polluent pas la logique de l'agent.
- **Composabilité** : on empile plusieurs middlewares (ex. `LoggingMiddleware` + `RateLimitMiddleware` + `ContentFilterMiddleware`).
- **Contrôle du graphe d'exécution** : un middleware peut décider de **rediriger** l'exécution (ex. renvoyer vers un nœud "human review" au lieu de continuer), via une clé de redirection dans l'état du graphe (souvent quelque chose comme `goto` / `next` dans `langgraph`).

## Mécanique d'implémentation

- Classe de base : on hérite d'une classe comme `AgentMiddleware` (ou équivalent selon la version de la lib).
- Décorateur : certaines méthodes doivent être marquées avec un décorateur dédié (ex. `@hook("before_model")` ou `@middleware.before_model`) pour indiquer à quel point du cycle de vie elles s'accrochent.
- Clé de redirection : dans l'état retourné, on positionne une clé spéciale (ex. `goto`) que le graphe (`langgraph`) lit pour savoir vers quel nœud router ensuite, permettant de casser le flux linéaire par défaut.

---

Spécification de l'activité évaluée et autonome
================================================

## Titre
Implémenter un middleware LangChain personnalisé avec redirection de graphe

## Contexte donné à l'apprenant
Un agent LangGraph existe déjà avec un flux linéaire : `input → model → tool → output`. L'objectif est d'intercepter l'exécution avant l'appel au modèle pour détecter une condition (ex. mot-clé sensible dans l'entrée utilisateur) et, si elle est remplie, dérouter le graphe vers un nœud `human_review` au lieu de laisser le flux continuer normalement.

## Livrable attendu
Un fichier `custom_middleware.py` contenant une classe `SensitiveContentMiddleware` répondant au cahier des charges ci-dessous.

## Cahier des charges (obligatoire)

1. **Héritage** : la classe doit hériter de la classe de base fournie par la librairie (`AgentMiddleware` ou équivalent selon la version installée — l'apprenant doit vérifier l'import exact dans la doc/version utilisée).
2. **Décorateur** : la méthode d'interception doit être annotée avec le décorateur correspondant au hook `before_model` (nom exact à vérifier selon la version : décorateur de méthode ou méthode nommée conventionnellement selon l'API).
3. **Détection de condition** : la méthode lit l'état courant (`state`) et vérifie si l'entrée utilisateur contient un mot-clé d'une liste `SENSITIVE_KEYWORDS = ["urgence", "danger", "plainte"]`.
4. **Clé de redirection** : si la condition est vraie, la méthode retourne (ou modifie l'état pour inclure) la clé de redirection du graphe (ex. `goto="human_review"`) ; sinon elle retourne `None`/l'état inchangé pour laisser le flux continuer normalement.
5. **Traçabilité** : chaque déclenchement du middleware doit être loggé (niveau INFO) avec le mot-clé détecté et l'horodatage.
6. **Intégration** : le middleware doit être enregistré dans la liste des middlewares de l'agent (`middleware=[SensitiveContentMiddleware()]` ou équivalent).

## Contraintes techniques
- Python ≥ 3.10, `langchain`/`langgraph` en dernière version stable au moment du travail.
- Aucune dépendance externe supplémentaire.
- Le code doit être testable sans clé API réelle (utiliser un modèle mocké ou un stub pour l'appel LLM).

## Grille d'évaluation (barème sur 20, autonome — l'apprenant s'auto-corrige avec cette grille)

| Critère | Points |
|---|---|
| Héritage correct de la classe de base | 3 |
| Décorateur/hook correctement appliqué et déclenché au bon moment du cycle | 4 |
| Détection de mot-clé fonctionnelle (tests sur au moins 3 cas : positif, négatif, casse mixte) | 4 |
| Redirection de graphe effective (le nœud `human_review` est bien atteint quand attendu) | 5 |
| Logging présent et informatif | 2 |
| Code propre, sans dépendance inutile, lisible | 2 |
| **Total** | **20** |

## Critères de réussite (seuil d'autonomie)
- ≥ 16/20 : validé sans supervision.
- 12–15/20 : à corriger sur les points faibles identifiés puis re-tester.
- < 12/20 : revoir la section "Mécanique d'implémentation" ci-dessus avant de recommencer.

## Test d'auto-validation à exécuter
Écrire un test unitaire (`pytest`) qui :
1. Instancie l'agent avec le middleware,
2. Envoie l'entrée `"J'ai une urgence"` → vérifie que le graphe route vers `human_review`,
3. Envoie l'entrée `"Quel temps fait-il ?"` → vérifie que le graphe continue le flux normal,
4. Capture les logs et vérifie la présence du message de traçabilité pour le cas positif.

---

**Note méthodologique pour l'apprenant** : les noms exacts du décorateur et de la classe de base varient selon la version de LangChain/LangGraph installée (l'API middleware a évolué). Avant de coder, vérifier dans l'environnement réel (`pip show langchain langgraph`, documentation officielle correspondant à la version) les noms exacts — ne pas supposer qu'ils sont figés.
