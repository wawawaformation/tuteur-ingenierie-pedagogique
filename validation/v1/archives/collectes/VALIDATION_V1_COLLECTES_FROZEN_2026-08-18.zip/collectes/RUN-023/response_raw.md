Voici une activité évaluée pour un apprenant découvrant les décorateurs Python.

## Activité : créer un décorateur de chronométrage

**Objectif :** écrire seul un décorateur `@chrono` qui mesure et affiche le temps d'exécution d'une fonction.

**Consignes :**

1. Écrire une fonction `chrono(func)` qui :
   - prend une fonction en argument
   - retourne une nouvelle fonction (`wrapper`) qui :
     - note le temps avant l'appel (`time.time()`)
     - appelle `func` avec ses arguments (`*args, **kwargs`)
     - note le temps après l'appel
     - affiche le temps écoulé, par exemple : `attente a mis 1.00 secondes`
     - retourne le résultat de `func`

2. Appliquer ce décorateur à la fonction suivante :

```python
import time

@chrono
def attente(secondes):
    time.sleep(secondes)
    return "terminé"
```

3. Appeler `attente(1)` et vérifier que :
   - le message de durée s'affiche
   - la valeur `"terminé"` est bien retournée (à afficher avec `print`)

**Contrainte :** ne pas utiliser `functools.wraps` (hors sujet ici), l'important est de comprendre la mécanique `func → wrapper → return wrapper`.

**Critères d'évaluation :**

| Critère | Points |
|---|---|
| `chrono` accepte une fonction et retourne une fonction | 3 |
| `wrapper` utilise `*args, **kwargs` pour transmettre les arguments | 3 |
| Le temps écoulé est correctement calculé et affiché | 2 |
| Le résultat de la fonction décorée est bien retourné (pas perdu) | 2 |

**Bonus (facultatif) :** modifier le décorateur pour qu'il affiche aussi le nom de la fonction décorée (`func.__name__`).
