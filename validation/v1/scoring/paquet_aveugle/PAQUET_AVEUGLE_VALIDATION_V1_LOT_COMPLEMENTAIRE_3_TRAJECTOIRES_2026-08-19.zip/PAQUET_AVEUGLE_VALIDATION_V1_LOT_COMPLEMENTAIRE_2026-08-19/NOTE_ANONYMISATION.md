# Note d'anonymisation du lot complémentaire

Les unités de scoring conservent les tours utilisateur et les réponses assistant nécessaires au jugement pédagogique.

Sont retirés des unités scoreur :

- appels internes au skill ;
- lectures de fichiers et commandes internes ;
- chemins de workspace ;
- identifiants `RUN-*` ;
- métadonnées de condition et de répétition.

Cette transformation vise uniquement à empêcher un désaveuglement direct par l'infrastructure. Elle ne modifie pas les contenus pédagogiques utilisateur/assistant utilisés par les oracles historiques.
