# TRAJ-X001

**Test historique : T26**

---

## UTILISATEUR

L'apprenant sait écrire et tester une fonction Python.

Propose une tâche où il doit créer une nouvelle fonction qui reçoit
deux nombres et retourne leur produit.

## ASSISTANT

Voici la fiche d'Activité respectant le format des deux volets (A3 : une seule notion nouvelle — ici, la définition d'une fonction à deux paramètres qui retourne un calcul ; « écrire et tester une fonction » est déjà attesté et réutilisé tel quel).

## Volet remis à l'apprenant

**Intention** — S'entraîner à écrire une fonction qui combine deux valeurs reçues en paramètres pour produire un résultat calculé.

**Consigne** — Écris une fonction `produit(a, b)` qui reçoit deux nombres et retourne leur produit. Écris ensuite un test qui vérifie son bon fonctionnement.

**Matériel de départ** — Un fichier vide `produit.py`.

**Contraintes**
- La fonction doit s'appeler `produit` et accepter exactement deux paramètres.
- Elle doit *retourner* le résultat (pas de `print`).
- Le test doit vérifier au moins un cas avec deux entiers positifs (par exemple `produit(3, 4)` doit valoir `12`).

**Critère de réussite** — Le test s'exécute et confirme que `produit(a, b)` renvoie bien le résultat attendu, sans erreur.

## Volet conservé par le formateur

**Palier visé** — 3. Appliquer (mettre en œuvre une procédure connue — écrire/tester une fonction — sur un cas simple nouveau).

**Notion nouvelle** — une fonction à deux paramètres qui retourne un calcul (ici une multiplication). Le reste (syntaxe `def`, écriture d'un test, exécution) est déjà attesté.

**Production attendue**
```python
def produit(a, b):
    return a * b

assert produit(3, 4) == 12
```

**Critères d'acceptation** — La fonction retourne (et n'affiche pas) le produit ; le test passe pour au moins un cas ; la ligne « fonction à deux paramètres retournant un calcul » passe à attesté dans l'état des paliers.

**Erreur fréquente attendue et sa reformulation** — L'apprenant utilise `print(a * b)` au lieu de `return a * b` : plutôt que « c'est faux », demander *« si tu appelles `x = produit(3, 4)`, que contient `x` à ton avis ? »*
