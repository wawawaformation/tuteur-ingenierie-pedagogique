# Paquet aveugle V1 — lot complémentaire

Ce paquet contient 3 trajectoires anonymisées à évaluer indépendamment.

Utiliser `PROMPT_SCOREUR_V1_LOT_COMPLEMENTAIRE.txt` et suivre strictement
`PROCEDURE_SCOREUR_V1_LOT_COMPLEMENTAIRE.md`.

Ne pas chercher à désaveugler les trajectoires et ne consulter aucun autre scoring.
