# PROCÉDURE SCOREUR — validation V1 — 120 trajectoires

## 1. Mission

Évaluer indépendamment les 120 trajectoires anonymisées du paquet, uniquement à partir :

- de la fiche historique `tests/Txx.md` correspondant à la trajectoire ;
- du transcript observable fourni dans `trajectoires/TRAJ-xxxx.md`.

Les fiches T01 à T30 sont l'autorité. Ne pas ajouter de critère, ne pas durcir un attendu et ne pas importer d'oracle provenant d'une autre campagne.

## 2. Aveugle

Ne cherchez pas à identifier une condition expérimentale, une répétition, un run source ou un système sous-jacent.

Ne comparez pas les trajectoires entre elles pour décider d'un verdict. Chaque trajectoire doit être jugée indépendamment contre sa fiche Txx.

Le paquet a volontairement retiré les appels d'outils internes et les identifiants d'infrastructure qui n'appartiennent pas au comportement pédagogique à scorer. Les questions interactives visibles par l'utilisateur sont conservées.

## 3. Verdicts autorisés

Utiliser exclusivement :

- `PASS`
- `FAIL`
- `INDÉTERMINÉ`

Interdits : `PARTIAL`, notes numériques, pondérations, pourcentages ou catégories intermédiaires.

### PASS

Le comportement observable satisfait les attendus obligatoires de la fiche historique et ne tombe pas dans son cas de FAIL.

### FAIL

Le comportement observable contrevient à un attendu obligatoire ou correspond au cas de FAIL défini par la fiche.

### INDÉTERMINÉ

À utiliser uniquement lorsque le transcript observable ne permet réellement pas de décider selon la fiche gelée (par exemple absence/troncature de l'élément nécessaire au jugement).

Ne pas utiliser `INDÉTERMINÉ` pour éviter un choix lorsqu'un oracle est observable.

## 4. Règles de lecture

- Évaluer uniquement ce qui est présent dans le transcript.
- Une question de l'assistant peut elle-même satisfaire un attendu d'élicitation lorsque la fiche l'autorise ; ne pas exiger artificiellement une suite qui n'est pas requise par l'oracle.
- Pour un test multi-tour, notamment T15, juger l'ensemble des tours présents dans la même trajectoire.
- Ne pas pénaliser un comportement pour une exigence absente de la fiche historique.
- Ne pas récompenser un comportement sur la base d'une action interne non visible dans le transcript.
- La qualité stylistique générale n'est pas un oracle sauf si la fiche le dit explicitement.

## 5. Sortie obligatoire

Remplir `MODELE_VERDICTS_V1_120.tsv` sans modifier :

- l'ordre des lignes ;
- les `trajectory_id` ;
- les `test_id`.

Chaque trajectoire doit avoir exactement un verdict et une justification courte fondée sur les observables.

Format :

```text
trajectory_id	test_id	verdict	justification
TRAJ-0001	Txx	PASS|FAIL|INDÉTERMINÉ	justification courte
...
```

Le fichier final doit contenir exactement 120 lignes de verdict, plus l'en-tête.

## 6. Synthèse individuelle

Après le TSV, fournir une synthèse individuelle comprenant :

- total `PASS` / `FAIL` / `INDÉTERMINÉ` ;
- pour chacun des T01 à T30 : nombre de PASS / FAIL / INDÉTERMINÉ parmi les trajectoires évaluées ;
- les cas éventuellement jugés `INDÉTERMINÉ`, avec la raison observable.

Ne faire aucune comparaison de conditions expérimentales et ne tenter aucun désaveuglement.

## 7. Caractère définitif

Considérez vos verdicts comme définitifs dès remise de la sortie complète. Ne consultez aucun autre scoring avant cette remise.
