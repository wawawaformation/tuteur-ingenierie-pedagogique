# Note d'anonymisation du paquet scoreur

Les unités de scoring conservent :

- les tours utilisateur ;
- les réponses assistant ;
- les questions interactives visibles et les réponses utilisateur associées.

Sont retirés des unités scoreur :

- appels internes au skill ;
- lectures de fichiers et commandes internes ;
- chemins de workspace ;
- identifiants `RUN-*` ;
- noms d'infrastructure permettant d'identifier directement une condition.

Cette transformation vise uniquement à empêcher un désaveuglement direct par l'infrastructure. Elle ne modifie pas les contenus pédagogiques utilisateur/assistant utilisés par les oracles historiques.
