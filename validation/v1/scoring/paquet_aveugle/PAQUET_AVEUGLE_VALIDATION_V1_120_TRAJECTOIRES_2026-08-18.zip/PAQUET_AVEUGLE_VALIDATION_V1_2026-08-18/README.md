# Paquet aveugle — validation V1 — 120 trajectoires

Contenu :

- `PROCEDURE_SCOREUR_V1_120.md` : procédure d'évaluation ;
- `PROMPT_SCOREUR_V1_120.txt` : prompt de lancement commun aux scoreurs ;
- `MODELE_VERDICTS_V1_120.tsv` : sortie TSV à compléter ;
- `INDEX_TRAJECTOIRES.tsv` : association publique trajectoire anonymisée → test historique ;
- `tests/T01.md` à `tests/T30.md` : fiches historiques gelées ;
- `trajectoires/TRAJ-0001.md` à `TRAJ-0120.md` : transcripts anonymisés ;
- `SHA256SUMS.txt` : empreintes de tous les fichiers du paquet hors lui-même.

Le même ZIP doit être remis sans modification aux deux scoreurs indépendants.

Aucune table de correspondance avec les runs, conditions ou répétitions n'est incluse dans ce paquet.
