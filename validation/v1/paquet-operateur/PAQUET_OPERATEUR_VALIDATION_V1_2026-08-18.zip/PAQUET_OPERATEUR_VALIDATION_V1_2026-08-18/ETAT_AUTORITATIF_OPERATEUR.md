# État autoritatif pour passage à l'agent opérateur

## Frontière expérimentale

La phase de conception et de préparation est close.

Référence de gel :

```text
commit : a132ef59e6010d7d264545f70f50233be22ca159
tag    : validation-v1-runtime-frozen
```

Le tag a été vérifié comme pointant sur ce commit et le `git status --short`
était vide au moment du gel.

## Éléments gelés

L'agent opérateur ne doit pas modifier :

```text
/projets/skill/tuteur-ingenierie-pedagogique/en_cours/
/projets/skill/tuteur-ingenierie-pedagogique/validation/v1/tests/
/projets/skill/tuteur-ingenierie-pedagogique/validation/v1/plan/
/projets/skill/tuteur-ingenierie-pedagogique/validation/collector-kit/
/projets/skill/tuteur-ingenierie-pedagogique/validation/v1/operateur/
/projets/skill/tuteur-ingenierie-pedagogique/docs/protocole_operateur.md
```

Les manifestes applicables sont sous :

```text
/projets/skill/tuteur-ingenierie-pedagogique/validation/v1/manifest/
```

## Plan

Le plan initial est :

```text
/projets/skill/tuteur-ingenierie-pedagogique/validation/v1/plan/RUNS.csv
```

Il comporte 120 runs initiaux :

```text
30 tests × 2 conditions × 2 répétitions
```

Les 60 runs potentiels de troisième répétition sont pré-déclarés dans :

```text
/projets/skill/tuteur-ingenierie-pedagogique/validation/v1/plan/RUNS_CONDITIONNELS.csv
```

Ils ne doivent pas être lancés pendant la série initiale. Ils ne deviennent
éligibles qu'après scoring des deux répétitions initiales du couple
`test × condition` et uniquement en cas de désaccord.

## Premier run attendu

Le premier run du plan a été vérifié à blanc :

```text
run_id      = RUN-001
test_id     = T13
condition   = avec skill
repetition  = 1
status      = PLANNED
```

Si le dépôt lu par l'opérateur ne donne pas ces valeurs en première ligne,
l'opérateur doit signaler `STOP — plan différent de la référence` et ne pas
lancer Claude.

## Runtime

Racine exclusive de la nouvelle campagne :

```text
/projets/skill/tests/validation_v1_2026-08-17
```

Sous-répertoires :

```text
/prompts
/runs
/tests_avec_skill_A
/tests_sans_skill_B
```

## Paramètres communs

```text
Claude Code      : 2.1.232
binaire          : /home/david/.local/share/claude/versions/2.1.232
modèle           : claude-sonnet-5
effort           : medium
permission mode  : default
auto-update      : désactivé
auto-memory      : désactivée
persona          : aucune
```

Convention collector :

```text
avec skill  -> condition=skill    -> skill-expected=yes
sans skill  -> condition=no-skill -> skill-expected=n/a
```

## Principe d'exécution

Un run à la fois :

```text
BLOC 1
→ interaction avec Claude
→ exit dans Claude Code
→ BLOC 2
```

Deux blocs shell maximum par run.

Le `exit` utilisé pour terminer Claude Code est une interaction dans Claude.
En revanche, les blocs shell fournis à l'utilisateur ne doivent pas contenir
`exit`, `exit 1`, `set -e` ou `set -euo pipefail`.

Toutes les commandes terminal données à l'utilisateur doivent employer des
chemins absolus.

## Interactions

L'opérateur interprète la nature de la demande de Claude.

Si une information pédagogique est explicitement prévue par la fiche T gelée,
il fournit exactement cette information.

Si une information pédagogique nécessaire n'est ni dans le prompt ni prévue
par la fiche gelée, la réponse neutre exacte est :

> Je n'ai pas d'information supplémentaire. Poursuis avec les éléments disponibles.

Une proposition facultative après une réponse déjà complète ne déclenche pas un
nouveau tour si la fiche historique ne l'exige pas.

Les demandes de confiance, permissions et autres interactions d'interface sont
traitées comme techniques et ne doivent pas servir à injecter du contenu
pédagogique.

## Scoring

L'agent opérateur ne score pas les trajectoires.

Il peut qualifier l'état technique d'un run selon le protocole, mais il ne
produit aucun PASS/FAIL pédagogique et ne relance jamais un run parce que le
résultat semble favorable ou défavorable.

Un rerun n'est autorisé qu'en cas d'invalidité technique réelle et doit être
identifié séparément.
