# Paquet opérateur — validation V1

## Objet

Ce paquet sert à ouvrir une conversation séparée avec l'agent opérateur chargé
de l'exécution de la campagne V1.

Il ne remplace pas le dépôt gelé. Les fichiers du dépôt à la référence Git
figée restent la source d'autorité pour le candidat, les tests, le plan et le
collector.

## Référence gelée

```text
dépôt  : /projets/skill/tuteur-ingenierie-pedagogique
commit : a132ef59e6010d7d264545f70f50233be22ca159
tag    : validation-v1-runtime-frozen
```

Le tag a été vérifié localement comme pointant vers exactement ce commit.

## Racine d'exécution

```text
/projets/skill/tests/validation_v1_2026-08-17
```

Les anciens artefacts présents ailleurs sous `/projets/skill/tests/` ne doivent
ni être supprimés ni être écrasés.

## Contenu du paquet

- `PROMPT_A_DONNER_A_L_AGENT_OPERATEUR.md` : prompt de démarrage à copier-coller ;
- `ETAT_AUTORITATIF_OPERATEUR.md` : frontière et règles de passage de main ;
- `documents/protocole_operateur.md` : protocole opérateur gelé ;
- `documents/operateur/` : paramètres, BLOC1, BLOC2, interactions et décision
  d'isolation runtime ;
- `documents/etat/ETAT_VALIDATION_V1_2026-08-18.md` : état post-gel ;
- `MANIFEST_PAQUET.sha256` : intégrité du présent paquet.

## Utilisation recommandée

1. pousser le commit et le tag si ce n'est pas déjà confirmé ;
2. ouvrir une nouvelle conversation dédiée ;
3. joindre `PAQUET_OPERATEUR_VALIDATION_V1_2026-08-18.zip` ;
4. copier-coller le contenu de `PROMPT_A_DONNER_A_L_AGENT_OPERATEUR.md` ;
5. laisser l'agent opérateur commencer par son préflight global ;
6. exécuter ensuite un seul run à la fois.

Aucun run comportemental n'avait été lancé au moment du gel de référence.


## Source des tests et du plan

Le paquet inclut une copie du jeu de tests historique V1 sous :

```text
documents/tests/jeu_de_tests_v1.md
```

Elle sert à l'agent pour comprendre les tests et interpréter les interactions.

En revanche, `RUNS.csv` n'est volontairement pas dupliqué dans ce paquet :
l'ordre randomisé de la campagne doit toujours être lu directement depuis le
fichier gelé du dépôt :

```text
/projets/skill/tuteur-ingenierie-pedagogique/validation/v1/plan/RUNS.csv
```

Cela évite qu'une copie de plan dans le paquet devienne une seconde source
d'autorité.
