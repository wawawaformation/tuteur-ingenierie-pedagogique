# Paquet d’adjudication aveugle V2 — 3 trajectoires

Ce paquet contient uniquement trois trajectoires nécessitant une adjudication indépendante.

Il ne contient :
- aucune condition expérimentale ;
- aucune répétition ;
- aucun run source ;
- aucun mapping privé ;
- aucun verdict des scoreurs précédents.

L’adjudicateur applique strictement `PROCEDURE_SCOREUR.md` et l’oracle correspondant à chaque `scenario_id`.
