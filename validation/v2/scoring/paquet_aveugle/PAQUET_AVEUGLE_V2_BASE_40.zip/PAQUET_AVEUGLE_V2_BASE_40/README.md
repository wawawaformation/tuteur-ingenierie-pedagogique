# Paquet aveugle V2 — base

40 trajectoires anonymisées.
