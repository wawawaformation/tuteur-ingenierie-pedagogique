# Bloc 2 — collecte et archivage du run

Le BLOC 2 est exécuté **uniquement après avoir quitté Claude Code avec
`exit`**.

## Commande canonique

`RUN-ID` est le même identifiant que dans le BLOC 1.

```bash
PKG="/projets/skill/tests/validation_v2_40runs_2026-08-21/PAQUET_OPERATEUR_VALIDATION_V2_40_RUNS_FROZEN_2BLOCS_2026-08-21"
export V2_CAMPAIGN_ROOT="/projets/skill/tests/validation_v2_40runs_2026-08-21/execution"

cd "$PKG"
python3 "$PKG/OUTILS/finalize_run.py" RUN-ID
```

## Contrôles attendus

Le retour doit permettre de vérifier au minimum :

```text
COLLECT=OK
TOKENS_STATUS=OBSERVABLE
ARCHIVE=...
SHA256=...
```

Une réponse pédagogiquement mauvaise n'est pas une invalidité technique.
Aucun rerun n'est lancé pour améliorer un résultat.
