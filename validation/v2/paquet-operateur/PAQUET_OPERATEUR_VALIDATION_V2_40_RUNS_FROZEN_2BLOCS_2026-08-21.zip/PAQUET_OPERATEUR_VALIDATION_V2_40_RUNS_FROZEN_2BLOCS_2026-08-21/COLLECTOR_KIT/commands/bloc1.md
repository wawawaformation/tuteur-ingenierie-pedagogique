# Bloc 1 — préparation et lancement du run

Le BLOC 1 est fourni par l'agent opérateur à l'opérateur humain.
Il prépare **un seul run** puis lance sa session Claude Code.

## Commande canonique

`RUN-ID` est remplacé par l'identifiant exact de `RUNS.csv`.

```bash
PKG="/projets/skill/tests/validation_v2_40runs_2026-08-21/PAQUET_OPERATEUR_VALIDATION_V2_40_RUNS_FROZEN_2BLOCS_2026-08-21"
export V2_CAMPAIGN_ROOT="/projets/skill/tests/validation_v2_40runs_2026-08-21/execution"
export DISABLE_AUTOUPDATER=1
export CLAUDE_CODE_DISABLE_AUTO_MEMORY=1

cd "$PKG"
python3 "$PKG/OUTILS/prepare_run.py" RUN-ID --launch
```

## Pendant le run

Le prompt, la condition, la persona et les fixtures sont déterminés par le
plan gelé. L'opérateur humain ne les adapte pas.

Si Claude Code demande une précision, propose un choix ou demande une
permission, appliquer `INTERACTIONS_OPERATEUR.md` et la consigne du scénario.

Ne jamais utiliser automatiquement `Esc` ou une réponse neutre : le choix
dépend de ce qui permet de rendre observable le comportement testé sans
introduire artificiellement de nouveaux éléments.

Quand la trajectoire est terminée, quitter Claude Code avec :

```text
exit
```

Puis demander / exécuter le BLOC 2.
