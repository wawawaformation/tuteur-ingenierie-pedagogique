# Paquet opérateur — validation V2 — 40 runs — GELÉ

> **Aucun run officiel ne doit être lancé tant que le paquet n'a pas été contrôlé puis explicitement gelé.**

Ce paquet prépare une campagne confirmatoire de **40 runs de base** autour d'une batterie unique de douze scénarios `NOY001` à `NOY012` :

- `NOY001` à `NOY008` : avec skill / sans skill, 2 répétitions par condition, soit 32 runs ;
- `NOY009` à `NOY012` : avec skill uniquement, 2 répétitions, soit 8 runs.

La consommation de tokens est collectée comme **mesure secondaire d'efficience**. Elle ne participe jamais aux verdicts pédagogiques.

## Ordre de lecture opérateur

1. `STATUT_GEL.md`
2. `ETAT_AUTORITATIF.md`
3. `PLAN_EXPERIMENTAL.md`
4. `DIRECTIVES_OPERATEUR.md`
5. `INTERACTIONS_OPERATEUR.md`
6. `PARAMETRES_EXECUTION.md`
7. `REGLE_REPETITIONS.md`
8. `DECISION_GO_STOP.md`
9. `RUNS.csv`
10. `RANDOMISATION.txt`

## Outils

- `OUTILS/prepare_run.py` : prépare un workspace neuf et initialise la collecte ;
- `OUTILS/finalize_run.py` : collecte et archive le run, puis affiche les compteurs de tokens ;
- `OUTILS/summarize_token_usage.py` : produit la synthèse descriptive de consommation ;
- `OUTILS/build_blind_package.py` : fabrique un paquet scoreur aveugle des trajectoires collectées ;
- `OUTILS/compare_scores.py` : compare deux scorings indépendants ;
- `OUTILS/unblind_scores.py` : désaveugle un scoring gelé.

## Principe essentiel

L'opérateur protège l'objectif expérimental, pas une chorégraphie mécanique. Il utilise les informations prévues ou disponibles lorsqu'elles sont pertinentes, sans souffler artificiellement la réponse attendue ni introduire un élément qui modifierait ce que le test cherche à mesurer.

## Pilotage des runs

La campagne utilise le mode conversationnel **deux blocs** :

- BLOC 1 : préparation + lancement de la session testée ;
- BLOC 2 : collecte + archivage + métriques de tokens.

Voir `MODE_OPERATEUR_2_BLOCS.md`.
