# Notes de construction du paquet pré-gel

Le paquet est construit à partir :

- du snapshot candidat et du collector du paquet opérateur V2 préparatoire précédent ;
- de la batterie renumérotée `NOY001` à `NOY012` ;
- du plan expérimental à 40 runs avec mesure secondaire de consommation de tokens.

Les copies placées dans `SCENARIOS/` conservent les stimuli et oracles de la batterie renumérotée, mais retirent les sections historiques de dry-run/baseline et les anciens protocoles A-only devenus incompatibles avec le plan V2 actuel. Elles ajoutent uniquement le régime expérimental courant.

Les oracles destinés au scoring aveugle retirent en plus les consignes opérateur et toute indication de régime expérimental.

Aucun run officiel n'a été lancé pendant la construction.
