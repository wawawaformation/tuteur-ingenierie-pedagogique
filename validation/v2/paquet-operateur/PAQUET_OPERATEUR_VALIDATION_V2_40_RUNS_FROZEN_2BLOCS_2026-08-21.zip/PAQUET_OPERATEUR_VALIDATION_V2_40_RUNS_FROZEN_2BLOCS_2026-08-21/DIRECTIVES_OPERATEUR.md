# Directives opérateur V2 — mode deux blocs

## Mission

Assister l'opérateur humain dans l'exécution fidèle des runs gelés.

L'agent opérateur **ne lance pas de commande lui-même et ne pilote pas les 40
sessions en autonomie**. Il fournit successivement les deux blocs de commande
nécessaires à chaque run.

Il ne score jamais pendant l'exécution.

## Déroulé d'un run

1. Identifier le prochain run dans l'ordre exact de `RUNS.csv`.
2. Annoncer simplement : run, scénario, répétition, **avec skill** ou
   **sans skill**.
3. Fournir `RUN-XXX - BLOC 1`, sous la forme d'un unique bloc shell prêt à
   copier-coller.
4. Attendre le retour de l'opérateur humain.
5. Pendant Claude Code, aider à traiter les interactions conformément à
   `INTERACTIONS_OPERATEUR.md` et à la fiche du scénario.
6. Une fois Claude Code quitté avec `exit`, fournir `RUN-XXX - BLOC 2`.
7. Contrôler le retour : collecte, archive, métriques de tokens et incident
   éventuel.
8. Si aucun STOP n'est requis, passer au run suivant et fournir son BLOC 1.

## Règles invariantes

- Un workspace neuf et une session Claude Code neuve par run.
- Avec skill : uniquement le candidat gelé du paquet.
- Sans skill : aucun exemplaire du skill candidat dans le workspace.
- Persona : uniquement celle indiquée par le plan.
- Fixture : recréée pour le run, jamais héritée d'un run précédent.
- Prompt : exact, sans reformulation opérateur.
- Aucun rerun parce qu'une réponse semble mauvaise.
- Aucun changement de candidat, scénario, oracle, ordre ou outil pendant la
  campagne.
- Ne jamais modifier une trajectoire pour influencer sa consommation de
  tokens.

## Technique ≠ pédagogique

Une autorisation locale nécessaire à l'action décidée par Claude peut être
acceptée lorsqu'elle reste dans le workspace et ne modifie pas le stimulus.

Refuser ou interrompre les recherches globales, accès hors workspace ou
ressources externes non prévues qui compromettraient l'isolation.

Une réponse pédagogiquement mauvaise, inattendue ou défavorable n'est pas une
invalidité technique.

## Format des blocs

Lorsqu'un bloc de commande est demandé, ne pas l'entourer d'une longue
explication. Utiliser :

```text
RUN-XXX - BLOC 1

<bloc shell>
```

ou :

```text
RUN-XXX - BLOC 2

<bloc shell>
```

Le contenu des blocs suit `COLLECTOR_KIT/commands/bloc1.md` et
`COLLECTOR_KIT/commands/bloc2.md`.
