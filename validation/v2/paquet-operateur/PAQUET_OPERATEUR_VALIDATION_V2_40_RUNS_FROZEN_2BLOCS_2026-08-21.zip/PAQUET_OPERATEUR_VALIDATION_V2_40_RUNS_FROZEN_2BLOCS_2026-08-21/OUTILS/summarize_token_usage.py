#!/usr/bin/env python3
from pathlib import Path
import csv, json, os, statistics, argparse

P=Path(__file__).resolve().parents[1]
DEFAULT_CAMPAIGN="/projets/skill/tests/validation_v2_40runs_2026-08-21/execution"
FIELDS=['input_tokens','cache_creation_input_tokens','cache_read_input_tokens','output_tokens','total_input_tokens','total_tokens']

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--tsv'); args=ap.parse_args()
    campaign=Path(os.environ.get('V2_CAMPAIGN_ROOT',DEFAULT_CAMPAIGN)); runs=campaign/'runs'
    with open(P/'RUNS.csv',encoding='utf-8',newline='') as f: plan=list(csv.DictReader(f))
    data=[]
    for r in plan:
        mp=runs/r['run_id']/'metrics.json'
        if not mp.exists(): continue
        m=json.loads(mp.read_text(encoding='utf-8'))
        if not m.get('token_usage_observable', True):
            continue
        row={**r}
        for k in FIELDS: row[k]=m.get(k)
        data.append(row)
    out_fields=['run_id','regime','scenario_id','condition','repetition']+FIELDS
    if args.tsv:
        with open(args.tsv,'w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=out_fields,delimiter='\t'); w.writeheader(); w.writerows([{k:r.get(k,'') for k in out_fields} for r in data])
    print(f"RUNS_WITH_METRICS={len(data)}/{len(plan)}")
    keyed={(r['scenario_id'],r['repetition'],r['condition']):r for r in data}
    deltas=[]
    print('PAIRES_AB:')
    for sidn in range(1,9):
        sid=f'NOY{sidn:03d}'
        for rep in ['1','2']:
            a=keyed.get((sid,rep,'A')); b=keyed.get((sid,rep,"B'"))
            if not a or not b: continue
            dt=a['total_tokens']-b['total_tokens']; pct=(100*dt/b['total_tokens']) if b['total_tokens'] else None
            deltas.append(dt); print(f"{sid} R{rep} delta_total={dt} delta_pct={pct:.2f}%" if pct is not None else f"{sid} R{rep} delta_total={dt} delta_pct=NA")
    if deltas:
        print(f"DELTA_TOTAL_MEAN={statistics.mean(deltas):.2f}")
        print(f"DELTA_TOTAL_MEDIAN={statistics.median(deltas):.2f}")
        print(f"DELTA_TOTAL_MIN={min(deltas)}")
        print(f"DELTA_TOTAL_MAX={max(deltas)}")

if __name__=='__main__': main()
