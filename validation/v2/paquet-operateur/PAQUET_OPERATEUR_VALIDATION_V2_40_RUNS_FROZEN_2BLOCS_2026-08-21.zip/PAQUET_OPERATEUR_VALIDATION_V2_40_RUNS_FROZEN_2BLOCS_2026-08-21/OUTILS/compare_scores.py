#!/usr/bin/env python3
import csv, sys
from pathlib import Path
from collections import Counter

if len(sys.argv)!=3:
    raise SystemExit("usage: compare_scores.py SCORE_S1.tsv SCORE_S2.tsv")

def load(p):
    with open(p,encoding="utf-8",newline="") as f:
        return {r["trajectory_id"]:r for r in csv.DictReader(f,delimiter="\t")}

a,b=load(sys.argv[1]),load(sys.argv[2])
ids=sorted(set(a)&set(b))
pairs=[(a[i]["verdict"],b[i]["verdict"]) for i in ids]
agree=sum(x==y for x,y in pairs)
labels=["PASS","FAIL","INDÉTERMINÉ"]
n=len(ids)
po=agree/n if n else 0
ca=Counter(x for x,_ in pairs); cb=Counter(y for _,y in pairs)
pe=sum((ca[l]/n)*(cb[l]/n) for l in labels) if n else 0
k=(po-pe)/(1-pe) if n and pe<1 else 1.0
print(f"N={n}")
print(f"ACCORDS={agree}")
print(f"TAUX_ACCORD={po:.4f}")
print(f"KAPPA={k:.4f}")
print("DESACCORDS:")
for i in ids:
    if a[i]["verdict"]!=b[i]["verdict"]:
        print(f"{i}\t{a[i]['scenario_id']}\t{a[i]['verdict']}\t{b[i]['verdict']}")
