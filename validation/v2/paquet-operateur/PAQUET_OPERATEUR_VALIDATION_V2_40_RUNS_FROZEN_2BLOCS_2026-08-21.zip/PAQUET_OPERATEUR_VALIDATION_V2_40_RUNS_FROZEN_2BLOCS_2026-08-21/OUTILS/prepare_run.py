#!/usr/bin/env python3
from pathlib import Path
import argparse
import csv
import json
import os
import shutil
import subprocess
import sys
import shlex

P = Path(__file__).resolve().parents[1]
DEFAULT_CAMPAIGN = "/projets/skill/tests/validation_v2_40runs_2026-08-21/execution"
CLAUDE = "/home/david/.local/share/claude/versions/2.1.232"
MODEL = "claude-sonnet-5"
EFFORT = "medium"
MODE = "default"
SKILL_NAME = "tuteur-ingenierie-pedagogique"


def csv_rows(name):
    with open(P / name, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def resolve_planned(run_id):
    for row in csv_rows("RUNS.csv"):
        if row["run_id"] == run_id:
            return row
    for row in csv_rows("RUNS_CONDITIONNELS.csv"):
        if row["conditional_id"] == run_id:
            return {
                "run_id": row["conditional_id"],
                "regime": row["regime"],
                "scenario_id": row["scenario_id"],
                "condition": row["condition"],
                "repetition": row["repetition"],
                "persona": row["persona"],
                "turns": row["turns"],
                "status": row["status"],
            }
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run_id", help="RUN-V2-xxx, R3-NOYxxx-X, ou identifiant neuf de rerun technique")
    ap.add_argument("--rerun-of", default=None, help="source exacte pour un rerun technique")
    ap.add_argument(
        "--launch",
        action="store_true",
        help="lance Claude Code après préparation ; destiné au BLOC 1 opérateur",
    )
    args = ap.parse_args()

    source_id = args.rerun_of or args.run_id
    row = resolve_planned(source_id)
    if row is None:
        raise SystemExit(f"STOP — run source inconnu: {source_id}")
    if args.rerun_of and resolve_planned(args.run_id) is not None:
        raise SystemExit("STOP — un rerun technique doit utiliser un nouvel identifiant, pas un run planifié")

    scfg = json.loads((P / "scenario_config.json").read_text(encoding="utf-8"))[row["scenario_id"]]
    campaign = Path(os.environ.get("V2_CAMPAIGN_ROOT", DEFAULT_CAMPAIGN))
    ws = campaign / "workspaces" / args.run_id
    runs = campaign / "runs"
    prompts = campaign / "prompts"

    if ws.exists() or (runs / args.run_id).exists() or (runs / f"{args.run_id}.zip").exists():
        raise SystemExit(f"STOP — collision pour {args.run_id}")

    ws.mkdir(parents=True)
    runs.mkdir(parents=True, exist_ok=True)
    prompts.mkdir(parents=True, exist_ok=True)

    if row["condition"] == "A":
        target = ws / ".claude/skills" / SKILL_NAME
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(P / "CANDIDATE/en_cours", target)
    else:
        forbidden = ws / ".claude/skills" / SKILL_NAME
        if forbidden.exists():
            raise SystemExit("STOP — skill présent dans un run sans skill")

    persona = scfg.get("persona")
    if persona:
        shutil.copy2(P / "PERSONAS" / f"{persona}.md", ws / "persona.md")

    for rel, content in scfg.get("fixtures", {}).items():
        fp = ws / rel
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(content, encoding="utf-8")

    prompt_files = []
    for i, turn in enumerate(scfg["turns"], 1):
        pf = prompts / f"{args.run_id}.T{i}.txt"
        pf.write_text(turn.rstrip() + "\n", encoding="utf-8")
        prompt_files.append(str(pf))

    context = {
        "run_id": args.run_id,
        "rerun_of": args.rerun_of,
        "source_run_id": source_id,
        "scenario_id": row["scenario_id"],
        "regime": row["regime"],
        "condition": row["condition"],
        "repetition": row["repetition"],
        "persona": persona,
        "workspace": str(ws),
        "prompt_files": prompt_files,
        "fixtures": list(scfg.get("fixtures", {}).keys()),
    }
    (ws / "run_context.json").write_text(
        json.dumps(context, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    collector = P / "COLLECTOR_KIT/collect_run.py"
    first = Path(prompt_files[0])
    cond = "skill" if row["condition"] == "A" else "no-skill"
    expected = "yes" if row["condition"] == "A" else "n/a"

    subprocess.run(
        [
            sys.executable,
            str(collector),
            "start",
            "--run-id",
            args.run_id,
            "--scenario-id",
            row["scenario_id"],
            "--condition",
            cond,
            "--skill-expected",
            expected,
            "--skill-name",
            SKILL_NAME,
            "--prompt-file",
            str(first),
            "--output-root",
            str(runs),
        ],
        check=True,
        cwd=ws,
    )

    claude = [
        CLAUDE,
        "--model",
        MODEL,
        "--effort",
        EFFORT,
        "--permission-mode",
        MODE,
    ]
    if persona:
        claude += ["--append-system-prompt-file", str(ws / "persona.md")]

    first_prompt = first.read_text(encoding="utf-8").rstrip("\n")
    claude += [first_prompt]

    print(f"PREPARED={args.run_id}")
    print(f"SCENARIO={row['scenario_id']}")
    print("CONDITION=" + ("avec skill" if row["condition"] == "A" else "sans skill"))
    print(f"REPETITION={row['repetition']}")
    print(f"WORKSPACE={ws}")

    if len(prompt_files) > 1:
        print("\nTours utilisateur prévus ensuite :")
        for i, pf in enumerate(prompt_files[1:], 2):
            print(f"  Tour {i}: cat {shlex.quote(pf)}")

    if not args.launch:
        shell_parts = [shlex.quote(x) for x in claude[:-1]]
        shell_parts.append("$(cat " + shlex.quote(str(first)) + ")")
        prefix = (
            f"cd {shlex.quote(str(ws))} && "
            "export DISABLE_AUTOUPDATER=1 CLAUDE_CODE_DISABLE_AUTO_MEMORY=1 && "
        )
        print("\nCommande Claude à lancer :")
        print(prefix + " ".join(shell_parts))
        return

    env = os.environ.copy()
    env["DISABLE_AUTOUPDATER"] = "1"
    env["CLAUDE_CODE_DISABLE_AUTO_MEMORY"] = "1"

    print("\nLAUNCH=CLAUDE")
    completed = subprocess.run(claude, cwd=ws, env=env)
    print(f"CLAUDE_EXIT_CODE={completed.returncode}")


if __name__ == "__main__":
    main()
