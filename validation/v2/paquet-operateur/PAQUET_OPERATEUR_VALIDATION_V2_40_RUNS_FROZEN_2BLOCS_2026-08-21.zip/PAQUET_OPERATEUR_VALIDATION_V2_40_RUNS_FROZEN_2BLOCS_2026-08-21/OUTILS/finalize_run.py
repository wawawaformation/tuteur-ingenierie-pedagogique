#!/usr/bin/env python3
from pathlib import Path
import json, os, shutil, subprocess, sys, zipfile, hashlib, argparse

P=Path(__file__).resolve().parents[1]
DEFAULT_CAMPAIGN="/projets/skill/tests/validation_v2_40runs_2026-08-21/execution"

def sha(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("run_id"); args=ap.parse_args()
    campaign=Path(os.environ.get("V2_CAMPAIGN_ROOT",DEFAULT_CAMPAIGN))
    ws=campaign/"workspaces"/args.run_id; runs=campaign/"runs"
    ctx_path=ws/"run_context.json"
    if not ctx_path.exists(): raise SystemExit(f"STOP — contexte absent: {ctx_path}")
    ctx=json.loads(ctx_path.read_text(encoding="utf-8"))

    collector=P/"COLLECTOR_KIT/collect_run.py"; parser=P/"COLLECTOR_KIT/analyse_jsonl.py"
    subprocess.run([sys.executable,str(collector),"collect","--run-id",args.run_id,
                    "--output-root",str(runs),"--parser",str(parser)],check=True,cwd=ws)
    out=runs/args.run_id
    if not out.exists(): raise SystemExit("STOP — collecte absente")

    art=out/"artifacts"; copied=0
    for rel in ctx.get("fixtures",[]):
        src=ws/rel
        if src.exists():
            dst=art/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst); copied+=1
    shutil.copy2(ctx_path,out/"run_context.json")

    metrics_path=out/"metrics.json"
    if not metrics_path.exists(): raise SystemExit("STOP — metrics.json absent")
    metrics=json.loads(metrics_path.read_text(encoding="utf-8"))
    required=["input_tokens","cache_creation_input_tokens","cache_read_input_tokens","output_tokens","token_usage_observable","total_input_tokens","total_tokens"]
    missing=[k for k in required if k not in metrics]
    if missing: raise SystemExit("STOP — compteurs tokens incomplets: "+", ".join(missing))

    zip_path=runs/f"{args.run_id}.zip"
    if zip_path.exists(): raise SystemExit(f"STOP — archive déjà présente: {zip_path}")
    with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob("*")):
            if p.is_file(): z.write(p,p.relative_to(runs))

    print("COLLECT=OK")
    print(f"ARTIFACTS={copied}")
    if metrics.get("token_usage_observable"):
        print("TOKENS_STATUS=OBSERVABLE")
        print(f"TOKENS_INPUT={metrics['input_tokens']}")
        print(f"TOKENS_CACHE_CREATE={metrics['cache_creation_input_tokens']}")
        print(f"TOKENS_CACHE_READ={metrics['cache_read_input_tokens']}")
        print(f"TOKENS_OUTPUT={metrics['output_tokens']}")
        print(f"TOKENS_TOTAL_INPUT={metrics['total_input_tokens']}")
        print(f"TOKENS_TOTAL={metrics['total_tokens']}")
    else:
        print("TOKENS_STATUS=INDISPONIBLE")
    print(f"ARCHIVE={zip_path}")
    print(f"SHA256={sha(zip_path)}")

if __name__=="__main__": main()
