#!/usr/bin/env python3
from pathlib import Path
import csv, os, re, random, zipfile, hashlib, shutil, argparse

P=Path(__file__).resolve().parents[1]
DEFAULT_CAMPAIGN="/projets/skill/tests/validation_v2_40runs_2026-08-21/execution"
SEED=2026082105

def sha(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()

def rows(name):
    with open(P/name,encoding="utf-8",newline="") as f: return list(csv.DictReader(f))

def keep_user_assistant(md):
    parts=re.split(r"(?m)^## (USER|ASSISTANT|TOOL[^\n]*)\n",md); out=[]
    for i in range(1,len(parts),2):
        if parts[i].strip() in {"USER","ASSISTANT"}: out.append(f"## {parts[i].strip()}\n\n{parts[i+1].strip()}")
    return "\n\n".join(out).strip()+"\n"

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--scope',choices=['base','conditional','all'],default='base'); args=ap.parse_args()
    campaign=Path(os.environ.get("V2_CAMPAIGN_ROOT",DEFAULT_CAMPAIGN)); rr=campaign/'runs'; scoring=campaign/'scoring'; private=campaign/'private'
    scoring.mkdir(parents=True,exist_ok=True); private.mkdir(parents=True,exist_ok=True)
    base=rows('RUNS.csv')
    conditional=[]
    for r in rows('RUNS_CONDITIONNELS.csv'):
        rid=r['conditional_id']
        if (rr/rid/'trajectory.md').exists():
            conditional.append({'run_id':rid,'regime':r['regime'],'scenario_id':r['scenario_id'],'condition':r['condition'],'repetition':r['repetition']})
    selected=base if args.scope=='base' else conditional if args.scope=='conditional' else base+conditional
    missing=[r['run_id'] for r in selected if not (rr/r['run_id']/'trajectory.md').exists()]
    if missing: raise SystemExit('STOP — collectes manquantes: '+', '.join(missing))
    if not selected: raise SystemExit('STOP — aucune trajectoire dans ce scope')
    shuffled=selected[:]; random.Random(SEED + {'base':0,'conditional':1,'all':2}[args.scope]).shuffle(shuffled)
    pkg=scoring/f"PAQUET_AVEUGLE_V2_{args.scope.upper()}_{len(selected)}"
    if pkg.exists(): shutil.rmtree(pkg)
    (pkg/'trajectoires').mkdir(parents=True); (pkg/'ORACLES_SCOREUR').mkdir()
    for sid in sorted(set(r['scenario_id'] for r in selected)):
        shutil.copy2(P/'ORACLES_SCOREUR'/f'{sid}.md',pkg/'ORACLES_SCOREUR'/f'{sid}.md')
    shutil.copy2(P/'PROCEDURE_SCOREUR.md',pkg/'PROCEDURE_SCOREUR.md'); shutil.copy2(P/'PROMPTS/PROMPT_SCOREUR_AVEUGLE.txt',pkg/'PROMPT_SCOREUR.txt')
    index=[]; mapping=[]
    for num,r in enumerate(shuffled,1):
        tid=f'TRAJ-{num:04d}'; src=rr/r['run_id']; tr=keep_user_assistant((src/'trajectory.md').read_text(encoding='utf-8'))
        ad=src/'artifacts'
        if ad.exists():
            for a in sorted(ad.rglob('*')):
                if a.is_file(): tr += f"\n\n## ARTEFACT FINAL — {a.name}\n\n```text\n{a.read_text(encoding='utf-8')}\n```\n"
        (pkg/'trajectoires'/f'{tid}.md').write_text(tr,encoding='utf-8')
        index.append({'trajectory_id':tid,'scenario_id':r['scenario_id']})
        mapping.append({'trajectory_id':tid,'run_id':r['run_id'],'scenario_id':r['scenario_id'],'condition':r['condition'],'repetition':r['repetition'],'regime':r['regime']})
    with open(pkg/'INDEX_TRAJECTOIRES.tsv','w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['trajectory_id','scenario_id'],delimiter='\t'); w.writeheader(); w.writerows(index)
    with open(pkg/'MODELE_VERDICTS.tsv','w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['trajectory_id','scenario_id','verdict','justification'],delimiter='\t'); w.writeheader(); [w.writerow({**r,'verdict':'','justification':''}) for r in index]
    (pkg/'README.md').write_text(f"# Paquet aveugle V2 — {args.scope}\n\n{len(selected)} trajectoires anonymisées.\n",encoding='utf-8')
    hs=[]
    for p in sorted(pkg.rglob('*')):
        if p.is_file(): hs.append(f'{sha(p)}  {p.relative_to(pkg).as_posix()}')
    (pkg/'SHA256SUMS.txt').write_text('\n'.join(hs)+'\n',encoding='utf-8')
    map_path=private/f'CORRESPONDANCE_V2_{args.scope.upper()}.tsv'
    with open(map_path,'w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['trajectory_id','run_id','scenario_id','condition','repetition','regime'],delimiter='\t'); w.writeheader(); w.writerows(mapping)
    zp=scoring/f'{pkg.name}.zip'
    if zp.exists(): zp.unlink()
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(pkg.rglob('*')):
            if p.is_file(): z.write(p,p.relative_to(pkg.parent))
    Path(str(zp)+'.sha256').write_text(f'{sha(zp)}  {zp.name}\n',encoding='utf-8')
    print(f'BLIND_PACKAGE={zp}'); print(f'PRIVATE_MAPPING={map_path}'); print(f'SHA256={sha(zp)}')

if __name__=='__main__': main()
