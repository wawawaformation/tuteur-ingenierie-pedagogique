#!/usr/bin/env python3
import csv, sys
from pathlib import Path
from collections import Counter, defaultdict

if len(sys.argv)!=3:
    raise SystemExit("usage: unblind_scores.py VERDICTS.tsv CORRESPONDANCE.tsv")

def rows(path, delim="\t"):
    with open(path,encoding="utf-8",newline="") as f:
        return list(csv.DictReader(f,delimiter=delim))

scores={r["trajectory_id"]:r for r in rows(sys.argv[1])}
mapping=rows(sys.argv[2])
merged=[]
for m in mapping:
    s=scores.get(m["trajectory_id"])
    if not s: continue
    merged.append({**m,"verdict":s["verdict"],"justification":s.get("justification","")})

print("SYNTHESE")
groups=defaultdict(list)
for r in merged:
    groups[(r["scenario_id"],r["condition"])].append(r["verdict"])
for (sid,cond),vs in sorted(groups.items()):
    c=Counter(vs)
    label="avec skill" if cond=="A" else "sans skill"
    print(f"{sid}\t{label}\tPASS={c['PASS']}\tFAIL={c['FAIL']}\tINDET={c['INDÉTERMINÉ']}")
